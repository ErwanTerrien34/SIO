1. Copier le projet dans le dossier wamp64/www
2. Exécuter le script produits.sql dans phpmyadmin sous mysql

Pour le compte administrateur :
login: Rarissime
mail: gerard.menvussat@mail.com
mot de passe: S!0M€rm02_34