<?php
    header("Location: accueil/accueil.php");
?>