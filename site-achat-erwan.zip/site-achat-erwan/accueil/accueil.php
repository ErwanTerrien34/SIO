<!DOCTYPE html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>gamerZ</title>

        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/style.css" />
    </head>

    <body class="body">
        <form method="post" class="head-menu" style = "background-color: rgb(128,128,0);">
        <br>
        <div class="head-menu">
            <nobr>
            <p style="text-align:left;">
                <span style="float:right;">
                <?php
                    session_start();
                    $id_session = session_id();

                    if(isset($_SESSION['Utilisateur'])) //Vérifie si l'utilisateur et connecté et génère un certain en-tête en fonction
                    {
                        echo '<div style = "background-color: rgb(128,128,0); text-align:right;"><span STYLE="padding:0 0 0 40px;"><a href="connexion\client.php" style="color: white;"><img src="imgs/profil.png" alt="profil" width=32 height=32><span STYLE="padding:0 0 0 10px;">'.$_SESSION['Utilisateur'].'</a> <span STYLE="padding:0 0 0 10px;"> <th <input type="submit" style="cursor: pointer;" name ="Disconnect" value="Se déconnecter"></span></span>
                        <span STYLE="padding:0 0 0 80px;"><a href="panier\panier.php" style="color: white;"><img src="imgs/panier.png" alt="panier" width=32 height=32><span STYLE="padding:0 0 0 10px;">Panier</a></span>
                        </span><span STYLE="padding:0 0 0 40px;"></div>';
                    }
                    else
                    {
                        echo '<div style = "background-color: rgb(128,128,0); text-align:right;"><span STYLE="padding:0 0 0 40px;"><a href="connexion\connexion.php" style="color: white;"><img src="imgs/profil.png" alt="profil" width=32 height=32 style="vertical-align:bottom;"><span STYLE="padding:0 0 0 10px;">Se connecter</a></span>
                        <span STYLE="padding:0 0 0 40px;"><a href="panier\panier.php" style="color: white;"><img src="imgs/panier.png" alt="panier" width=32 height=32 style="vertical-align:bottom;"><span STYLE="padding:0 0 0 10px;">Panier</a></span><span STYLE="padding:0 0 0 40px;"></div>
                        </span>';
                    }
                ?>
            </p>
            </nobr>
            <?php
                if(isset($_POST['Disconnect']))
                {
                    session_destroy();
                    header("Location: accueil/accueil.php");
                }
            ?>
        </div>
        <br>
        </form>
        <br><br><br><br><br>
        <div class="title"><span style="text-align: center; border-color: black;"><img src="imgs/electra 100.png" alt="electra100" width=256 height=144></span>GamerZ <br>
        </div>
        <p style="text-align:center; font-size:22px;">
            Configure ta machine idéale
            <br>
            <br>
            <br>
            <br>
            <br>
            Nos produits
            <table border="1" cellspacing= "20" style="margin: auto; border-color: black; column-width: 300px;">
                <tr style="margin: auto; border-color: black; text-align: center;">
                    <th width="300px" style="text-align: center; border-color: black;"><a href="composants\chassis.php" style="color:white;">Boîtier</a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\processeur.php" style="color:white;">Processeur</a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\graphique.php" style="color:white;">Carte graphique</a></th>
                </tr>
                <tr style="border-color: black; text-align: center;">
                    <th width="300px" style="text-align: center; border-color: black;"><a href="composants\chassis.php"><img src="imgs/pc.fw.png" alt="electra100" width=256 height=209></a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\processeur.php"><img src="imgs/cpu.jpg" width="168" height="143" alt=""/></a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\graphique.php"><img src="imgs/gpu.fw.png" width="168" height="143" alt=""/></a></th>
                </tr>
                <tr style="border-color: black; text-align: center;">
                    <th width="300px" style="text-align: center; border-color: black;"><br><br><br></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><br><br><br></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><br><br><br></th>
                </tr>
              	<tr style="margin: auto; border-color: black; text-align: center;">
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\ram.php" style="color:white;">RAM</a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\system.php" style="color:white;">Disque Système</a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\data.php" style="color:white;">Disque de données</a></th>
                </tr>
                <tr style="border-color: black; text-align: center;">
                	<th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\ram.php" style="color:white;"><img src="imgs/ram.fw.png" width="168" height="143" alt=""/></a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\system.php" style="color:white;"><img src="imgs/ssd.fw.png" width="168" height="143" alt=""/></a></th>
                    <th width="300px" stye= "text-align: center; border-color: black;"><a href="composants\data.php" style="color:white;"><img src="imgs/data.fw.png" width="114" height="143" alt=""/></a></th>
				</tr>
            </table>
        </p>
        <br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<footer class="foot" style="background-color: rgb(128,128,0);">
		    <br>
			<a href="contact\contact.php" style="color: white;"><img src="imgs/contact.png" alt="contact" width=32 height=32 style="vertical-align:bottom;"><span STYLE="padding:0 0 0 10px;">Nous contacter<span STYLE="padding:0 0 0 40px;"></a>
			<br>-
		</footer>
    </body>


</html>