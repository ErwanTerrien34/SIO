<?php
/** 
 * gère la connexion à la base de données
*/

// définit les constantes de connexion
const HOST='127.0.0.1';
const PORT = '3306';
const LOGIN = 'root';
const PWD = '';
const CHARSET = 'utf8';
const DBNAME = 'produits';

function getConnexion(){

    // établit la chaîne $dsn
    $dsn = 'mysql:host='.HOST.';port='.PORT.';dbname='.DBNAME.';charset='.CHARSET;

    // essaie de seconnecter à la base de données
    try{
        $cnx = new PDO($dsn, LOGIN, PWD);
        
        // paramètre
        $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    } catch (PDOException $e){
        die('Erreur de connexion : '.$e->getMessage());
    }

    return $cnx;
}