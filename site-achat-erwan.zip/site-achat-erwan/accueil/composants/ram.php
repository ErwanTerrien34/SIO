<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Mémoire vive</title>

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>


<?php
	if(isset($_POST['Buy']))
	{
		require_once '../bdd-pdo.php';
		try
		{
			$cnx = getConnexion();	
			$InfoProduit = "";

			require_once '../bdd-pdo.php';
			$qte = 0;
			try
			{
				$cnx = getConnexion();
				$sql = "select COUNT(*) as Total from panier P JOIN Composants C ON C.idComposants = P.idComposants where C.idComposants = :idP"; //Obtention de la quantité existante
				$stmt = $cnx->prepare($sql);
				$stmt->execute(array('idP' => $_POST['Produit']));
			}
			catch(PDOException $e)
			{
				die('Erreur : '.$e->getMessage());
			}

			while($row = $stmt->fetch())
			{
				$qte = $row['Total'];
			}

			if ($qte == 0)
			{
				$MainSql = "insert into panier (idComposants, quantite) values (:idP, 1)"; //Ajout de l'article
			}
			else
			{
				$MainSql = "update panier SET quantite = quantite + 1 Where idComposants = :idP"; //Augmentation de la quantité s'il est déjà recensé dans le panier
			}
			
			$stmt = $cnx->prepare($MainSql);
			$stmt->execute(array('idP' => $_POST['Produit']));

			header("Location: ../panier/panier.php");
		}
		catch(PDOException $e)
		{
			die('Erreur : '.$e->getMessage());
		}
	}
?>

<body style="background-color:black; color:white;">

	<header style="background-color:rgb(128,128,0)">
		<div style="margin-top: 10px; margin-left: 10px;">
			<a href="../accueil.php" style="color: rgb(255, 255, 255);"><span STYLE="padding:0 0 0 10px;"><img src="../imgs/accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 10px;">Retour boutique</span></a>
		</div>
	</header>
	<form method="post">

	<div id="myContainer">
		<div>
			<br>
			<h1>Choix de la RAM</h1>
			<h3>Elle contient des informations à utiliser sur le moment et de faire plusieurs tâches à la fois</h3>
			<br>
			<br>
			<label>Sélectionne une mémoire vive</label>
			<?php
				require_once '../bdd-pdo.php';
				try
				{
					$cnx = getConnexion();
					$sql = 'select * from composants WHERE idCategorie = 3 and qteStock != 0'; //Obtient l'ensemble des articles de ce type
					$stmt = $cnx->prepare($sql);
					$stmt->execute();
				}
				catch(PDOException $e)
				{
					die('Erreur : '.$e->getMessage());
				}

				$html = '<select name="Produit">';
				$stmt->setFetchMode(PDO::FETCH_ASSOC);
				while($row = $stmt->fetch())
				{
					$html .= '<option value='.$row['idComposants'].'>'.$row['designation'].'</option>';  //Remplissage de la liste déroulante
				}
				$html .= '</select>';
				echo $html;
			?>
			<input type="submit" name="Buy" value="Ajouter au panier" style="background-color: black; border-color: white; color: rgb(255,255,0); cursor: pointer;">
		</div>
	</div>

	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</form>
</body>

</html>