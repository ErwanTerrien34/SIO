<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
		require_once '../bdd-pdo.php';
		try
		{
			$cnx = getConnexion();
			$sql = 'select COUNT(*) as articles from panier';
			$stmt = $cnx->prepare($sql);
			$stmt->execute();
		}
		catch(PDOException $e)
		{
			die('Erreur : '.$e->getMessage());
		}
		while($row = $stmt->fetch()) //Empêche de passer des commandes vides
		{
			if ($row['articles'] == 0)
			{
				header("Location: ../accueil.php");
			}
		}

		$html = '<select name="Produit">';
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		while($row = $stmt->fetch())
		{
			$html .= '<option value='.$row['idComposants'].'>'.$row['designation'].'</option>';
		}
		$html .= '</select>';
		echo $html;
		
		$total = 0;
        require_once '../bdd-pdo.php';
        try
        {
            $cnx = getConnexion();
            $sql = 'select prixUnitaire, quantite from panier P JOIN Composants C ON P.idComposants = C.idComposants';
            $stmt = $cnx->prepare($sql);
            $stmt->execute();
        }
        catch(PDOException $e)
        {
            die('Erreur : '.$e->getMessage());
        }
        while($row = $stmt->fetch())
        {
            $total += ($row['prixUnitaire'] * $row['quantite']);
        }
		$html = '<title>Passser la commande de ('.$total.' €)</title>';
        echo $html;

        session_start();
        $id_session = session_id();
    ?>

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<header id="head-menu" style="height: 96px;">
    <div style="margin-top: 10px; margin-left: 10px;">
        <a href="../accueil.php" style="color: rgb(255, 255, 255); margin-top: 20px;"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</span></a>
    </div>
</header>

<body style="text-align: center">
    Paiement de la commande
    <br>
    <br>
    <div id="content" class="container">
        <form method="post">
            <p>Si tu valides cette commande, un livreur viendra t'amener ta commande et te fera payer la somme à domicile.</p>
            <br>
            <br>
            <input type="submit" name="Purchase" value="Régler">  
        </form>  
    </div>
    
    <!-- Chargement javascript -->
    <!-- js pour bootstrap : jquery + bundle contenant popper entre autres -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <br>
    <?php
        if(isset($_POST['Purchase']))
        {
            $Detail = "";
            $prix = 0;

            require_once '../bdd-pdo.php';
            try
            {
				$cnx = getConnexion();
                $sql = "Insert into commande (idAdresse, idClient) values (:a,:c)";
                $stmt = $cnx->prepare($sql);
                $stmt->execute(array('a' => $_SESSION['Adresse'], 'c' => $_SESSION['Client']));
				
				$cnx = getConnexion();
                $sql = "Insert into etat values ((SELECT MAX(idCommande) from commande), 1, (SELECT CURDATE()))";
                $stmt = $cnx->prepare($sql);
                $stmt->execute();
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
			try
            {
			    $cnx = getConnexion();
                $sql = "Select * From Panier";
                $stmt = $cnx->prepare($sql);
                $stmt->execute();
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            while($row = $stmt->fetch())
            {
				$cnx2 = getConnexion();
				$sql2 = "Insert into detailscmds values ((SELECT MAX(idCommande) from commande), :a, :q)";
				$stmt2 = $cnx->prepare($sql2);
                $stmt2->execute(array('a' => $row['idComposants'], 'q' => $row['quantite']));
            }

            require_once '../bdd-pdo.php';
            try
            {
                $cnx = getConnexion();
                $sql = "Truncate table Panier";
                $stmt = $cnx->prepare($sql);
                $stmt->execute();

                header("Location: ../accueil.php");
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
        }
    ?>
</body>
</html>