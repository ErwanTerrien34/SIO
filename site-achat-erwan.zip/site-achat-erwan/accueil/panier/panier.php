<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
        require_once '../bdd-pdo.php';
        try
        {
            $cnx = getConnexion();
            $sql = 'select SUM(quantite) AS total from panier';
            $stmt = $cnx->prepare($sql);
            $stmt->execute();
        }
        catch(PDOException $e)
        {
            die('Erreur : '.$e->getMessage());
        }
        while($row = $stmt->fetch())
        {
            $html = '<title>Panier ('.$row['total'].')</title>';
        }
        echo $html;

        try
        {
            $cnx = getConnexion();
            $sql = 'delete from panier where quantite = 0';
            $stmt = $cnx->prepare($sql);
            $stmt->execute();
        }
        catch(PDOException $e)
        {
            die('Erreur : '.$e->getMessage());
        }
    ?>

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>
<form method="post">
<body style="background-color: rgb(192, 192, 192);">
    <header id="head-menu" style="height: 96px;">
        <div style="margin-top: 10px; margin-left: 10px;">
            <a href="../accueil.php" style="color: rgb(255, 255, 255); margin-top: 20px;"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</a>
        </div>
    </header>
    <div style="font-size:32px; margin-left: 20px; color: black;">
        Mon panier
    </div>
    <br>
    <cmd style="font-size:32px; margin-left: 20px; color: black;">
        Détail de ma commande
    </cmd>
    <br>
    <br>
    <table border="3px" style="margin-left: 20px; color: black; ">
        <?php
            require_once '../bdd-pdo.php';
            try
            {
                $cnx = getConnexion();
                $sql = 'select C.idComposants, designation, prixUnitaire, quantite from panier P JOIN Composants C ON P.idComposants = C.idComposants group by designation, prixUnitaire';
                $stmt = $cnx->prepare($sql);
                $stmt->execute();
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            $html = '<tr style="text-align: center"><th width="600px">Produit(s)</th><th width="200px">Quantité</th><th width="240px">Prix Unitaire</th></tr>';
            while($row = $stmt->fetch())
            {
                $html .= '<tr ><td style="padding : 10px;">'.$row['designation'].'</td><td style="text-align: right; margin-right: 20px; padding : 10px;"><input name="'.$row['idComposants'].'" type="number" min="0" value="'.$row['quantite'].'" /></td><td style="text-align: right; margin-right: 20px; padding : 10px;">'.$row['prixUnitaire'].' €</td></tr>';
            }
            echo $html;
        ?>
    </table>
    <br>
    <table border="3px" style="margin-left: 625px; color: black; ">
        <?php
			$total = 0;
            try
            {
                $cnx = getConnexion();
                $sql = 'select prixUnitaire, quantite from panier P JOIN Composants C ON P.idComposants = C.idComposants';
                $stmt = $cnx->prepare($sql);
                $stmt->execute();
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            while($row = $stmt->fetch())
            {
                $total += ($row['prixUnitaire'] * $row['quantite']);
            }
			$html = '<tr><th width="195px" style="text-align: center; font-size: 22px; padding : 10px;">Total</th><th width="240px" style="text-align: right; padding : 10px; font-size: 22px">'.$total.' €</th></tr>';
            echo $html
        ?>
    </table>
    <br>
    <?php
        if(isset($_POST['Pay']))
        {   
            session_start();
            $id_session = session_id();
			
			try
			{
				$cnx = getConnexion();
				$sql = 'SELECT COUNT(*) as articles FROM PANIER';
				$stmt = $cnx->prepare($sql);
				$stmt->execute();
			}
			catch(PDOException $e)
			{
				die('Erreur : '.$e->getMessage());
			}
			while($row = $stmt->fetch())
			{
				$i = $row['articles'];
			}
			if ($i == 0)
			{
				echo "Il faut remplir le panier avant de passer la commande";
			}
			else if(isset($_SESSION['Utilisateur']))
            {
				try
				{
					$cnx = getConnexion();
					$sql = 'SELECT COUNT(*) as articles FROM PANIER';
					$stmt = $cnx->prepare($sql);
					$stmt->execute();
				}
				catch(PDOException $e)
				{
					die('Erreur : '.$e->getMessage());
				}
				while($row = $stmt->fetch())
				{
					$i = $row['articles'];
				}
				if ($i == 0)
				{
					echo "Il faut remplir le panier avant de passer la commande";
				}
				else
				{
					header("Location: ../paiement/paiement.php");
				}
            }
            else
            {
                header("Location: ../connexion/connexion.php");
            }
        }
        if(isset($_POST['Clear']))
        {
            try
            {
                $cnx = getConnexion();
                $sql = 'Truncate table panier';
                $stmt = $cnx->prepare($sql);
                $stmt->execute();
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            header("Location: ../panier/panier.php");
        }

        if(isset($_POST['Modify']))
        {
			try
			{
				$cnx = getConnexion();
				$sql = 'select * from panier';
				$stmt = $cnx->prepare($sql);
				$stmt->execute();
			}
			catch(PDOException $e)
			{
				die('Erreur : '.$e->getMessage());
			}
			while($row = $stmt->fetch()) //Modifie les articles avec la quantité correspondante
			{
				try
				{
					$cnx2 = getConnexion();
					$sql2 = 'UPDATE panier SET quantite = :q WHERE idComposants = :c';
					$stmt2 = $cnx->prepare($sql2);
					$stmt2->execute(array('q' => $_POST[$row['idComposants']], 'c' => $row['idComposants']));
				}
				catch(PDOException $e)
				{
					die('Erreur : '.$e->getMessage());
				}
			}
            header("Location: ../panier/panier.php");
        }
    ?>
</body>
<footer style="margin-left: 20px;">
    <br>
    
	<input style="cursor: pointer;" type="submit" name="Pay" value="Passer la commande">
	<span STYLE="padding:0 0 0 20px;"><input style="cursor: pointer;" type="submit" name="Clear" value="Vider le panier">
	<span STYLE="padding:0 0 0 20px;"><input style="cursor: pointer;" type="submit" name="Modify" value="Mettre à jour">
	
</footer>
</form>
</html>