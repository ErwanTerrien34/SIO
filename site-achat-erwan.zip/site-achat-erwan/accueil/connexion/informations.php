<?php
    session_start();
    $id_session = session_id();
?>

<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
        echo "<title>".$_SESSION['Utilisateur']."</title>";
    ?>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<header  id="head-menu" style="height: 96px; padding : 10px;">
    <a href="../accueil.php" style="color: rgb(255, 255, 255);"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</a>
    <span style="float:right;">
        <span STYLE="padding:0 0 0 40px;"><a href="../panier\panier.php" style="color: white;"><img src="panier.png" alt="panier" width=64 height=64><span STYLE="padding:0 0 0 20px;">Panier</a></span>
    </span>
</header>

<body style="text-align: left">
    <br>
    <br>
    <div style="margin-left: 10px;">
        <form method="post">
			<?php
				require_once '../bdd-pdo.php';
				$html = '';
				try
				{
					$cnx = getConnexion();
					$sql = "SELECT * FROM clients C JOIN Adresse A ON A.idAdresse = C.idAdresse WHERE idClient = :c";
					$stmt = $cnx->prepare($sql);
					$stmt->execute(array('c' => $_SESSION['Client']));
				}
				catch(PDOException $e)
				{
					die('Erreur : '.$e->getMessage());
				}
				while($row = $stmt->fetch())
				{	
					$html .= '<table style="width: 100%;"> <tr> <td align="center">Nom *<input type="text" class="form-control col-sm-3" name="Nom" value="'.$row['nom'].'" placeholder="Nom *" required> <span STYLE="padding:0 0 0 20px;"></td></tr><tr> <td align="center">Prenom * <input type="text" class="form-control col-sm-3" name="Prenom" value="'.$row['prenom'].'" placeholder="Prénom *" required> <span STYLE="padding:0 0 0 20px;"></td></tr><tr> <td align="center">Adresse mail *<input type="email" class="form-control col-sm-3" name="login" value="'.$row['mail'].'" placeholder="Adresse mail *" required> <span STYLE="padding:0 0 0 20px;"></td></tr><tr> <td align="center"><span STYLE="padding:0 0 0 20px;">Pseudo *<input type="text" class="form-control col-sm-3" name="pseudo" value="'.$row['pseudo'].'" placeholder="Pseudo *" required> <span STYLE="padding:0 0 0 20px;"></td></tr><tr> <td align="center"> Adresse *<input type="text" class="form-control col-sm-3" name="Adr" value="'.$row['libelle'].'" placeholder="Adresse *" required> <span STYLE="padding:0 0 0 20px;"><br>Code postal *<input type="text" class="form-control col-sm-3" name="Cpt" value="'.$row['codePostal'].'" placeholder="Code postal * "pattern="[0-9]{5}" required width=60px> <span STYLE="padding:0 0 0 20px;"> <br> Ville * :<input type="text" class="form-control col-sm-3" name="Ville" value="'.$row['ville'].'" placeholder="Ville *" required> <span STYLE="padding:0 0 0 20px;"></td></tr><tr><td align="center">Numéro de téléphone *<input type="tel" class="form-control col-sm-3" name="NumTel" value="'.$row['NumTel'].'" placeholder="Numéro de téléphone * (ex: 0123456789)" pattern="[0-9]{10}" required> <br></td></tr></table>';
				}
				echo $html;
			?>

            <input style="cursor: pointer;" type="submit" name="Modify" value="Mettre à jour">
            <br>
            <br>
            * champs obligatoires
        </form>
        <br>
    </div>

    <!-- Chargement javascript -->
    <!-- js pour bootstrap : jquery + bundle contenant popper entre autres -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
	<br>
    <?php
        if(isset($_POST['Modify']))
        {
            $problem = 0;

            require_once '../bdd-pdo.php';
            try
            {
                $cnx = getConnexion();
                $sql = 'Select * from clients where mail = :m';
                $stmt = $cnx->prepare($sql);
                $stmt->execute(array('m' => $_POST['login']));
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            while($row = $stmt->fetch())
            {
                if (($row['mail'] == $_POST['login']) && ($_POST['login'] != $_SESSION['Mail']))
                {
                    $problem += 1;
                    echo "le mail existe déjà";
                }
            }
            if ($problem == 0)
            {
                try
                {
                    require_once '../bdd-pdo.php';
                    $cnx = getConnexion();
					$sql = "UPDATE adresse SET libelle = :a, ville = :v, codePostal = :c  WHERE idAdresse = (SELECT idAdresse FROM Clients WHERE idClient = :i)";
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute(array('a' => $_POST['Adr'], 'v' => $_POST['Ville'], 'c' => $_POST['Cpt'], 'i' => $_SESSION['Client']));
                    
					$cnx = getConnexion();
					$sql = "UPDATE clients SET nom = :n, prenom = :pr, mail = :m, pseudo = :ps, NumTel = :t WHERE idClient = :i";
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute(array('n' => $_POST['Nom'], 'pr' => $_POST['Prenom'], 'm' => $_POST['login'], 'ps' => $_POST['pseudo'], 't' => $_POST['NumTel'], 'i' => $_SESSION['Client']));
					
					echo "Tes informations ont bien été modifiées";
                }
                catch(PDOException $e)
                {
                    die('Erreur : '.$e->getMessage());
                }
				
				$_SESSION['Utilisateur'] = $_POST['pseudo'];
				$_SESSION['Mail'] = $_POST['login'];
				
				header("Location: informations.php");
            }
        }
    ?>
</body>
<html>