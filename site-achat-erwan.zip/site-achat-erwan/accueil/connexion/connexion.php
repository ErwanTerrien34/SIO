<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>Se connecter</title>

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<header id="head-menu" style="height: 96px;">
    <div style="margin-top: 10px; margin-left: 10px;">
        <a href="../accueil.php" style="color: rgb(255, 255, 255); margin-top: 20px;"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</span></a>
    </div>
</header>

<body style="text-align: center;">
    <br>
    <div style="font-size:32px;">
        Se connecter
    </div>
    <br>
    <br>
    <div id="content" class="container">
        <form method="post">
            <table style="width: 100%">
                <tr>
                    <td align="center">
                        <input type="email" class="form-control col-sm-3" name="login" placeholder="Adresse mail" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="password" class="form-control col-sm-3" name="password" placeholder="Mot de passe">
                        <br>
                    </td>
                </tr>
            </table>
            <input style="cursor: pointer;" type="submit" name="Connect" value="Connexion">
			<span STYLE="padding:0 0 0 20px;">
			<input style="cursor: pointer;" type="submit" name="Forget" value="Mot de passe oublié">
        </form>    
    </div>
    
    <!-- Chargement javascript -->
    <!-- js pour bootstrap : jquery + bundle contenant popper entre autres -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <br>
    <?php
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\Exception;
		
        if(isset($_POST['Connect']))
        {
            $password = ($_POST['password']);
            $log_exist = 0;

            require_once '../bdd-pdo.php';
            try
            {
                $cnx = getConnexion();
                $sql = "Select * from clients where mail = :m";
                $stmt = $cnx->prepare($sql);
                $stmt->execute(array('m' => $_POST['login']));
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            while($row = $stmt->fetch())
            {
                if ($row['mail'] == $_POST['login'])
                {
                    $log_exist += 1;
                }
            }

            if ($log_exist != 0)
            {
                require_once '../bdd-pdo.php';
                try
                {
                    $cnx = getConnexion();
                    $sql = 'Select * from clients where mail = "'.$_POST['login'].'"';
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute();
                }
                catch(PDOException $e)
                {
                    die('Erreur : '.$e->getMessage());
                }
                while($row = $stmt->fetch())
                {
                    if ($row['MotDePasse'] == $password)
                    {
                        $cnx = getConnexion();
                        $sql = "Select * from clients";
                        $stmt = $cnx->prepare($sql);
                        $stmt->execute();
                        session_start();
                        $_SESSION['Utilisateur'] = $row['pseudo'];
                        $_SESSION['Mail'] = $_POST['login'];
						$_SESSION['Client'] = $row['idClient'];
						$_SESSION['Adresse'] = $row['idAdresse'];
                        header("Location: ../accueil.php");
                    }
                    else
                    {
                        echo "login ou mot de passe incorrect!";
                    }
                }
            }
            else
            {
                echo "login ou mot de passe incorrect!<br>";
            }
        }
		if (isset($_POST['Forget']))
		{
			require_once '../bdd-pdo.php';
			$i = 0;
			try
			{
				$cnx = getConnexion();
				$sql = "Select * from clients where mail = :m";
				$stmt = $cnx->prepare($sql);
				$stmt->execute(array('m' => $_POST['login']));
			}
			catch(PDOException $e)
			{
				die('Erreur : '.$e->getMessage());
			}
			
			while($row = $stmt->fetch())
			{				
				$i++;
				require 'PHPMailer/src/Exception.php';
				require 'PHPMailer/src/PHPMailer.php';
				require 'PHPMailer/src/SMTP.php';

				$mail = new PHPMailer();
				$mail->CharSet = 'UTF-8'; //Format d'encodage à utiliser pour les caractères
				$mail->IsSMTP();
				$mail->Host = 'smtp.laposte.net';               //Adresse IP ou DNS du serveur SMTP
				$mail->Port = 465;                          //Port TCP du serveur SMTP
				$mail->SMTPAuth = 1;                        //Utiliser l'identification

				if($mail->SMTPAuth)
				{
				   $mail->SMTPSecure = 'ssl';               //Protocole de sécurisation des échanges avec le SMTP
				   $mail->Username   =  'er.terrien@laposte.net';   //Adresse email à utiliser
				   $mail->Password   =  'Laposte34000!';         //Mot de passe de l'adresse email à utiliser
				}
				$mail->smtpConnect();

				$mail->From       = 'er.terrien@laposte.net' ;                //L'email à afficher pour l'envoi
				$mail->FromName = 'Admin';			//L'alias à afficher pour l'envoi

				$mail->Subject    =  "Rappel mot de passe Gamerz";                      //Le sujet du mail
				$mail->WordWrap   = 50; 			                   //Nombre de caracteres pour le retour a la ligne automatique
				$mail->Body = 'Ton mot de passe est : '.$row['MotDePasse']; 	       //Texte brut
				$mail->IsHTML(false);
				$mail->AddAddress($_POST['login'],$row['pseudo']);
				if (!$mail->send())
				{
					echo "Consultes ta messagerie !<br>";
				}
				else
				{
					echo "La messagerie est injoignable !<br>";
				}
			}
			if ($i == 0)
			{
				echo "L'adresse mail n'existe pas<br>";
			}
		}
    ?>
    <a href="inscription.php">Pas de compte ?</a>
</body>
</html>