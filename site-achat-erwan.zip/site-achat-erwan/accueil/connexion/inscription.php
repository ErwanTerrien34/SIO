<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>S'inscrire</title>

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<header id="head-menu" style="height: 96px;">
    <div style="margin-top: 10px; margin-left: 10px;">
        <a href="../accueil.php" style="color: rgb(255, 255, 255); margin-top: 20px;"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</span></a>
    </div>
</header>

<body style="text-align: center;">
    <br>
    <div style="font-size:32px;">
        S'inscrire
    </div>
    <br>
    <br>
    <div id="content" class="container">
        <form method="post"> 
            <table style="width: 100%">
                <tr>
                    <td align="center">
                        <input type="text" class="form-control col-sm-3" name="Nom" placeholder="Nom *" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="text" class="form-control col-sm-3" name="Prenom" placeholder="Prénom *" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="email" class="form-control col-sm-3" name="login" placeholder="Adresse mail *" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="text" class="form-control col-sm-3" name="pseudo" placeholder="Pseudo *" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                    <input type="text" class="form-control col-sm-3" name="Adr" placeholder="Adresse *" required>
                    <span STYLE="padding:0 0 0 20px;"><input type="text" class="form-control col-sm-3" name="Cpt" placeholder="Code postal * "pattern="[0-9]{5}" required width=60px>
                    <span STYLE="padding:0 0 0 20px;"><input type="text" class="form-control col-sm-3" name="Ville" placeholder="Ville *" required>
                    <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="tel" class="form-control col-sm-3" name="NumTel" placeholder="Numéro de téléphone * (ex: 0123456789)" pattern="[0-9]{10}" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="password" class="form-control col-sm-3" name="password1" placeholder="Mot de passe *" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="password" class="form-control col-sm-3" name="password2" placeholder="Confirmer le mot de passe *" required>
                        <br>
                    </td>
                </tr>
            </table>

            <input style="cursor: pointer;" type="submit" name="Suscribe" value="S'inscrire">
            <br>
            <br>
            * champs obligatoires
        </form>

    </div>
    
    <!-- Chargement javascript -->
    <!-- js pour bootstrap : jquery + bundle contenant popper entre autres -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <br>
    <?php
        if(isset($_POST['Suscribe']))
        {
            $problem = 0;
			$password1 = $_POST['password1'];
			$password2 = $_POST['password2'];

            require_once '../bdd-pdo.php';
            try
            {
                $cnx = getConnexion();
                $sql = 'Select * from clients where mail = :m';
                $stmt = $cnx->prepare($sql);
                $stmt->execute(array('m' => $_POST['login']));
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            while($row = $stmt->fetch())
            {
                if ($row['mail'] == $login) //Vérification des doublons de mails
                {
                    $problem += 1;
                    echo "le mail existe déjà <br>";
                }
            }
            if ($password1 != $password2)
            {
                $problem += 1;
                echo "les deux mots de passe ne correspondent pas !<br>";
            }
            if ($problem == 0)
            {
                try
                {
                    require_once '../bdd-pdo.php';
                    $cnx = getConnexion();
					$sql = "Insert into adresse (libelle, ville, codePostal) values (:a,:v,:c)";
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute(array('a' => $_POST['Adr'], 'v' => $_POST['Ville'], 'c' => $_POST['Cpt']));
					
					$cnx = getConnexion();
					$sql = "select MAX(idAdresse) as adresse from adresse"; //Création de l'adresse
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute();
					
					while($row = $stmt->fetch())
					{
						$a = $row['adresse'];
					}
                    
					$cnx = getConnexion();
					$sql = "Insert into clients (nom, prenom, mail, pseudo, MotDePasse, NumTel, admin, idAdresse) values (:n,:pr,:m,:ps,:pw,:t,'NON',:a)"; //Création du client avec le lien à son adresse
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute(array('n' => $_POST['Nom'], 'pr' => $_POST['Prenom'], 'm' => $_POST['login'], 'ps' => $_POST['pseudo'], 'pw' => $_POST['password1'], 't' => $_POST['NumTel'], 'a' => $a));
                    
					echo "Ton compte a été créé, il te faut maintenant aller sur la page connexion pour te connecter";
                }
                catch(PDOException $e)
                {
                    die('Erreur : '.$e->getMessage());
                }
            }
        }
    ?>
    <br>
    <a href="connexion.php">Déjà un compte ?</a>
</body>
</html>