<?php
    session_start();
    $id_session = session_id();
?>

<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
        echo "<title>".$_SESSION['Utilisateur']."</title>";
    ?>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<header  id="head-menu" style="height: 96px; padding : 10px;">
    <a href="../accueil.php" style="color: rgb(255, 255, 255);"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</a>
    <span style="float:right;">
        <span STYLE="padding:0 0 0 40px;"><a href="../panier\panier.php" style="color: white;"><img src="panier.png" alt="panier" width=64 height=64><span STYLE="padding:0 0 0 20px;">Panier</a></span>
    </span>
</header>

<body style="text-align: center">
    <br>
    <br>
    <div style="margin-left: 10px;">
        <form method="post">
    <div id="content" class="container">
        <form method="post"> 
            <table style="width: 100%">
                <tr>
                    <td align="center">
                        <input type="password" class="form-control col-sm-3" name="password0" placeholder="Ancien mot de passe *" required>
                        <br>
                    </td>
                </tr>
				<tr>
                    <td align="center">
                        <input type="password" class="form-control col-sm-3" name="password1" placeholder="Mot de passe *" required>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="password" class="form-control col-sm-3" name="password2" placeholder="Confirmer le mot de passe *" required>
                        <br>
                    </td>
                </tr>
            </table>

            <input style="cursor: pointer;" type="submit" name="Modify" value="Changer">
            <br>
            <br>
        </form>
        <br>
    </div>

    <!-- Chargement javascript -->
    <!-- js pour bootstrap : jquery + bundle contenant popper entre autres -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
	<br>
    <?php
        if(isset($_POST['Modify']))
        {
            $problem = 0;

            require_once '../bdd-pdo.php';
            try
            {
                $cnx = getConnexion();
                $sql = 'Select * from clients where idClient = :c';
                $stmt = $cnx->prepare($sql);
                $stmt->execute(array('c' => $_SESSION['Client']));
            }
            catch(PDOException $e)
            {
                die('Erreur : '.$e->getMessage());
            }
            while($row = $stmt->fetch())
            {
                if ($row['MotDePasse'] != $_POST['password0'])
                {
                    $problem += 1;
                    echo "Mot de passe incorrect !";
                }
            }
			if ($_POST['password1'] != $_POST['password2'])
            {
                $problem += 1;
                echo "les deux mots de passe ne correspondent pas !<br>";
            }
			if ($_POST['password0'] == $_POST['password1'])
            {
                $problem += 1;
                echo "le nouveau mot de passe doit être différent de l'ancien !<br>";
            }
            if ($problem == 0)
            {
                try
                {
                    require_once '../bdd-pdo.php';
                    
					$cnx = getConnexion();
					$sql = "UPDATE clients SET MotDePasse = :p WHERE idClient = :i";
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute(array('p' => $_POST['password1'], 'i' => $_SESSION['Client']));
					
					echo "Le mot de passe a bien été modifié";
                }
                catch(PDOException $e)
                {
                    die('Erreur : '.$e->getMessage());
                }
            }
        }
    ?>
</body>
<html>