<?php
    session_start();
    $id_session = session_id();
?>

<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
        echo "<title>".$_SESSION['Utilisateur']."</title>"; //Renvoie le pseudo dans le titre de la page
    ?>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<header  id="head-menu" style="height: 96px; padding : 10px;">
    <a href="../accueil.php" style="color: rgb(255, 255, 255);"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</a>
    <span style="float:right;">
        <span STYLE="padding:0 0 0 40px;"><a href="../panier\panier.php" style="color: white;"><img src="panier.png" alt="panier" width=64 height=64><span STYLE="padding:0 0 0 20px;">Panier</a></span>
    </span>
</header>

<body style="text-align: left">
    <div style="font-size:32px; margin-left: 10px;">
        <?php
            echo "Mon compte";
        ?>
    </div>
    <br>
    <br>
    <div style="margin-left: 10px;">
        <form method="post">
            <table style="width: 100%">
                <tr>
                    <td style="font-size:20px;">
                        Historique des commandes :
                        <br>
                        <br>
                    </td>
                </tr>
            </table>

            <table border="3px" style="margin-left: 20px; color: black; text-align: center;">
                <?php
                    require_once '../bdd-pdo.php';
                    try
                    {
                        $cnx = getConnexion();
                        $sql = "SELECT Cod.idCommande as uneCommande, S.libelle AS StatutCommande, DATE_FORMAT(T.dateCommande, '%d/%m/%Y') as 'DateCommande' FROM Commande Cod JOIN (SELECT C.idCommande, MAX(E.dateStatut) as dateCommande ,MAX(S.idStatut) As StatutActuel FROM Commande C JOIN Etat E ON E.idCommande = C.idCommande JOIN Statut S ON E.idStatut = S.idStatut GROUP BY C.idCommande) T ON Cod.idCommande = T.idCommande JOIN Statut S ON T.StatutActuel = S.idStatut JOIN Clients Cl ON Cl.idClient = Cod.idClient WHERE mail = :m ORDER BY Cod.idCommande DESC";
						$stmt = $cnx->prepare($sql);
                        $stmt->execute(array('m' => $_SESSION['Mail']));
                    }
                    catch(PDOException $e)
                    {
                        die('Erreur : '.$e->getMessage());
                    }
                    $html = '<tr><th width="100px">Numéro de commande</th><th width="900px">Contenu</th><th width="200px">Statut Actuel</th><th width="200px">Date de commande</th></tr>';
                    while($row = $stmt->fetch()) //Renvoie toutes les commandes
                    {	
						try
						{
							$cnx2 = getConnexion();
							$sql2 = "Select * from commande Cod JOIN detailscmds D ON D.idCommande = Cod.idCommande JOIN Composants Cop ON Cop.idComposants = D.idComposants where D.idCommande = :c";
							$stmt2 = $cnx->prepare($sql2);
							$stmt2->execute(array('c' => $row['uneCommande']));
						}
						catch(PDOException $e)
						{
							die('Erreur : '.$e->getMessage());
						}
						$html .= '<tr><td>'.$row["uneCommande"].'</td><td>';
						while($row2 = $stmt2->fetch()) //Renvoie les articles de chaque commandes
						{
							$html .= $row2["designation"].'  (x '.$row2["qteCommandee"].')<br>';
						}
                        $html .= '</td><td>'.$row["StatutCommande"].'</td><td>'.$row["DateCommande"].'</td></tr>';
                    }
                    echo $html;
                ?>
            </table>
            <br>
            <br>
            <br>
            <?php
                require_once '../bdd-pdo.php';
                try
                {
                    $cnx = getConnexion();
                    $sql = "Select * from Clients where mail = '".$_SESSION['Mail']."'"; //
                    $stmt = $cnx->prepare($sql);
                    $stmt->execute();
                }
                catch(PDOException $e)
                {
                    die('Erreur : '.$e->getMessage());
                }
                while($row = $stmt->fetch())
                {
                    if ($row['admin'] == "OUI")
                    {
                        $html = '<textarea type="textarea" class="form-control col-sm-3" name="Message" placeholder="Mon message *" style="height: 260px;" required></textarea><br><input style="cursor: pointer;" type="submit" name="Send" value="Envoyer">';
                        echo $html;
                    }
                }
            ?>
        </form>
        <br>
        <form method="post">
            <input style="cursor: pointer;" type="submit" name="Disconnect" value="Se déconnecter">
        </form>
		<br>
		<form method="post">
            <input style="cursor: pointer;" type="submit" name="Info" value="Mes informations">
        </form>
		<br>
		<form method="post">
            <input style="cursor: pointer;" type="submit" name="Password" value="Changer mon mot de passe">
        </form>
    </div>

    <!-- Chargement javascript -->
    <!-- js pour bootstrap : jquery + bundle contenant popper entre autres -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>

    <?php
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\Exception;
	
        if(isset($_POST['Disconnect']))
        {
            session_destroy();
            header("Location: ../accueil.php");
        }        
		
		if(isset($_POST['Info']))
        {
            header("Location: informations.php");
        }
		
		if(isset($_POST['Password']))
        {
            header("Location: motdepasse.php");
        }
        
        if(isset($_POST['Send']))
        {
            try
            {
				require_once '../bdd-pdo.php';
				try
				{
					$cnx = getConnexion();
					$sql = "Select * from clients where admin = 'NON'";
					$stmt = $cnx->prepare($sql);
					$stmt->execute();
				}
				catch(PDOException $e)
				{
					die('Erreur : '.$e->getMessage());
				}
			
					require 'PHPMailer/src/Exception.php';
					require 'PHPMailer/src/PHPMailer.php';
					require 'PHPMailer/src/SMTP.php';

					$mail = new PHPMailer();
					$mail->CharSet = 'UTF-8'; //Format d'encodage à utiliser pour les caractères
					$mail->IsSMTP();
					$mail->Host = 'smtp.laposte.net';               //Adresse IP ou DNS du serveur SMTP
					$mail->Port = 465;                          //Port TCP du serveur SMTP
					$mail->SMTPAuth = 1;                        //Utiliser l'identification

					if($mail->SMTPAuth)
					{
					   $mail->SMTPSecure = 'ssl';               //Protocole de sécurisation des échanges avec le SMTP
					   $mail->Username   =  'er.terrien@laposte.net';   //Adresse email à utiliser
					   $mail->Password   =  'Laposte34000!';         //Mot de passe de l'adresse email à utiliser
					}
					$mail->smtpConnect();

					$mail->From       = 'er.terrien@laposte.net' ;                //L'email à afficher pour l'envoi
					$mail->FromName = 'Admin';			//L'alias à afficher pour l'envoi

					$mail->Subject    =  "Message de l'administrateur";                      //Le sujet du mail
					$mail->WordWrap   = 50; 			                   //Nombre de caracteres pour le retour a la ligne automatique
					$mail->Body = $_POST['Message']; 	       //Texte brut
					$mail->IsHTML(false); 
				
				while($row = $stmt->fetch())
				{				
					$mail->AddAddress($row['mail'],$row['pseudo']);
				}

				if (!$mail->send())
				{
					echo '<div style="margin-left: 20px; color: rgb(192, 0, 0); font-weight: bold; font-size:24px;">Il y a eu un problème avec le message';
				}
				else
				{
					echo '<div style="margin-left: 20px; color: rgb(0, 192, 0); font-weight: bold; font-size:24px;">Le message a bien été envoyé.';
				}
            }

            catch(Exception $e)
            {
                echo '<div style="margin-left: 20px; color: rgb(192, 0, 0); font-weight: bold; font-size:24px;">Il y a eu un problème avec le message';
            }
        }
    ?>
</body>
<html>