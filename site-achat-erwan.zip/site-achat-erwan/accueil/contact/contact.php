<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Contact</title>

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,900" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="styles.css" />

</head>

<body style="background-color: rgb(192, 192, 192);">
    <header id="head-menu" style="height: 96px;">
        <div style="margin-top: 10px; margin-left: 10px;">
            <a href="../accueil.php" style="color: rgb(255, 255, 255); margin-top: 20px;"><img src="accueil.png" alt="accueil" width=64 height=64><span STYLE="padding:0 0 0 20px;">Retour boutique</span></a>
        </div>
    </header>
    <cmd style="font-size:32px; margin-left: 20px; color: black;">
        Nous contacter
    </cmd>
    <br>
    <br>
    <form method="post">
    <div style="margin-left: 20px; width:4000px;">
        <input type="text" class="form-control col-sm-3" name="Nom" placeholder="Nom *" required>
        <input type="text" class="form-control col-sm-3" name="Prenom" placeholder="Prénom *" required>
        <input type="mail" class="form-control col-sm-3" name="Email" placeholder="Adresse Mail *" required>
        <input type="text" class="form-control col-sm-3" name="Sujet" placeholder="Sujet *" required>
        <br>
        <textarea type="textarea" class="form-control col-sm-3" name="Message" placeholder="Mon message" style="height: 260px;" required></textarea>
        <br>
        <input style="cursor: pointer;" type="submit" name="Send" value="Envoyer">
        <br>
        <br>
        * Champs obligatoires
    </div>
    </form>
    <br>
    <?php
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\Exception;
        if(isset($_POST['Send']))
        {
            try
            {
				require 'PHPMailer/src/Exception.php';
				require 'PHPMailer/src/PHPMailer.php';
				require 'PHPMailer/src/SMTP.php';
				
				$mail = new PHPMailer();
				$mail->CharSet = 'UTF-8'; //Format d'encodage à utiliser pour les caractères
				$mail->IsSMTP();
				$mail->Host = 'smtp.laposte.net';               //Adresse IP ou DNS du serveur SMTP
				$mail->Port = 465;                          //Port TCP du serveur SMTP
				$mail->SMTPAuth = 1;                        //Utiliser l'identification

				if($mail->SMTPAuth)
				{
				   $mail->SMTPSecure = 'ssl';               //Protocole de sécurisation des échanges avec le SMTP
				   $mail->Username   =  'er.terrien@laposte.net';   //Adresse email à utiliser
				   $mail->Password   =  'Laposte34000!';         //Mot de passe de l'adresse email à utiliser
				}
				$mail->smtpConnect();
				
				$mail->From     =  'er.terrien@laposte.net';                //L'email à afficher pour l'envoi
				$mail->FromName = $_POST['Prenom'].' '.$_POST['Nom'];			//L'alias à afficher pour l'envoi
				
				$mail->Subject    =  $_POST['Sujet'];                      //Le sujet du mail
				$mail->WordWrap   = 50; 			                   //Nombre de caracteres pour le retour a la ligne automatique
				$mail->Body = $_POST['Email']."\n".$_POST['Message']; 	       //Texte brut
				$mail->IsHTML(false);  
				
				$mail->AddAddress('er.terrien@laposte.net','Erwan');

				if (!$mail->send())
				{
					echo '<div style="margin-left: 20px; color: rgb(192, 0, 0); font-weight: bold; font-size:24px;">Il y a eu un problème avec le message';
				}
				else
				{
					echo '<div style="margin-left: 20px; color: rgb(0, 192, 0); font-weight: bold; font-size:24px;">Le message a bien été envoyé.';
				}
            }

            catch(Exception $e)
            {
                echo '<div style="margin-left: 20px; color: rgb(192, 0, 0); font-weight: bold; font-size:24px;">Il y a eu un problème avec le message';
            }
        }
    ?>
</body>
</html>