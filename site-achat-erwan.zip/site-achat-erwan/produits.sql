DROP DATABASE IF EXISTS produits;
CREATE DATABASE IF NOT EXISTS produits;
USE produits;

DROP USER IF EXISTS 'G.Menvussat'@'localhost';

                CREATE TABLE IF NOT EXISTS Marque (idMarque int NOT NULL AUTO_INCREMENT, libelle varchar(50), PRIMARY KEY (idMarque));
				CREATE TABLE IF NOT EXISTS Categorie (idCategorie int NOT NULL AUTO_INCREMENT, libelle varchar(50), PRIMARY KEY (idCategorie));
				CREATE TABLE IF NOT EXISTS Adresse (idAdresse int  NOT NULL AUTO_INCREMENT, libelle varchar(255), ville varchar(255), codePostal char(5), PRIMARY KEY (idAdresse));
				CREATE TABLE IF NOT EXISTS Clients (idClient int NOT NULL AUTO_INCREMENT, nom varchar(64), prenom varchar(64), mail varchar (255), pseudo varchar (64), MotDePasse varchar(64), NumTel varchar(14), admin char(3), idAdresse int, PRIMARY KEY (idClient), FOREIGN KEY (idAdresse) REFERENCES Adresse (idAdresse));
				CREATE TABLE IF NOT EXISTS Commande (idCommande int NOT NULL AUTO_INCREMENT, idAdresse int, idClient int, PRIMARY KEY (idCommande), FOREIGN KEY (idClient) REFERENCES Clients (idClient), FOREIGN KEY (idAdresse) REFERENCES Adresse (idAdresse));

                CREATE TABLE IF NOT EXISTS Composants (idComposants int NOT NULL AUTO_INCREMENT, designation varchar(50), idMarque int, FOREIGN KEY (idMarque) REFERENCES Composants (idMarque), prixUnitaire decimal(10,2), qtestock int, seuilAlerte int, idCategorie int, FOREIGN KEY (idCategorie) REFERENCES Composants (idCategorie), PRIMARY KEY (idComposants));
				CREATE TABLE IF NOT EXISTS DetailsCmds (idCommande int, idComposants int, qteCommandee int, FOREIGN KEY (idCommande) REFERENCES Commande (idCommande), FOREIGN KEY (idComposants) REFERENCES Composants (idComposants));
				CREATE TABLE IF NOT EXISTS Statut (idStatut int NOT NULL AUTO_INCREMENT, libelle varchar(50), PRIMARY KEY (idStatut));
				CREATE TABLE IF NOT EXISTS Etat (idCommande int, idStatut int, dateStatut date, FOREIGN KEY (idCommande) REFERENCES Commande (idCommande), FOREIGN KEY (idStatut) REFERENCES Statut (idStatut));

				CREATE TABLE IF NOT EXISTS Resolution (idResolution int NOT NULL AUTO_INCREMENT, longueur smallint, largeur smallint, PRIMARY KEY (idResolution));
				CREATE TABLE IF NOT EXISTS TailleEcran (idTaille int NOT NULL AUTO_INCREMENT, taille Decimal(10,1), PRIMARY KEY (idTaille));
                CREATE TABLE IF NOT EXISTS Frequence (idFrequence int NOT NULL AUTO_INCREMENT, frequence smallint , PRIMARY KEY (idFrequence));
				CREATE TABLE IF NOT EXISTS ChassisEcran (idComposants int, idTaille int, idResolution int, idFrequence int, FOREIGN KEY (idComposants) REFERENCES Composants (idComposants), FOREIGN KEY (idTaille) REFERENCES TailleEcran (idTaille), FOREIGN KEY (idResolution) REFERENCES Resolution (idResolution), FOREIGN KEY (idFrequence) REFERENCES Frequence (idFrequence));

				CREATE TABLE IF NOT EXISTS Processeur_Type (idType int NOT NULL AUTO_INCREMENT, libelle varchar(50), PRIMARY KEY (idType));
                CREATE TABLE IF NOT EXISTS Processeur (idComposants int, idType int, PRIMARY KEY (idComposants), FOREIGN KEY (idType) REFERENCES Processeur_Type (idType));
                
				CREATE TABLE IF NOT EXISTS RAM_Capacite (idCapacite int NOT NULL AUTO_INCREMENT, capaciteRAM smallint, PRIMARY KEY (idCapacite));
                CREATE TABLE IF NOT EXISTS RAM_Frequence (idFrequence int NOT NULL AUTO_INCREMENT, frequence smallint , PRIMARY KEY (idFrequence));
                CREATE TABLE IF NOT EXISTS RAM_Latence (idLatence int NOT NULL AUTO_INCREMENT, tempsLatence smallint , PRIMARY KEY (idLatence));
				CREATE TABLE IF NOT EXISTS RAM (idComposants int, idCapacite int, idFrequence int, idLatence int, FOREIGN KEY (idComposants) REFERENCES Composants (idComposants), FOREIGN KEY (idCapacite) REFERENCES RAM_Capacite (idCapacite), FOREIGN KEY (idFrequence) REFERENCES RAM_Frequence (idFrequence), FOREIGN KEY (idLatence) REFERENCES RAM_Latence (idLatence));

				CREATE TABLE IF NOT EXISTS DisqueDur_Forme (idForme int NOT NULL AUTO_INCREMENT, forme varchar(4),  PRIMARY KEY (idForme));
				CREATE TABLE IF NOT EXISTS DisqueDur_SSD (idSSD int NOT NULL AUTO_INCREMENT, SSD varchar(3),  PRIMARY KEY (idSSD));
				CREATE TABLE IF NOT EXISTS DisqueDur_Capacite (idCapacite int NOT NULL AUTO_INCREMENT, capacite smallint,  PRIMARY KEY (idCapacite));
                CREATE TABLE IF NOT EXISTS DisqueDur (idComposants int, idSSD int, idCapacite int, idForme int, FOREIGN KEY (idComposants) REFERENCES Composants (idComposants), FOREIGN KEY (idCapacite) REFERENCES DisqueDur_Capacite (idCapacite), FOREIGN KEY (idSSD) REFERENCES DisqueDur_SSD (idSSD), FOREIGN KEY (idForme) REFERENCES DisqueDur_Forme (idForme));

                CREATE TABLE IF NOT EXISTS Panier (idComposants int, quantite smallint, PRIMARY KEY (idComposants), FOREIGN KEY (idComposants) REFERENCES Composants (idComposants));

				INSERT INTO Clients (nom, prenom, mail, pseudo, MotDePasse, NumTel, admin, idAdresse) VALUES ('Menvussat', 'Gérard', 'gerard.menvussat@mail.com', 'Rarissime', 'S!0M€rm02_34', '0404040404', 'OUI', null);

				INSERT INTO Categorie (libelle) VALUES ('Châssis'), ('Processeur'), ('RAM'), ('Stockage');

				INSERT INTO Marque (libelle) VALUES ('Nous'), ('Intel'), ('AMD'), ('Nvidia'), ('Corsair'), ('GSkill'), ('HyperX'), ('Kingston'), ('Samsung'), ('Seagate'), ('Toshiba'), ('Western Digital');


				INSERT INTO Composants (designation, idMarque, prixUnitaire, qtestock, seuilAlerte, idCategorie) VALUES 
				('Electra 100 13" 1920x1080 60Hz', 1,360,30,2,1),
				('Hydra 200 15" 2560x1440 144Hz', 1,640,30,2,1),
				('Pyros 300 17" 3200x1800 240Hz', 1,1200,30,2,1),
				('Atlas 400 20" 3840x2160 360Hz', 1,2300,30,2,1),

				('Core_i3-10100F', 2,38,30,2,2),
                ('Core_i5-10600K', 2,50,20,2,2),
                ('Core_i7-10700K', 2,94,10,2,2),
                ('Core_i9-10850K', 2,108,5,2,2),
                ('Ryzen_5_2600_Wraith_Stealth_Edition', 3,35,30,2,2),
                ('Ryzen_5_3600_Wraith_Stealth_Edition', 3,45,20,2,2),
                ('Ryzen_7_3700X_Wraith_Prism_cooler', 3,85,10,2,2),
                ('RYZEN_9_5900X', 3,70,95,2,2),
				('GeForce_GTX_1650', 4,20,30,2,2),
                ('GeForce_GTX_1650_Super', 4,25,27,2,2),
                ('GeForce_GTX_1660', 4,30,25,2,2),
                ('GeForce_GTX_1660_Super', 4,32,20,2,2),
                ('GeForce_GTX_1660_ti', 4,35,25,2,2),
                ('GeForce_RTX_3050', 4,175,15,2,2),
                ('GeForce_RTX_3060', 4,180,15,2,2),
                ('GeForce_RTX_3070', 4,185,12,2,2),
                ('GeForce_RTX_3080', 4,190,10,2,2),
                ('Radeon_RX_5300M', 3,20,30,2,2),
                ('Radeon_RX_5500M', 3,25,27,2,2),
                ('Radeon_RX_5600M', 3,27,26,2,2),
                ('Radeon_RX_5700M', 3,35,25,2,2),
                ('Radeon_RX_6600S', 3,40,23,2,2),
                ('Radeon_RX_6700S', 3,42,22,2,2),
                ('Radeon_RX_6800S', 3,45,20,2,2),
                ('Radeon_RX_6300M', 3,50,19,2,2),
                ('Radeon_RX_6500M', 3,55,17,2,2),
                ('Radeon_RX_6600M', 3,57,15,2,2),
                ('Radeon_RX_6650M', 3,60,14,2,2),
                ('Radeon_RX_6650M_XT', 3,62,12,2,2),
                ('Radeon_RX_6700M', 3,65,10,2,2),
                ('Radeon_RX_6800M', 3,70,8,2,2),
                ('Radeon_RX_6850M', 3,80,6,2,2),

                ('ValueSelect_SO-DIMM_DDR4_4_Go_2133_MHz_CAS_15', 5, 4.99, 30, 4, 3),
                ('ValueSelect_SO-DIMM_DDR4_4_Go_2400_MHz_CAS_16', 5, 4.99,30, 4,3),
                ('ValueSelect_SO-DIMM_-_8_Go_-_DDR4_3200_MHz_-_CL22', 5, 34.99,30, 4,3),
                ('ValueSelect_SO-DIMM_DDR4_8_Go_2133_MHz_CAS_15', 5, 14.99,30, 8,3),
                ('ValueSelect_SO-DIMM_DDR4_8_Go_2400_MHz_CAS_16', 5, 19.99,30, 8,3),
                ('ValueSelect_SO-DIMM_-_8_Go_-_DDR4_2666_MHz_-_CL18', 5, 29.99,30, 8,3),
                ('ValueSelect_SO-DIMM_-_16_Go_-_DDR4_2666_MHz_-_CL18', 5, 59.99,30, 16,3),
                ('ValueSelect_SO-DIMM_DDR4_16_Go_2133_MHz_CAS_15', 5, 39.99,30, 16,3),
                ('ValueSelect_SO-DIMM_DDR4_16_Go_2400_MHz_CAS_16', 5, 44.99,30, 16,3),
                ('ValueSelect_SO-DIMM_-_16_Go_-_DDR4_3000_MHz_-_CL18', 5, 52.99,30, 16,3),
                ('Vengeance_SODIMM_-_16_Go_-_DDR4_3200_MHz_-_CL22', 5, 59.99,30, 16,3),
                ('ValueSelect_SO-DIMM_DDR4_32_Go_2666_MHz_CAS_18', 5, 79.99,30, 32,3),
                ('Ripjaws_SO-DIMM_DDR4_4_Go_2133_MHz_CAS_15', 6, 0,30, 4,3),
                ('Ripjaws_SO-DIMM_DDR4_4_Go_2666_MHz_CAS_16', 6, 9.99,30, 4,3),
                ('Ripjaws_SO-DIMM_DDR4_4_Go_2400_MHz_CAS_16', 6, 4.99,30, 4,3),
                ('Ripjaws_SO-DIMM_DDR4_8_Go_2133_MHz_CAS_15', 6, 14.99,30, 8,3),
                ('Ripjaws_SO-DIMM_DDR4_8_Go_2400_MHz_CAS_16', 6, 19.99,30, 8,3),
                ('Ripjaws_SO-DIMM_DDR4_8_Go_2666_MHz_CAS_19', 6, 29.99,30, 8,3),
                ('Ripjaws_SO-DIMM_-_8_Go_-_DDR4_3200_MHz_-_CL22', 6, 24.99,30, 8,3),
                ('Ripjaws_SO-DIMM_DDR4_8_Go_3200_MHz_CAS_18', 6, 24.99,30, 8,3),
                ('Ripjaws_SO-DIMM_DDR4_16_Go_2666_MHz_CAS_19', 6, 44.99,30, 16,3),
                ('Ripjaws_SO-DIMM_DDR4_16_Go_2400_MHz_CAS_16', 6, 39.99,30, 16,3),
                ('Ripjaws_SO-DIMM_-_16_Go_-_DDR4_3200_MHz_-_CL22', 6, 49.99,30, 16,3),
                ('Ripjaws_SO-DIMM_DDR4_16_Go_2133_MHz_CAS_15', 6, 29.99,30, 16,3),
                ('Ripjaws_SO-DIMM_-_32_Go_-_DDR4_3200_MHz_-_CL22', 6, 89.99,30, 32,3),
                ('Ripjaws_SO-DIMM_DDR4_16_Go_3200_MHz_CAS_18', 6, 49.99,30, 16,3),
                ('Ripjaws_SO-DIMM_DDR4_32_Go_2666_MHz_CAS_18', 6, 84.99,30, 32,3),
                ('HyperX_16_Go_DDR4_2666_MHz_CL15_Impact_SO-DIMM', 7, 59.99,30, 16,3),
                ('Fury_Impact_SO-DIMM_-_8_Go_-_DDR4_2933_MHz_-_CL17', 8, 32.99,30, 8,3),
                ('Fury_Impact_SO-DIMM_-_4_Go_-_DDR3_1600_MHz_-_CL9', 8, 4.99,30, 4,3),
                ('Fury_Impact_SO-DIMM_-_8_Go_-_DDR4_2666_MHz_-_CL15', 8, 24.99,30, 8,3),
                ('Fury_Impact_SO-DIMM_-_8_Go_-_DDR4_3200_MHz_-_CL20', 8, 29.99,30, 8,3),
                ('Fury_Impact_SO-DIMM_-_16_Go_-_DDR4_3200_MHz_-_CL20', 8, 49.99,30, 16,3),
                ('Fury_Impact_SO-DIMM_-_8_Go_-_DDR3_1600_MHz_-_CL9', 8, 18.99,30, 16,3),
                ('Fury_Impact_SO-DIMM_-_16_Go_-_DDR4_2933_MHz_-_CL17', 8, 47.99,30, 16,3),
                ('Fury_Impact_SO-DIMM_-_16_Go_-_DDR4_3200_MHz_-_CL20', 8, 49.99,30, 16,3),
                ('Fury_Impact_SO-DIMM_-_32_Go_-_DDR4_2666_MHz_-_CL16', 8, 79.99,30, 32,3),
                ('Fury_Impact_SO-DIMM_-_32_Go_-_DDR4_2933_MHz_-_CL16', 8, 84.99,30, 32,3),
                ('Fury_Impact_SO-DIMM_-_32_Go_-_DDR4_3200_MHz_-_CL16', 8, 89.99,30, 32,3),

                ('980_-_500_Go', 9, 29.99, 30, 5,4),
                ('860_EVO_M.2_-_500_Go', 9, 35.99, 30, 5,4),
                ('980_-_5_Go', 9, 59.99, 30, 5,4),
                ('970_EVO_Plus_-_500_Go', 9, 35.99, 30, 5,4),
                ('860_EVO_M.2_-_500_Go', 9, 59.99, 30, 5,4),
                ('970_EVO_-_500_Go', 9, 64.99, 30, 5,4),
                ('970_EVO_Plus_-_500_Go', 9, 69.99, 30, 5,4),
                ('980_Pro_-_500_Go', 9, 39.99, 30, 5,4),
                ('980_-_1_To', 9, 124.99, 30, 5,4),
                ('970_EVO_Plus_-_1_To', 9, 135.99, 30, 5,4),
                ('860_EVO_M.2_-_1_To', 9, 149.99, 30, 5,4),
                ('980_Pro_-_500_Go', 9, 54.99, 30, 5,4),
                ('970_Pro_-_512_Go', 9, 59.99, 30, 512,4),
                ('980_Pro_-_1_To', 9, 119.99, 30, 5,4),
                ('980_Pro_HS_-_1_To', 9, 129.99, 30, 5,4),
                ('970_EVO_Plus_-_2_To', 9, 279.99, 30, 5,4),
                ('970_PRO_-_1_To', 9, 139.99, 30, 5,4),
                ('980_Pro_-_2_To', 9, 249.99, 30, 5,4),
                ('980_Pro_HS_-_2_To', 9, 279.99, 30, 5,4),
                ('BarraCuda_Q5_-_500_Go', 10, 59.99, 30, 5,4),
                ('IronWolf_510_-_500_Go', 10, 29.99, 30, 5,4),
                ('IronWolf_510_-_500_Go', 10, 49.99, 30, 5,4),
                ('FireCuda_520_-_500_Go', 10, 54.99, 30, 5,4),
                ('BarraCuda_Q5_-_1_To', 10, 119.99, 30, 5,4),
                ('FireCuda_530_-_500_Go', 10, 56.99, 30, 5,4),
                ('FireCuda_510_-_1_To', 10, 99.99, 30, 5,4),
                ('FireCuda_520_-_1_To', 10, 104.99, 30, 5,4),
                ('FireCuda_510_-_500_Go', 10, 94.99, 30, 5,4),
                ('FireCuda_530_-_1_To', 10, 119.99, 30, 5,4),
                ('BarraCuda_Q5_-_2_To', 10, 219.99, 30, 5,4),
                ('IronWolf_510_-_1.92_To', 10, 224.99, 30, 5,4),
                ('FireCuda_530_-_2_To', 10, 249.99, 30, 5,4),
                ('Green_-_500_Go', 12, 14.99, 30, 5,4),
                ('Green_-_500_Go', 12, 24.99, 30, 5,4),
                ('Blue_M.2_-_500_Go', 12, 29.99, 30, 5,4),
                ('Blue_SN570_-_500_Go', 12, 29.99, 30, 5,4),
                ('Green_SN35_-_500_Go', 12, 24.99, 30, 5,4),
                ('Blue_SN570_-_500_Go', 12, 54.99, 30, 5,4),
                ('Green_SN35_-_500_Go', 12, 49.99, 30, 5,4),
                ('Green_-_5_Go', 12, 49.99, 30, 5,4),
                ('BLACK_SN75_-_500_Go', 12, 29.99, 30, 5,4),
                ('Blue_M.2_-_500_Go', 12, 54.99, 30, 5,4),
                ('BLACK_SN75_SE_-_500_Go', 12, 29.99, 30, 5,4),
                ('Red_SA5_M.2_-_500_Go', 12, 59.99, 30, 5,4),
                ('BLACK_SN75_SE_-_500_Go', 12, 61.99, 30, 5,4),
                ('Green_SN35_-_1_To', 12, 99.99, 30, 5,4),
                ('Blue_M.2_-_1_To', 12, 109.99, 30, 5,4),
                ('Blue_SN570_-_1_To', 12, 119.99, 30, 5,4),
                ('BLACK_SN75_EK_-_500_Go', 12, 59.99, 30, 5,4),
                ('Red_SN700_-_5_Go', 12, 69.99, 30, 5,4),
                ('BLACK_SN85_-_500_Go', 12, 64.99, 30, 5,4),
                ('BLACK_SN75_-_1_To', 12, 124.99, 30, 5,4),
                ('BLACK_SN75_SE_-_1_To', 12, 129.99, 30, 5,4),
                ('BLACK_SN75_SE_Battlefield_2042_-_500_Go', 12, 75.99, 30, 5,4),
                ('BLACK_SN85_HE_-_500_Go', 12, 69.99, 30, 5,4),
                ('BLACK_SN85_-_1_To', 12, 135.99, 30, 5,4),
                ('Blue_SN570_-_2_To', 12, 239.99, 30, 5,4),
                ('BLACK_SN75_SE_Battlefield_2042_-_1_To', 12, 149.99, 30, 5,4),
                ('Red_SN700_-_1_To', 12, 129.99, 30, 5,4),
                ('BLACK_SN85_HE_-_500_Go', 12, 134.99, 30, 5,4),
                ('Green_SN35_-_2_To', 12, 199.99, 30, 5,4),
                ('Blue_M.2_-_2_To', 12, 219.99, 30, 5,4),
                ('Red_SA5_M.2_-_2_To', 12, 229.99, 30, 5,4),
                ('BLACK_SN75_-_2_To', 12, 249.99, 30, 5,4),
                ('BLACK_SN75_EK_-_2_To', 12, 259.99, 30, 5,4),
                ('BLACK_SN85_-_2_To', 12, 264.99, 30, 5,4),
                ('Red_SN700_M.2_-_2_To', 12, 249.99, 30, 5,4),
                ('BLACK_SN85_HE_-_2_To', 12, 279.99, 30, 5,4),
                ('Red_SN700_M.2_-_4_To', 12, 499.99, 30, 5,4),
                ('BarraCuda_Mobile_-_500_Go_-_5_Mo', 10, 14.99, 30, 5,4),
                ('BarraCuda_Mobile_-_1_To_-_5_Mo', 10, 24.99, 30, 5,4),
                ('BarraCuda_Mobile_Pro_-_1_To_-_5_Mo', 10, 29.99, 30, 5,4),
                ('IronWolf_125_-_500_Go', 10, 29.99, 30, 5,4),
                ('Barracuda_Q1_-_500_Go', 10, 49.99, 30, 5,4),
                ('BarraCuda_Mobile_-_2_To_-_5_Mo', 10, 59.99, 30, 5,4),
                ('IronWolf_125_-_500_Go', 10, 59.99, 30, 5,4),
                ('BarraCuda_Mobile_-_4_To_-_5_Mo', 10, 119.99, 30, 5,4),
                ('IronWolf_125_-_1_To', 10, 119.99, 30, 5,4),
                ('BarraCuda_Mobile_-_500_To_-_5_Mo', 10, 149.99, 30, 5,4),
                ('IronWolf_125_-_2_To', 10, 249.99, 30, 5,4),
                ('IronWolf_125_-_2_To', 10, 499.99, 30, 5,4),
                ('L200_-_1_To_-_5_Mo', 11, 29.99, 30, 5,4),
                ('L200_-_2_To_-_5_Mo', 11, 59.99, 30, 5,4),
                ('Green_-_500_Go', 12, 14.99, 30, 5,4),
                ('Green_-_500_Go', 12, 28.99, 30, 5,4),
                ('Blue_Mobile_-_500_Go_-_5_Mo', 12, 14.99, 30, 5,4),
                ('Blue_-_5_Go', 12, 29.99, 30, 5,4),
                ('Blue_Mobile_-_1_To_-_5_Mo', 12, 29.99, 30, 5,4),
                ('Green_-_5_Go', 12, 56.99, 30, 5,4),
                ('Blue_-_5_Go', 12, 54.99, 30, 5,4),
                ('Black_Mobile_-_1_To_-_5_Mo', 12, 34.99, 30, 5,4),
                ('Red_SA5_-_5_Go', 12, 59.99, 30, 5,4),
                ('Red_Plus_Mobile_-_1_To_-_16_Mo', 12, 30.99, 30, 5,4),
                ('Black_Mobile_-_1_To_-_5_Mo', 12, 54.99, 30, 5,4),
                ('Green_-_1_To', 12, 109.99, 30, 5,4),
                ('Blue_-_1_To', 12, 114.99, 30, 5,4),
                ('Red_SA5_-_1_To', 12, 119.99, 30, 5,4),
                ('Green_-_2_To', 12, 219.99, 30, 5,4),
                ('Blue_-_2_To', 12, 229.99, 30, 5,4),
                ('Red_SA5_-_2_To', 12, 249.99, 30, 5,4),
                ('Blue_-_4_To', 12, 479.99, 30, 5,4),
                ('Red_SA5_-_4_To', 12, 499.99, 30, 5,4);

				INSERT INTO TailleEcran (taille) VALUES (13), (15), (17), (20);
				INSERT INTO Resolution (longueur, largeur) VALUES (1920,1080), (2560,1440), (3200,1800), (3840,2160);
				INSERT INTO Frequence (frequence) VALUES (60), (144), (240), (360);
				INSERT INTO ChassisEcran (idComposants, idTaille, idResolution, idFrequence) VALUES
				(1,1,1,1),
				(2,2,2,2),
				(3,3,3,3),
				(4,4,4,4);


				INSERT INTO Processeur_Type (libelle) VALUES ('CPU'), ('GPU');

				INSERT INTO Processeur (idComposants ,idType) VALUES
				(5,1),
				(6,1),
				(7,1),
				(8,1),
				(9,1),
				(10,1),
				(11,1),
				(12,1),
				(13,2),
				(14,2),
				(15,2),
				(16,2),
				(17,2),
				(18,2),
				(19,2),
				(20,2),
				(21,2),
				(22,2),
				(23,2),
				(24,2),
				(25,2),
				(26,2),
				(27,2),
				(28,2),
				(29,2),
				(30,2),
				(31,2),
				(32,2),
				(33,2),
				(34,2),
				(35,2),
				(36,2);



				INSERT INTO RAM_Capacite (capaciteRAM) VALUES (4), (8), (16), (32);
                INSERT INTO RAM_Frequence (frequence) VALUES (1600), (2133), (2400), (2666), (2933), (3000), (3200);
                INSERT INTO RAM_Latence (tempsLatence) VALUES (9), (15), (16), (17), (18), (19), (20), (22);

				INSERT INTO RAM (idComposants, idCapacite, idFrequence, idLatence) VALUES
				(37,1, 2, 2),
				(38,1, 3, 3),
				(39,1, 6, 8),
				(40,2, 2, 2),
				(41,2, 3, 3),
				(42,2, 3, 5),
				(43,3, 3, 5),
				(44,3, 2, 2),
				(45,3, 3, 2),
				(46,3, 5, 5),
				(47,3, 6, 8),
				(48,4, 3, 5),
				(49,1, 2, 2),
				(50,1, 3, 3),
				(51,1, 3, 3),
				(52,2, 2, 2),
				(53,2, 3, 3),
				(54,2, 3, 6),
				(55,2, 6, 8),
				(56,2, 6, 5),
				(57,3, 3, 6),
				(58,3, 3, 3),
				(59,3, 6, 8),
				(60,4, 2, 2),
				(61,3, 6, 8),
				(62,4, 3, 5),
				(63,3, 3, 2),
				(64,4, 6, 5),
				(65,3, 3, 5),
				(66,2, 4, 4),
				(67,1, 1, 1),
				(68,2, 3, 2),
				(69,2, 6, 7),
				(70,3, 6, 7),
				(71,2, 1, 1),
				(72,3, 4, 4),
				(73,3, 6, 7),
				(74,4, 3, 3),
				(75,4, 4, 3),
				(76,4, 6, 3);


				INSERT INTO DisqueDur_Forme (forme) VALUES ('M.2'), ('2.5');
				INSERT INTO DisqueDur_SSD (SSD) VALUES ('OUI'), ('NON');
				INSERT INTO DisqueDur_Capacite (capacite) VALUES (120), (240), (250), (480), (500), (512), (960), (1000), (1920), (2000), (4000);

				INSERT INTO DisqueDur (idComposants, idSSD, idCapacite, idForme) VALUES
				(77,1, 3, 1),
				(78,1, 5, 1),
				(79,1, 3, 1),
				(80,1, 5, 1),
				(81,1, 5, 1),
				(82,1, 5, 1),
				(83,1, 3, 1),
				(84,1, 7, 1),
				(85,1, 7, 1),
				(86,1, 7, 1),
				(87,1, 5, 1),
				(88,1, 6, 1),
				(89,1,7, 1),
				(90,1,7, 1),
				(91,1,8, 1),
				(92,1,7, 1),
				(93,1,8, 1),
				(94,1,8, 1),
				(95,1, 5, 1),
				(96,1,2, 1),
				(97,1,4, 1),
				(98,1, 5, 1),
				(99,1,7, 1),
				(100,1, 5, 1),
				(101,1,7, 1),
				(102,1,7, 1),
				(103,1,6, 1),
				(104,1,7, 1),
				(105,1,8, 1),
				(106,1,7, 1),
				(107,1,8, 1),
				(108,1,1, 1),
				(109,1,2, 1),
				(110,1,3, 1),
				(111,1,3, 1),
				(112,1,2, 1),
				(113,1, 5, 1),
				(114,1,4, 1),
				(115,1,4, 1),
				(116,1,3, 1),
				(117,1, 5, 1),
				(118,1,3, 1),
				(119,1, 5, 1),
				(120,1, 5, 1),
				(121,1,7, 1),
				(122,1,7, 1),
				(123,1,7, 1),
				(124,1, 5, 1),
				(125,1, 5, 1),
				(126,1, 5, 1),
				(127,1,7, 1),
				(128,1,7, 1),
				(129,1, 5, 1),
				(130,1, 5, 1),
				(131,1,7, 1),
				(132,1,8, 1),
				(133,1,7, 2),
				(134,1,7, 2),
				(135,1,7, 2),
				(136,1,8, 1),
				(137,1,8, 1),
				(138,1,8, 1),
				(139,1,8, 1),
				(140,1,8, 1),
				(141,1,8, 1),
				(142,1,8, 1),
				(143,1,8, 1),
				(144,1,9, 1),
				(145,2, 5, 2),
				(146,1,7, 2),
				(147,1,7, 2),
				(148,1,3, 2),
				(149,1,4, 2),
				(150,2,8, 2),
				(151,1, 5, 2),
				(152,2,9, 2),
				(153,1,7, 2),
				(154,2,5, 2),
				(155,1,7, 2),
				(156,1,7, 2),
				(157,2,7, 2),
				(158,2,8, 2),
				(159,1,1, 2),
				(160,1,2, 2),
				(161,1, 5, 2),
				(162,1,3, 2),
				(163,2,7, 2),
				(164,1,4, 2),
				(165,1, 5, 2),
				(166,2,7, 2),
				(167,1, 5, 1),
				(168,2,7, 2),
				(169,2,7, 2),
				(170,1,7, 2),
				(171,1,7, 2),
				(172,1,7, 2),
				(173,1,7, 2),
				(174,1,7, 2),
				(175,1,7, 2),
				(176,1,7, 2),
				(177,1,7, 2);


				INSERT INTO STATUT (libelle) VALUES
				('non validée'), ('en préparation'), ('prise en charge'), ('en cours d''acheminement'), ('livrée');
				
				INSERT INTO Adresse (libelle, ville, codePostal) VALUES ('Avenue des tests', 'Montpellier', '34000');
				INSERT INTO Adresse (libelle, ville, codePostal) VALUES ('Rue de la programmation', 'Nîmes', '30000');
				INSERT INTO Adresse (libelle, ville, codePostal) VALUES ('Lotissement des routeurs', 'Perpignan', '66000');
				
				INSERT INTO Commande (idAdresse, idClient) VALUES (1, 1), (1, 1);
				INSERT INTO Commande (idAdresse, idClient) VALUES (1, 1), (2, 1);
				INSERT INTO Commande (idAdresse, idClient) VALUES (3, 1), (2, 1);
				INSERT INTO Commande (idAdresse, idClient) VALUES (3, 1), (2, 1);
				
				INSERT INTO DetailsCmds VALUES (1, 1, 1), (1, 2, 1), (1, 3, 1), (2, 2, 1), (2, 4, 1), (2, 6, 1);
				
				INSERT INTO Etat VALUES (1, 1, '2023-01-11'), (1, 2, '2023-01-15'), (2, 1, '2023-01-02'), (2, 2, '2023-02-02'), (2, 3, '2023-02-02'), (2, 4, '2023-02-02'), (2, 5, '2023-03-02');

				INSERT INTO DetailsCmds VALUES (3, 52, 1), (3, 47, 1), (3, 15, 1), (4, 12, 1), (4, 96, 1), (4, 33, 1);
				INSERT INTO DetailsCmds VALUES (5, 52, 1), (5, 47, 1), (5, 15, 1), (6, 12, 1), (6, 96, 1), (6, 33, 1);
				INSERT INTO DetailsCmds VALUES (7, 52, 1), (7, 47, 1), (7, 15, 1), (8, 12, 1), (8, 96, 1), (8, 33, 1);

				INSERT INTO Etat VALUES (3, 1, '2023-01-13'), (3, 2, '2023-01-15'), (4, 1, '2023-01-20'), (4, 2, '2023-01-27'), (4, 3, '2023-01-02');
				INSERT INTO Etat VALUES (5, 1, '2023-02-2'), (6, 1, '2023-01-02'), (6, 2, '2023-01-05'), (6, 3, '2023-01-08'), (6, 4, '2023-01-15'), (6, 5, '2023-01-25');
				INSERT INTO Etat VALUES (7, 1, '2023-01-13'), (7, 2, '2023-01-15'), (8, 1, '2023-01-21'), (8, 2, '2023-01-30'), (8, 3, '2023-02-01');
				INSERT INTO Etat VALUES (1, 3, '2023-01-15'), (1, 4, '2023-01-25'), (1, 5, '2023-02-01');
				

				CREATE USER 'G.Menvussat'@'localhost' IDENTIFIED BY 'S!0M€rm02_34';
				GRANT SELECT ON `produits`.* TO 'G.Menvussat'@'localhost';
				GRANT UPDATE (`qtestock`, `seuilAlerte`) ON `produits`.`composants` TO 'G.Menvussat'@'localhost';