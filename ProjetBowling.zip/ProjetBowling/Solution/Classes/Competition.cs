﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Competition
    {
        /// <summary>
        /// Récupération compétition individuelle
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="nom"></param>
        /// <param name="dateCompetition"></param>
        /// <param name="engagement"></param>
        /// <param name="idCentre"></param>
        /// <param name="idNiveau"></param>
        /// <param name="idCategorie"></param>
        public Competition(int idCompetition, string nom, DateTime dateCompetition, decimal engagement, int idCentre, int idNiveau, int idCategorie)
        {
            this.IdCompetition = idCompetition;
            this.Nom = nom;
            this.DateCompetition = dateCompetition;
            this.Engagement = engagement;
            this.IdCentre = idCentre;
            this.IdNiveau = idNiveau;
            this.IdCategorie = idCategorie;
            this.leClassementIndividuel = new List<ClassementIndividuel>();
        }

        /// <summary>
        /// Ajout compétition individuelle
        /// </summary>
        /// <param name="nom"></param>
        /// <param name="dateCompetition"></param>
        /// <param name="engagement"></param>
        /// <param name="idCentre"></param>
        /// <param name="idNiveau"></param>
        /// <param name="idCategorie"></param>
        public Competition(string nom, DateTime dateCompetition, decimal engagement, int idCentre, int idNiveau, int idCategorie)
        {
            this.Nom = nom;
            this.DateCompetition = dateCompetition;
            this.Engagement = engagement;
            this.IdCentre = idCentre;
            this.IdNiveau = idNiveau;
            this.IdCategorie = idCategorie;
            this.leClassementIndividuel = new List<ClassementIndividuel>();
        }

        /// <summary>
        /// Récupération des compétitions individuelles ou doublettes confondues.
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="nom"></param>
        /// <param name="dateCompetition"></param>
        /// <param name="engagement"></param>
        /// <param name="idCentre"></param>
        public Competition(int idCompetition, string nom, DateTime dateCompetition, decimal engagement, int idCentre)
        {
            this.IdCompetition = idCompetition;
            this.Nom = nom;
            this.DateCompetition = dateCompetition;
            this.Engagement = engagement;
            this.IdCentre = idCentre;
        }

        /// <summary>
        /// Récupération compétition doublette
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="nom"></param>
        /// <param name="dateCompetition"></param>
        /// <param name="engagement"></param>
        /// <param name="idCentre"></param>
        /// <param name="idCategorie"></param>
        public Competition(int idCompetition, string nom, DateTime dateCompetition, decimal engagement, int idCentre, int idCategorie) //Doublette
        {
            this.IdCompetition = idCompetition;
            this.Nom = nom;
            this.DateCompetition = dateCompetition;
            this.Engagement = engagement;
            this.IdCentre = idCentre;
            this.IdCategorie = idCategorie;
            this.leClassementDouble = new List<ClassementDouble>();
        }

        /// <summary>
        /// Ajout compétition doublette
        /// </summary>
        /// <param name="nom"></param>
        /// <param name="dateCompetition"></param>
        /// <param name="engagement"></param>
        /// <param name="idCentre"></param>
        /// <param name="idCategorie"></param>
        public Competition(string nom, DateTime dateCompetition, decimal engagement, int idCentre, int idCategorie)
        {
            this.Nom = nom;
            this.DateCompetition = dateCompetition;
            this.Engagement = engagement;
            this.IdCentre = idCentre;
            this.IdCategorie = idCategorie;
            this.leClassementDouble = new List<ClassementDouble>();
        }

        /// <summary>
        /// Constructeur par défault
        /// </summary>
        public Competition() { }

        public int IdCompetition { get; set; }
        public string Nom { get; set; }
        public DateTime DateCompetition { get; set; }
        public decimal Engagement { get; set; }
        public int IdCentre { get; set; }
        public Centre LeCentre { get; set; }
        public int IdNiveau { get; set; }
        public Niveau LeNiveau { get; set; }
        public int IdCategorie { get; set; }
        public Categorie LaCategorie { get; set; }

        public List<ClassementIndividuel> leClassementIndividuel { get; set; }

        public List<ClassementDouble> leClassementDouble { get; set; }

        /// <summary>
        /// Renvoie le nom de la compétition
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.Nom;
        }
    }
}
