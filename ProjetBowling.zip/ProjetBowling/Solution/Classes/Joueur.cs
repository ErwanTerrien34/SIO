﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Joueur
    {
        /// <summary>
        /// Récupération du joueur
        /// </summary>
        /// <param name="idJoueur"></param>
        /// <param name="numLicence"></param>
        /// <param name="nom"></param>
        /// <param name="prenom"></param>
        /// <param name="dateNaissance"></param>
        /// <param name="adresse"></param>
        /// <param name="ville"></param>
        /// <param name="codePostal"></param>
        /// <param name="numTelephone"></param>
        /// <param name="adresseMail"></param>
        /// <param name="idNiveau"></param>
        /// <param name="idCategorie"></param>
        public Joueur(int idJoueur, string numLicence, string nom, string prenom, DateTime dateNaissance, string adresse, string ville, string codePostal, string numTelephone, string adresseMail, int idNiveau, int idCategorie)
        {
            this.IdJoueur = idJoueur;
            this.NumLicence = numLicence;
            this.Nom = nom;
            this.Prenom = prenom;
            this.DateNaissance = dateNaissance;
            this.Adresse = adresse;
            this.Ville = ville;
            this.CodePostal = codePostal;
            this.NumTelephone = numTelephone;
            this.AdresseMail = adresseMail;
            this.IdNiveau = idNiveau;
            this.IdCategorie = idCategorie;
            this.LesCompetitionsDuJoueur = new List<Competition>();
            this.LesParticipationsDuJoueur = new List<Participation>();
            this.Resume = this.Nom + " " + this.Prenom;
        }

        /// <summary>
        /// Ajout du joueur
        /// </summary>
        /// <param name="numLicence"></param>
        /// <param name="nom"></param>
        /// <param name="prenom"></param>
        /// <param name="dateNaissance"></param>
        /// <param name="adresse"></param>
        /// <param name="ville"></param>
        /// <param name="codePostal"></param>
        /// <param name="numTelephone"></param>
        /// <param name="adresseMail"></param>
        /// <param name="idNiveau"></param>
        /// <param name="idCategorie"></param>
        public Joueur(string numLicence, string nom, string prenom, DateTime dateNaissance, string adresse, string ville, string codePostal, string numTelephone, string adresseMail, int idNiveau, int idCategorie)
        {
            this.NumLicence = numLicence;
            this.Nom = nom;
            this.Prenom = prenom;
            this.DateNaissance = dateNaissance;
            this.Adresse = adresse;
            this.Ville = ville;
            this.CodePostal = codePostal;
            this.NumTelephone = numTelephone;
            this.AdresseMail = adresseMail;
            this.IdNiveau = idNiveau;
            this.IdCategorie = idCategorie;
            this.LesCompetitionsDuJoueur = new List<Competition>();
            this.LesParticipationsDuJoueur = new List<Participation>();
            this.Resume = this.Nom + " " + this.Prenom;
        }

        public Joueur() { }

        public int IdJoueur { get; set; }
        public string NumLicence { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateNaissance { get; set; }
        public string Adresse { get; set; }
        public string Ville { get; set; }
        public string CodePostal { get; set; }
        public string NumTelephone { get; set; }
        public string AdresseMail { get; set; }
        public int IdNiveau { get; set; }
        public Niveau LeNiveau { get; set; }
        public int IdCategorie { get; set; }
        public Categorie LaCategorie { get; set; }

        public string Resume { get; set; }

        public List<Competition> LesCompetitionsDuJoueur { get; set; }
        public List<Participation> LesParticipationsDuJoueur { get; set; }

        /// <summary>
        /// Renvoie le joueur sous ce format :
        /// nom - prenom
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.Nom + " " + this.Prenom;
        }
    }
}
