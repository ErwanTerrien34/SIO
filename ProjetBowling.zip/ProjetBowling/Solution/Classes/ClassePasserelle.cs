﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography.X509Certificates;
using System;

namespace Classes
{
    public class ClassePasserelle
    {
        private static SqlConnection connexionBase = new SqlConnection("Data Source=.;Initial Catalog=ProjetBowling;user Id=Quilles;password=B0w1!ng");

        public static List<Joueur> GetLesJoueurs()
        {
            List<Joueur> lesJoueurs = new List<Joueur>();
            SqlCommand reqGetLesJoueurs = new SqlCommand("SELECT idJoueur, numLicence, nom, prenom, dateNaissance, adresse, ville, codePostal, numTelephone, adresseMail, idNiveau, idCategorie FROM Joueur ORDER BY nom, prenom", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesJoueurs = reqGetLesJoueurs.ExecuteReader();
                while (readerLesJoueurs.Read())
                {
                    Joueur leJoueur = new Joueur(
                        (int)readerLesJoueurs[0],
                        readerLesJoueurs[1].ToString(),
                        readerLesJoueurs[2].ToString(),
                        readerLesJoueurs[3].ToString(),
                        Convert.ToDateTime(readerLesJoueurs[4]),
                        readerLesJoueurs[5].ToString(),
                        readerLesJoueurs[6].ToString(),
                        readerLesJoueurs[7].ToString(),
                        readerLesJoueurs[8].ToString(),
                        readerLesJoueurs[9].ToString(),
                        (int)readerLesJoueurs[10],
                        (int)readerLesJoueurs[11]);

                    lesJoueurs.Add(leJoueur);
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesJoueurs;
        }

        public static List<Niveau> GetLesNiveaux()
        {
            List<Niveau> lesNiveaux = new List<Niveau>();
            SqlCommand reqGetLesNiveaux = new SqlCommand("SELECT idNiveau, libelle, nbPointsRequis FROM Niveau ORDER BY nbPointsRequis", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesNiveaux = reqGetLesNiveaux.ExecuteReader();
                while (readerLesNiveaux.Read())
                {

                    lesNiveaux.Add(new Niveau((int)readerLesNiveaux[0], readerLesNiveaux[1].ToString(), (int)readerLesNiveaux[2]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesNiveaux;
        }

        public static List<Categorie> GetLesCategories()
        {
            List<Categorie> lesCategories = new List<Categorie>();
            SqlCommand reqGetLesCategories = new SqlCommand("SELECT idCategorie, libelle, ageMin, ageMax FROM Categorie ORDER BY ageMin", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesCategories = reqGetLesCategories.ExecuteReader();
                while (readerLesCategories.Read())
                {
                    lesCategories.Add(new Categorie((int)readerLesCategories[0], readerLesCategories[1].ToString(), (byte)readerLesCategories[2], (byte)readerLesCategories[3]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesCategories;
        }

        public static List<Competition> GetLesCompetitions()
        {
            List<Competition> lesCompetitions = new List<Competition>();
            SqlCommand reqGetLesCompetitions = new SqlCommand("SELECT idCompetition, nom, dateCompetition, engagement, idCentre FROM Competition", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesCompetitions = reqGetLesCompetitions.ExecuteReader();
                while (readerLesCompetitions.Read())
                {
                    lesCompetitions.Add(new Competition((int)readerLesCompetitions[0], readerLesCompetitions[1].ToString(), Convert.ToDateTime(readerLesCompetitions[2]), Math.Round((decimal)readerLesCompetitions[3],2), (int)readerLesCompetitions[4]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesCompetitions;
        }

        public static List<Competition> GetLesCompetitionsIndividuelles()
        {
            List<Competition> lesCompetitions = new List<Competition>();
            SqlCommand reqGetLesCompetitions = new SqlCommand("SELECT C.idCompetition, nom, dateCompetition, engagement, idCentre, idNiveau, idCategorie FROM Competition C JOIN Individuelle I ON C.idCompetition = I.idCompetition", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesCompetitions = reqGetLesCompetitions.ExecuteReader();
                while (readerLesCompetitions.Read())
                {
                    lesCompetitions.Add(new Competition((int)readerLesCompetitions[0], readerLesCompetitions[1].ToString(), Convert.ToDateTime(readerLesCompetitions[2]), Math.Round((decimal)readerLesCompetitions[3], 2), (int)readerLesCompetitions[4], (int)readerLesCompetitions[5], (int)readerLesCompetitions[6]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesCompetitions;
        }

        public static List<Participation> GetLesParticipations(int idJoueur)
        {
            List<Participation> lesParticipations = new List<Participation>();
            SqlCommand reqGetLesParticipations = new SqlCommand("EXEC Participations @idJoueur", connexionBase);
            reqGetLesParticipations.Parameters.AddWithValue("@idJoueur", idJoueur);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesParticipations = reqGetLesParticipations.ExecuteReader();
                while (readerLesParticipations.Read())
                {
                    lesParticipations.Add(new Participation((int)readerLesParticipations[0], readerLesParticipations[1].ToString(), Convert.ToDateTime(readerLesParticipations[2]), readerLesParticipations[3].ToString(), (int)readerLesParticipations[4]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesParticipations;
        }

        public static void SupprimerJoueur(int idJoueur)
        {
            SqlCommand reqSupprimerJoueur = new SqlCommand("DELETE FROM Joueur WHERE idJoueur =  @idJoueur", connexionBase);
            reqSupprimerJoueur.Parameters.AddWithValue("@idJoueur", idJoueur);
            try
            {
                connexionBase.Open();
                reqSupprimerJoueur.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void ModifierJoueur(Joueur JoueurAModifier)
        {
            SqlCommand reqModifierJoueur = new SqlCommand("UPDATE Joueur SET numLicence = @numLicence, nom = @nom, prenom = @prenom, dateNaissance = @dateNaissance, adresse = @adresse, ville = @ville, codePostal = @codePostal, numTelephone = @numTelephone, adresseMail = @adresseMail, idNiveau = @idNiveau, idCategorie = @idCategorie FROM Joueur where idJoueur = @id", connexionBase);
            reqModifierJoueur.Parameters.AddWithValue("@id", JoueurAModifier.IdJoueur);
            reqModifierJoueur.Parameters.AddWithValue("@numLicence", JoueurAModifier.NumLicence);
            reqModifierJoueur.Parameters.AddWithValue("@nom", JoueurAModifier.Nom);
            reqModifierJoueur.Parameters.AddWithValue("@prenom", JoueurAModifier.Prenom);
            reqModifierJoueur.Parameters.AddWithValue("@dateNaissance", JoueurAModifier.DateNaissance);
            reqModifierJoueur.Parameters.AddWithValue("@adresse", JoueurAModifier.Adresse);
            reqModifierJoueur.Parameters.AddWithValue("@ville", JoueurAModifier.Ville);
            reqModifierJoueur.Parameters.AddWithValue("@codePostal", JoueurAModifier.CodePostal);
            reqModifierJoueur.Parameters.AddWithValue("@numTelephone", JoueurAModifier.NumTelephone);
            reqModifierJoueur.Parameters.AddWithValue("@adresseMail", JoueurAModifier.AdresseMail);
            reqModifierJoueur.Parameters.AddWithValue("@idNiveau", JoueurAModifier.IdNiveau);
            reqModifierJoueur.Parameters.AddWithValue("@idCategorie", JoueurAModifier.IdCategorie);

            try
            {
                connexionBase.Open();
                reqModifierJoueur.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static int AjouterJoueur(Joueur JoueurSupplementaire)
        {
            SqlCommand reqAjouterJoueur = new SqlCommand("INSERT INTO Joueur (numLicence, nom, prenom, dateNaissance, adresse, ville, codePostal, numTelephone, adresseMail, idNiveau, idCategorie) VALUES(@numLicence, @nom, @prenom, @dateNaissance, @adresse, @ville, @codePostal, @numTelephone, @adresseMail, @idNiveau, @idCategorie)", connexionBase);
            reqAjouterJoueur.Parameters.AddWithValue("@numLicence", JoueurSupplementaire.NumLicence);
            reqAjouterJoueur.Parameters.AddWithValue("@nom", JoueurSupplementaire.Nom);
            reqAjouterJoueur.Parameters.AddWithValue("@prenom", JoueurSupplementaire.Prenom);
            reqAjouterJoueur.Parameters.AddWithValue("@dateNaissance", JoueurSupplementaire.DateNaissance);
            reqAjouterJoueur.Parameters.AddWithValue("@adresse", JoueurSupplementaire.Adresse);
            reqAjouterJoueur.Parameters.AddWithValue("@ville", JoueurSupplementaire.Ville);
            reqAjouterJoueur.Parameters.AddWithValue("@codePostal", JoueurSupplementaire.CodePostal);
            reqAjouterJoueur.Parameters.AddWithValue("@numTelephone", JoueurSupplementaire.NumTelephone);
            reqAjouterJoueur.Parameters.AddWithValue("@adresseMail", JoueurSupplementaire.AdresseMail);
            reqAjouterJoueur.Parameters.AddWithValue("@idNiveau", JoueurSupplementaire.IdNiveau);
            reqAjouterJoueur.Parameters.AddWithValue("@idCategorie", JoueurSupplementaire.IdCategorie);
            SqlCommand reqGetId = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object idJoueur;
            try
            {
                connexionBase.Open();
                reqAjouterJoueur.ExecuteNonQuery();
                idJoueur = reqGetId.ExecuteScalar();
            }
            finally
            {
                connexionBase.Close();
            }
            return Convert.ToInt32(idJoueur);
        }

        public static List<Centre> GetLesCentres()
        {
            List<Centre> lesCentres = new List<Centre>();
            SqlCommand reqGetLesCentres = new SqlCommand("SELECT idCentre, raisonSociale, adresse, ville, codePostal FROM Centre", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesCentres = reqGetLesCentres.ExecuteReader();
                while (readerLesCentres.Read())
                {
                    lesCentres.Add(new Centre((int)readerLesCentres[0], readerLesCentres[1].ToString(), readerLesCentres[2].ToString(), readerLesCentres[3].ToString(), readerLesCentres[4].ToString()));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesCentres;
        }

        public static void SupprimerCompetition(int idCompetition)
        {
            SqlCommand reqSupprimerCompetition = new SqlCommand("DELETE FROM Competition WHERE idCompetition =  @idCompetition;", connexionBase);
            reqSupprimerCompetition.Parameters.AddWithValue("@idCompetition", idCompetition);
            try
            {
                connexionBase.Open();
                reqSupprimerCompetition.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void ModifierCompetitionIndividuelle(Competition CompetitionSupplementaire)
        {
            SqlCommand reqModifierCompetition = new SqlCommand("UPDATE Competition SET nom = @nom, engagement = @engagement, dateCompetition = @dateCompetition, idCategorie = @idCategorie, idCentre = @idCentre FROM Competition where idCompetition = @id UPDATE Individuelle SET idNiveau = @idNiveau FROM Individuelle WHERE idCompetition = @id", connexionBase);
            reqModifierCompetition.Parameters.AddWithValue("@id", CompetitionSupplementaire.IdCompetition);
            reqModifierCompetition.Parameters.AddWithValue("@nom", CompetitionSupplementaire.Nom);
            reqModifierCompetition.Parameters.AddWithValue("@engagement", CompetitionSupplementaire.Engagement);
            reqModifierCompetition.Parameters.AddWithValue("@dateCompetition", CompetitionSupplementaire.DateCompetition);
            reqModifierCompetition.Parameters.AddWithValue("@idNiveau", CompetitionSupplementaire.IdNiveau);
            reqModifierCompetition.Parameters.AddWithValue("@idCategorie", CompetitionSupplementaire.IdCategorie);
            reqModifierCompetition.Parameters.AddWithValue("@idCentre", CompetitionSupplementaire.IdCentre);

            try
            {
                connexionBase.Open();
                reqModifierCompetition.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void ModifierCompetitionDouble(Competition CompetitionSupplementaire)
        {
            SqlCommand reqModifierCompetition = new SqlCommand("UPDATE Competition SET nom = @nom, engagement = @engagement, dateCompetition = @dateCompetition, idCategorie = @idCategorie, idCentre = @idCentre FROM Competition where idCompetition = @id", connexionBase);
            reqModifierCompetition.Parameters.AddWithValue("@id", CompetitionSupplementaire.IdCompetition);
            reqModifierCompetition.Parameters.AddWithValue("@nom", CompetitionSupplementaire.Nom);
            reqModifierCompetition.Parameters.AddWithValue("@engagement", CompetitionSupplementaire.Engagement);
            reqModifierCompetition.Parameters.AddWithValue("@dateCompetition", CompetitionSupplementaire.DateCompetition);
            reqModifierCompetition.Parameters.AddWithValue("@idCategorie", CompetitionSupplementaire.IdCategorie);
            reqModifierCompetition.Parameters.AddWithValue("@idCentre", CompetitionSupplementaire.IdCentre);

            try
            {
                connexionBase.Open();
                reqModifierCompetition.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static int AjouterCompetitionIndividuelle(Competition CompetitionSupplementaire)
        {
            SqlCommand reqAjouterCompetition = new SqlCommand("INSERT INTO Competition (nom, dateCompetition, engagement, idCentre, idCategorie) VALUES(@nom, @dateCompetition, @engagement, @idCentre, @idCategorie)", connexionBase);
            reqAjouterCompetition.Parameters.AddWithValue("@nom", CompetitionSupplementaire.Nom);
            reqAjouterCompetition.Parameters.AddWithValue("@engagement", CompetitionSupplementaire.Engagement);
            reqAjouterCompetition.Parameters.AddWithValue("@dateCompetition", CompetitionSupplementaire.DateCompetition);
            reqAjouterCompetition.Parameters.AddWithValue("@idCategorie", CompetitionSupplementaire.IdCategorie);
            reqAjouterCompetition.Parameters.AddWithValue("@idCentre", CompetitionSupplementaire.IdCentre);
            SqlCommand reqGetId = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object idCompetition;
            try
            {
                connexionBase.Open();
                reqAjouterCompetition.ExecuteNonQuery();
                idCompetition = reqGetId.ExecuteScalar();      //Un seul enregistrement à retourner
                SqlCommand reqAjouterIndividuelle = new SqlCommand("INSERT INTO Individuelle (idCompetition, idNiveau) VALUES(@id, @idNiveau)", connexionBase);
                reqAjouterIndividuelle.Parameters.AddWithValue("@id", Convert.ToInt32(idCompetition));
                reqAjouterIndividuelle.Parameters.AddWithValue("@idNiveau", CompetitionSupplementaire.IdNiveau);
                reqAjouterIndividuelle.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
            return Convert.ToInt32(idCompetition);
        }

        public static int AjouterCompetitionDouble(Competition CompetitionSupplementaire)
        {
            SqlCommand reqAjouterCompetition = new SqlCommand("INSERT INTO Competition (nom, dateCompetition, engagement, idCentre, idCategorie) VALUES(@nom, @dateCompetition, @engagement, @idCentre, @idCategorie)", connexionBase);
            reqAjouterCompetition.Parameters.AddWithValue("@nom", CompetitionSupplementaire.Nom);
            reqAjouterCompetition.Parameters.AddWithValue("@engagement", CompetitionSupplementaire.Engagement);
            reqAjouterCompetition.Parameters.AddWithValue("@dateCompetition", CompetitionSupplementaire.DateCompetition);
            reqAjouterCompetition.Parameters.AddWithValue("@idCategorie", CompetitionSupplementaire.IdCategorie);
            reqAjouterCompetition.Parameters.AddWithValue("@idCentre", CompetitionSupplementaire.IdCentre);
            SqlCommand reqGetId = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object idCompetition;
            try
            {
                connexionBase.Open();
                reqAjouterCompetition.ExecuteNonQuery();
                idCompetition = reqGetId.ExecuteScalar();
                SqlCommand reqAjouterDouble = new SqlCommand("INSERT INTO Doublette (idCompetition) VALUES(@id)", connexionBase);
                reqAjouterDouble.Parameters.AddWithValue("@id", Convert.ToInt32(idCompetition));
                reqAjouterDouble.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
            return Convert.ToInt32(idCompetition);
        }

        public static List<ClassementIndividuel> GetClassementIndividuel()
        {
            List<ClassementIndividuel> leClassement = new List<ClassementIndividuel>();
            SqlCommand reqGetLeClassement = new SqlCommand("SELECT idCompetition, idJoueur, pointsObtenusSeul FROM Inscription_Individuelle ORDER BY pointsObtenusSeul DESC", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLeClassement = reqGetLeClassement.ExecuteReader();
                while (readerLeClassement.Read())
                {
                    leClassement.Add(new ClassementIndividuel((int)readerLeClassement[0], (int)readerLeClassement[1], (int)readerLeClassement[2]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return leClassement;
        }

        public static void SupprimerParticipationIndividuelle(int idJoueur, int idCompetition)
        {
            SqlCommand reqSupprimerParticipation = new SqlCommand("DELETE FROM Inscription_Individuelle WHERE idJoueur =  @idJoueur AND idCompetition = @idCompetition", connexionBase);
            reqSupprimerParticipation.Parameters.AddWithValue("@idJoueur", idJoueur);
            reqSupprimerParticipation.Parameters.AddWithValue("@idCompetition", idCompetition);
            try
            {
                connexionBase.Open();
                reqSupprimerParticipation.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void ModifierClassementIndividuel(ClassementIndividuel classementAModifier, ClassementIndividuel NouveauClassement)
        {
            SqlCommand reqModifierClassement = new SqlCommand("UPDATE Inscription_Individuelle SET idJoueur = @idJoueur, pointsObtenusSeul = @nbPoints FROM Inscription_Individuelle WHERE idCompetition = @idCompetition AND idJoueur = @idJoueurBis", connexionBase);
            reqModifierClassement.Parameters.AddWithValue("@idCompetition", classementAModifier.IdCompetition);
            reqModifierClassement.Parameters.AddWithValue("@idJoueur", NouveauClassement.IdJoueur);
            reqModifierClassement.Parameters.AddWithValue("@idJoueurBis", classementAModifier.IdJoueur);
            reqModifierClassement.Parameters.AddWithValue("@nbPoints", NouveauClassement.NbPoints);

            try
            {
                connexionBase.Open();
                reqModifierClassement.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void AjouterClassementIndividuel(ClassementIndividuel classementSupplementaire)
        {
            SqlCommand reqAjouterClassement = new SqlCommand("INSERT INTO Inscription_Individuelle (idCompetition, idJoueur, pointsObtenusSeul) VALUES (@idCompetition, @idJoueur, @nbPoints)", connexionBase);
            reqAjouterClassement.Parameters.AddWithValue("@idCompetition", classementSupplementaire.IdCompetition);
            reqAjouterClassement.Parameters.AddWithValue("@idJoueur", classementSupplementaire.IdJoueur);
            reqAjouterClassement.Parameters.AddWithValue("@nbPoints", classementSupplementaire.NbPoints);
            try
            {
                connexionBase.Open();
                reqAjouterClassement.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static List<Competition> GetLesCompetitionsDoubles()
        {
            List<Competition> lesCompetitions = new List<Competition>();
            SqlCommand reqGetLesCompetitions = new SqlCommand("SELECT C.idCompetition, nom, dateCompetition, engagement, idCentre, idCategorie FROM Competition C JOIN Doublette D ON C.idCompetition = D.idCompetition", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLesCompetitions = reqGetLesCompetitions.ExecuteReader();
                while (readerLesCompetitions.Read())
                {
                    lesCompetitions.Add(new Competition((int)readerLesCompetitions[0], readerLesCompetitions[1].ToString(), Convert.ToDateTime(readerLesCompetitions[2]), Math.Round((decimal)readerLesCompetitions[3], 2), (int)readerLesCompetitions[4], (int)readerLesCompetitions[5]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return lesCompetitions;
        }

        public static List<ClassementDouble> GetClassementDouble()
        {
            List<ClassementDouble> leClassement = new List<ClassementDouble>();
            SqlCommand reqGetLeClassement = new SqlCommand("SELECT E.numEquipe, idCompetition, Joueur1, Joueur2, pointsObtenuADeux FROM S_associer S JOIN Equipe E ON E.numEquipe = S.numEquipe ORDER BY pointsObtenuADeux DESC", connexionBase);
            try
            {
                connexionBase.Open();
                SqlDataReader readerLeClassement = reqGetLeClassement.ExecuteReader();
                while (readerLeClassement.Read())
                {
                    leClassement.Add(new ClassementDouble((int)readerLeClassement[0], (int)readerLeClassement[1], (int)readerLeClassement[2], (int)readerLeClassement[3], (int)readerLeClassement[4]));
                }
            }
            finally
            {
                connexionBase.Close();
            }
            return leClassement;
        }

        public static void SupprimerParticipationDouble(int numEquipe)
        {
            SqlCommand reqSupprimerParticipation = new SqlCommand("DELETE FROM Equipe WHERE numEquipe = @num", connexionBase);
            reqSupprimerParticipation.Parameters.AddWithValue("@num", numEquipe);
            try
            {
                connexionBase.Open();
                reqSupprimerParticipation.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void ModifierClassementDouble(ClassementDouble classementAModifier)
        {
            SqlCommand reqModifierClassement1 = new SqlCommand("UPDATE Equipe SET Joueur1 = @J1, Joueur2 = @J2 FROM Equipe WHERE numEquipe = @num", connexionBase);
            reqModifierClassement1.Parameters.AddWithValue("@num", classementAModifier.NumEquipe);
            reqModifierClassement1.Parameters.AddWithValue("@J1", classementAModifier.IdJoueur1);
            reqModifierClassement1.Parameters.AddWithValue("@J2", classementAModifier.IdJoueur2);

            SqlCommand reqModifierClassement2 = new SqlCommand(" UPDATE S_Associer SET pointsObtenuADeux = @nbPoints FROM S_Associer WHERE numEquipe = @num", connexionBase);
            reqModifierClassement2.Parameters.AddWithValue("@nbPoints", classementAModifier.NbPoints);
            reqModifierClassement2.Parameters.AddWithValue("@num", classementAModifier.NumEquipe);

            try
            {
                connexionBase.Open();
                reqModifierClassement1.ExecuteNonQuery();
                reqModifierClassement2.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static int AjouterClassementDouble(ClassementDouble classementSupplementaire)
        {
            SqlCommand reqAjouterClassement = new SqlCommand("INSERT INTO Equipe (Joueur1, Joueur2) VALUES (@J1, @J2)", connexionBase);
            reqAjouterClassement.Parameters.AddWithValue("@J1", classementSupplementaire.IdJoueur1);
            reqAjouterClassement.Parameters.AddWithValue("@J2", classementSupplementaire.IdJoueur2);
            SqlCommand reqGetNum = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object numEquipe;
            int i = 0;

            try
            {
                connexionBase.Open();
                reqAjouterClassement.ExecuteNonQuery();
                numEquipe = reqGetNum.ExecuteScalar();
                i = Convert.ToInt32(numEquipe);
                SqlCommand reqAjouterDouble = new SqlCommand("INSERT INTO S_Associer (idCompetition, numEquipe, pointsObtenuADeux) VALUES(@id, @num, @nbPoints)", connexionBase);
                reqAjouterDouble.Parameters.AddWithValue("@id", Convert.ToInt32(classementSupplementaire.IdCompetition));
                reqAjouterDouble.Parameters.AddWithValue("@num", Convert.ToInt32(numEquipe));
                reqAjouterDouble.Parameters.AddWithValue("@nbPoints", classementSupplementaire.NbPoints);
                reqAjouterDouble.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }

            return i;
        }

        public static void SupprimerCentre(int idCentre)
        {
            SqlCommand reqSupprimerCentre = new SqlCommand("DELETE FROM Centre WHERE idCentre =  @idCentre", connexionBase);
            reqSupprimerCentre.Parameters.AddWithValue("@idCentre", idCentre);
            try
            {
                connexionBase.Open();
                reqSupprimerCentre.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static int AjouterCentre(Centre CentreSupplementaire)
        {
            SqlCommand reqAjouterCentre = new SqlCommand("INSERT INTO Centre (raisonSociale, adresse, ville, codePostal) VALUES (@nom, @adresse, @ville, @codePostal)", connexionBase);
            reqAjouterCentre.Parameters.AddWithValue("@nom", CentreSupplementaire.RaisonSociale);
            reqAjouterCentre.Parameters.AddWithValue("@adresse", CentreSupplementaire.Adresse);
            reqAjouterCentre.Parameters.AddWithValue("@ville", CentreSupplementaire.Ville);
            reqAjouterCentre.Parameters.AddWithValue("@codePostal", CentreSupplementaire.CodePostal);
            SqlCommand reqGetId = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object idCentre;
            try
            {
                connexionBase.Open();
                reqAjouterCentre.ExecuteNonQuery();
                idCentre = reqGetId.ExecuteScalar();
            }
            finally
            {
                connexionBase.Close();
            }
            return Convert.ToInt32(idCentre);
        }

        public static void ModifierCentre(Centre CentreAModifier)
        {
            SqlCommand reqModifierCentre = new SqlCommand("UPDATE Centre SET raisonSociale = @nom, adresse = @adresse, ville = @ville, codePostal = @codePostal FROM Centre where idCentre = @id", connexionBase);
            reqModifierCentre.Parameters.AddWithValue("@id", CentreAModifier.IdCentre);
            reqModifierCentre.Parameters.AddWithValue("@nom", CentreAModifier.RaisonSociale);
            reqModifierCentre.Parameters.AddWithValue("@adresse", CentreAModifier.Adresse);
            reqModifierCentre.Parameters.AddWithValue("@ville", CentreAModifier.Ville);
            reqModifierCentre.Parameters.AddWithValue("@codePostal", CentreAModifier.CodePostal);

            try
            {
                connexionBase.Open();
                reqModifierCentre.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void SupprimerCategorie(int idCategorie)
        {
            SqlCommand reqSupprimerCategorie = new SqlCommand("DELETE FROM Categorie WHERE idCategorie =  @idCategorie", connexionBase);
            reqSupprimerCategorie.Parameters.AddWithValue("@idCategorie", idCategorie);
            try
            {
                connexionBase.Open();
                reqSupprimerCategorie.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static int AjouterCategorie(Categorie CategorieSupplementaire)
        {
            SqlCommand reqAjouterCategorie = new SqlCommand("INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES (@nom, @ageMin, @ageMax)", connexionBase);
            reqAjouterCategorie.Parameters.AddWithValue("@nom", CategorieSupplementaire.Libelle);
            reqAjouterCategorie.Parameters.AddWithValue("@ageMin", CategorieSupplementaire.AgeMin);
            reqAjouterCategorie.Parameters.AddWithValue("@ageMax", CategorieSupplementaire.AgeMax);
            SqlCommand reqGetId = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object idCategorie;
            try
            {
                connexionBase.Open();
                reqAjouterCategorie.ExecuteNonQuery();
                idCategorie = reqGetId.ExecuteScalar();
            }
            finally
            {
                connexionBase.Close();
            }
            return Convert.ToInt32(idCategorie);
        }

        public static void ModifierCategorie(Categorie CategorieAModifier)
        {
            SqlCommand reqModifierCategorie = new SqlCommand("UPDATE Categorie SET libelle = @nom, ageMin = @ageMin, ageMax = @ageMax FROM Categorie where idCategorie = @id", connexionBase);
            reqModifierCategorie.Parameters.AddWithValue("@id", CategorieAModifier.IdCategorie);
            reqModifierCategorie.Parameters.AddWithValue("@nom", CategorieAModifier.Libelle);
            reqModifierCategorie.Parameters.AddWithValue("@ageMin", CategorieAModifier.AgeMin);
            reqModifierCategorie.Parameters.AddWithValue("@ageMax", CategorieAModifier.AgeMax);

            try
            {
                connexionBase.Open();
                reqModifierCategorie.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static void SupprimerNiveau(int idNiveau)
        {
            SqlCommand reqSupprimerNiveau = new SqlCommand("DELETE FROM Niveau WHERE idNiveau =  @idNiveau", connexionBase);
            reqSupprimerNiveau.Parameters.AddWithValue("@idNiveau", idNiveau);
            try
            {
                connexionBase.Open();
                reqSupprimerNiveau.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }

        public static int AjouterNiveau(Niveau NiveauSupplementaire)
        {
            SqlCommand reqAjouterNiveau = new SqlCommand("INSERT INTO Niveau (libelle, nbPointsRequis) VALUES (@nom, @points)", connexionBase);
            reqAjouterNiveau.Parameters.AddWithValue("@nom", NiveauSupplementaire.Libelle);
            reqAjouterNiveau.Parameters.AddWithValue("@points", NiveauSupplementaire.NbPointsRequis);
            SqlCommand reqGetId = new SqlCommand("SELECT @@IDENTITY", connexionBase);
            object idNiveau;
            try
            {
                connexionBase.Open();
                reqAjouterNiveau.ExecuteNonQuery();
                idNiveau = reqGetId.ExecuteScalar();
            }
            finally
            {
                connexionBase.Close();
            }
            return Convert.ToInt32(idNiveau);
        }

        public static void ModifierNiveau(Niveau NiveauAModifier)
        {
            SqlCommand reqModifierNiveau = new SqlCommand("UPDATE Niveau SET libelle = @nom, nbPointsRequis = @points FROM Niveau where idNiveau = @id", connexionBase);
            reqModifierNiveau.Parameters.AddWithValue("@id", NiveauAModifier.IdNiveau);
            reqModifierNiveau.Parameters.AddWithValue("@nom", NiveauAModifier.Libelle);
            reqModifierNiveau.Parameters.AddWithValue("@points", NiveauAModifier.NbPointsRequis);

            try
            {
                connexionBase.Open();
                reqModifierNiveau.ExecuteNonQuery();
            }
            finally
            {
                connexionBase.Close();
            }
        }
    }
}
