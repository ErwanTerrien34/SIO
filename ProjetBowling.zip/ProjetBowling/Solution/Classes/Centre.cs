﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Centre
    {
        public Centre(int idCentre, string raisonSociale, string adresse, string ville, string cp)
        {
            this.IdCentre = idCentre;
            this.RaisonSociale = raisonSociale;
            this.Adresse = adresse;
            this.Ville = ville;
            this.CodePostal = cp;
        }

        public Centre(string raisonSociale, string adresse, string ville, string cp)
        {
            this.RaisonSociale = raisonSociale;
            this.Adresse = adresse;
            this.Ville = ville;
            this.CodePostal = cp;
        }

        public Centre() { }

        public int IdCentre {get; set;}
        public string RaisonSociale {get; set;}
        public string Adresse {get; set;}
        public string Ville {get; set;}
        public string CodePostal {get; set;}

        public override string ToString()
        {
            return IdCentre + " - " + RaisonSociale;
        }
    }
}
