﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class ClassementDouble
    {
        /// <summary>
        /// Récupération du classement double
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="idJoueur"></param>
        /// <param name="nbPoints"></param>
        public ClassementDouble(int numEquipe, int idCompetition, int idJoueur1, int idJoueur2, int nbPoints)
        {
            this.NumEquipe = numEquipe;
            this.IdCompetition = idCompetition;
            this.IdJoueur1 = idJoueur1;
            this.IdJoueur2 = idJoueur2;
            this.NbPoints = nbPoints;
        }

        /// <summary>
        /// Ajout du classement double
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="idJoueur1"></param>
        /// <param name="idJoueur2"></param>
        /// <param name="nbPoints"></param>
        public ClassementDouble(int idCompetition, int idJoueur1, int idJoueur2, int nbPoints)
        {
            this.IdCompetition = idCompetition;
            this.IdJoueur1 = idJoueur1;
            this.IdJoueur2 = idJoueur2;
            this.NbPoints = nbPoints;
        }

        /// <summary>
        /// Constructeur par défault
        /// </summary>
        public ClassementDouble()
        {

        }

        public int Position { get; set; }

        public int NumEquipe { get; set; }
        public int IdCompetition { get; set; }
        public Competition LaCompetition { get; set; }
        public int IdJoueur1 { get; set; }
        public Joueur LeJoueur1 { get; set; }
        public int IdJoueur2 { get; set; }
        public Joueur LeJoueur2 { get; set; }
        public int NbPoints { get; set; }
    }
}