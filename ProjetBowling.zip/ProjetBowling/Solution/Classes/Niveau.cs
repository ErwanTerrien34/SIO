﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Niveau
    {
        /// <summary>
        /// Récupération du niveau
        /// </summary>
        /// <param name="idNiveau"></param>
        /// <param name="libelle"></param>
        /// <param name="nbPointsRequis"></param>
        public Niveau(int idNiveau, string libelle, int nbPointsRequis)
        {
            this.IdNiveau = idNiveau;
            this.Libelle = libelle;
            this.NbPointsRequis = nbPointsRequis;
        }

        /// <summary>
        /// Ajout du niveau
        /// </summary>
        /// <param name="libelle"></param>
        /// <param name="nbPointsRequis"></param>
        public Niveau(string libelle, int nbPointsRequis)
        {
            this.Libelle = libelle;
            this.NbPointsRequis = nbPointsRequis;
        }

        public Niveau() {   }

        public int IdNiveau {get; set;}
        public string Libelle {get; set;}
        public int NbPointsRequis { get; set;}

        /// <summary>
        /// Renvoie le niveau sous ce format :
        /// n - nomNiveau
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return IdNiveau + " - " + Libelle;
        }
    }
}
