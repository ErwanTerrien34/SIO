﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Categorie
    {
        /// <summary>
        /// Récupération de la catégorie
        /// </summary>
        /// <param name="idCategorie"></param>
        /// <param name="libelle"></param>
        /// <param name="ageMin"></param>
        /// <param name="ageMax"></param>
        public Categorie(int idCategorie, string libelle, byte ageMin, byte ageMax)
        {
            this.IdCategorie = idCategorie;
            this.Libelle = libelle;
            this.AgeMin = ageMin;
            this.AgeMax = ageMax;
        }

        /// <summary>
        /// Ajout d'une catégorie
        /// </summary>
        /// <param name="libelle"></param>
        /// <param name="ageMin"></param>
        /// <param name="ageMax"></param>
        public Categorie(string libelle, byte ageMin, byte ageMax)
        {
            this.Libelle = libelle;
            this.AgeMin = ageMin;
            this.AgeMax = ageMax;
        }

        /// <summary>
        /// Constructeur par défault
        /// </summary>
        public Categorie()  {   }

        public int IdCategorie { get; set; }
        public string Libelle { get; set; }
        public byte AgeMin { get; set; }
        public byte AgeMax { get; set; }

        /// <summary>
        /// Renvoie la catégorie sous ce format :
        /// n - nomCategorie
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return IdCategorie + " - " + Libelle;
        }
    }
}
