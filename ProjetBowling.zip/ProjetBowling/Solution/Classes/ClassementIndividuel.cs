﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class ClassementIndividuel
    {
        /// <summary>
        /// Récupération du classement individuel
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="idJoueur"></param>
        /// <param name="nbPoints"></param>
        public ClassementIndividuel(int idCompetition, int idJoueur, int nbPoints)
        {
            this.IdCompetition = idCompetition;
            this.IdJoueur = idJoueur;
            this.NbPoints = nbPoints;
        }

        /// <summary>
        /// Constructeur par défault
        /// </summary>
        public ClassementIndividuel()
        {

        }

        public int Position { get; set; }
        public int IdCompetition { get; set; }
        public Competition LaCompetition { get; set; }
        public int IdJoueur { get; set; }
        public Joueur LeJoueur { get; set; }
        public int NbPoints { get; set; }
    }
}