﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Participation
    {
        /// <summary>
        /// Participations du joueur par compétition
        /// </summary>
        /// <param name="idCompetition"></param>
        /// <param name="nom"></param>
        /// <param name="dateCompetition"></param>
        /// <param name="typeCompetition"></param>
        /// <param name="nbPointsObtenus"></param>
        public Participation(int idCompetition, string nom, DateTime dateCompetition, string typeCompetition, int nbPointsObtenus)
        {
            this.IdCompetition = idCompetition;
            this.Nom = nom;
            this.DateCompetition = dateCompetition;
            this.TypeCompetition = typeCompetition;
            this.NbPointsObtenus = nbPointsObtenus;
        }

        public int IdCompetition { get; set; }
        public int IdJoueur { get; set; }
        public string Nom { get; set; }
        public DateTime DateCompetition { get; set; }
        public string TypeCompetition { get; set; }
        public int NbPointsObtenus { get; set; }
    }
}
