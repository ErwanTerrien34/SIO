﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet
{
    /// <summary>
    /// Menu principal de l'application
    /// </summary>
    public partial class FrmMDI : Form
    {
        public FrmMDI()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Demande de confirmation pour quitter l'application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmMDI_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Êtes-vous sûr de vouloir quitter ?", "Quitter", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        /// <summary>
        /// Demande de confirmation pour quitter l'application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void qUITTERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Êtes-vous sûr de vouloir quitter ?", "Quitter", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        /// <summary>
        /// Ouverture du formulaire joueur
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void joueursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmJoueur"] == null)
            {
                FrmJoueur frm = new FrmJoueur();
                frm.MdiParent = this;
                frm.Show();
                frm.Location = new Point(0, 0);
            }
            else
            {
                Application.OpenForms["FrmJoueur"].BringToFront();
            }
        }

        /// <summary>
        /// Ouverture du formulaire compétition individuelle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void individuelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmCompetitionIndividuelle"] == null)
            {
                FrmCompetitionIndividuelle frm = new FrmCompetitionIndividuelle();
                frm.MdiParent = this;
                frm.Show();
                frm.Location = new Point(0, 0);
            }
            else
            {
                Application.OpenForms["FrmCompetitionIndividuelle"].BringToFront();
            }
        }

        /// <summary>
        /// Ouverture du formulaire compétition doublette
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void doubletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmCompetitionDoublette"] == null)
            {
                FrmCompetitionDoublette frm = new FrmCompetitionDoublette();
                frm.MdiParent = this;
                frm.Show();
                frm.Location = new Point(0, 0);
            }
            else
            {
                Application.OpenForms["FrmCompetitionDoublette"].BringToFront();
            }
        }

        /// <summary>
        /// Ouverture du formulaire centre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void centreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmCentre"] == null)
            {
                FrmCentre frm = new FrmCentre();
                frm.MdiParent = this;
                frm.Show();
                frm.Location = new Point(0, 0);
            }
            else
            {
                Application.OpenForms["FrmCentre"].BringToFront();
            }
        }

        /// <summary>
        /// Ouverture du formulaire categorie
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void catégorieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmCategorie"] == null)
            {
                FrmCategorie frm = new FrmCategorie();
                frm.MdiParent = this;
                frm.Show();
                frm.Location = new Point(0, 0);
            }
            else
            {
                Application.OpenForms["FrmCategorie"].BringToFront();
            }
        }

        /// <summary>
        /// Ouverture du formulaire Niveau
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void niveauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["FrmNiveau"] == null)
            {
                FrmNiveau frm = new FrmNiveau();
                frm.MdiParent = this;
                frm.Show();
                frm.Location = new Point(0, 0);
            }
            else
            {
                Application.OpenForms["FrmNiveau"].BringToFront();
            }
        }

        /// <summary>
        /// Texte dans l'en tête (titre de l'application)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmMDI_Load(object sender, EventArgs e)
        {
            this.Text = "Ligue de Bowling";
        }
    }
}
