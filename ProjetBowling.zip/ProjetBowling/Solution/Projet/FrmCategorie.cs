﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    /// <summary>
    /// Formulaire de recensement des catégories
    /// </summary>
    public partial class FrmCategorie : Form
    {
        /// <summary>
        /// Vérifie si une donnée est en cours d'ajout
        /// </summary>
        private bool rajout = false;

        public FrmCategorie()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Après ajout ou annulation de l'ajout
        /// </summary>
        private void Retablir()
        {
            btSupprimer.Visible = true;
            btGererAjout.Visible = true;
        }

        /// <summary>
        /// Récupération des données dans le formulaire catégorie
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmCategorie_Load(object sender, EventArgs e)
        {
            try
            {
                this.bindSrcCategorie.DataSource = ClassePasserelle.GetLesCategories();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Lien direct de la liste au formulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridCategorie_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 1;
        }

        /// <summary>
        /// Bloque le passage sur un autre onglet lors de l'ajout
        /// Annule les modifications lors du changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (this.rajout == true)
            {
                e.Cancel = true;
            }
            else
            {
                bindSrcCategorie.CancelEdit();
                bindSrcCategorie.ResetBindings(false);
            }
        }

        /// <summary>
        /// Supprime une catégorie
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer_Click(object sender, EventArgs e)
        {
            if (bindSrcCategorie.Count == 0)
            {
                MessageBox.Show("Aucune catégorie n'existe actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer cette catégorie ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerCategorie(((Categorie)bindSrcCategorie.Current).IdCategorie);
                    bindSrcCategorie.RemoveCurrent();
                    bindSrcCategorie.EndEdit();
                    MessageBox.Show("Catégorie supprimée", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        /// <summary>
        /// Annule les modifications
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                bindSrcCategorie.CancelEdit();
                bindSrcCategorie.ResetBindings(false);
                Retablir();
                bindSrcCategorie.ResetBindings(false);
                rajout = false;
            }
            else
            {
                bindSrcCategorie.CancelEdit();
                bindSrcCategorie.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btApliquer_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string leNom = txtNom.Text;
                        byte ageMin = (byte)numMin.Value;
                        byte ageMax = (byte)numMax.Value;

                        Categorie laCategorie = new Categorie(leNom, ageMin, ageMax);
                        int ajout = ClassePasserelle.AjouterCategorie(laCategorie);
                        ((Categorie)bindSrcCategorie.Current).IdCategorie = ajout;
                        bindSrcCategorie.EndEdit();
                        bindSrcCategorie.MoveLast();
                        MessageBox.Show("Catégorie ajoutée", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (bindSrcCategorie.Count == 0)
                    {
                        if (MessageBox.Show("Aucune catégorie n'existe \n Voulez-vous en créer une ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            string leNom = txtNom.Text;
                            byte ageMin = (byte)numMin.Value;
                            byte ageMax = (byte)numMax.Value;

                            Categorie laCategorie = new Categorie(leNom, ageMin, ageMax);
                            int ajout = ClassePasserelle.AjouterCategorie(laCategorie);
                            laCategorie.IdCategorie = ajout;
                            bindSrcCategorie.Add(laCategorie);
                            bindSrcCategorie.EndEdit();
                            bindSrcCategorie.MoveLast();
                            MessageBox.Show("Catégorie ajoutée", "Information", MessageBoxButtons.OK);
                        }
                    }
                    else
                    {
                        Categorie leCategorie = new Categorie(((Categorie)bindSrcCategorie.Current).IdCategorie, txtNom.Text, (byte)numMin.Value, (byte)numMax.Value);
                        ClassePasserelle.ModifierCategorie(leCategorie);
                        bindSrcCategorie.EndEdit();
                        MessageBox.Show("Catégorie modifiée", "Information", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare un nouvel ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout_Click(object sender, EventArgs e)
        {
            bindSrcCategorie.CancelEdit();
            bindSrcCategorie.ResetBindings(false);
            bindSrcCategorie.AddNew();
            rajout = true;
            btSupprimer.Visible = false;
            btGererAjout.Visible = false;
        }
    }
}
