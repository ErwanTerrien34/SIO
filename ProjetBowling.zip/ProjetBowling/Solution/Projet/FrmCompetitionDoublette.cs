﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet
{
    /// <summary>
    /// Formulaire de recensement des compétitions doublettes
    /// </summary>
    public partial class FrmCompetitionDoublette : Form
    {
        /// <summary>
        /// Vérifie si une donnée est en cours d'ajout
        /// </summary>
        private bool rajout = false;

        public FrmCompetitionDoublette()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Après ajout ou annulation de l'ajout
        /// </summary>
        private void Retablir()
        {
            btSupprimer.Visible = true;
            btSupprimer2.Visible = true;
            btGererAjout.Visible = true;
            btGererAjout2.Visible = true;
        }

        /// <summary>
        /// Associe les compétitions aux joueurs
        /// </summary>
        private void AppelCompetition()
        {
            this.bindSrcCompetition.DataSource = ClassePasserelle.GetLesCompetitionsDoubles();
            this.bindSrcClassement.DataSource = ClassePasserelle.GetClassementDouble();

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int i = 0;
                while (((Categorie)this.bindSrcCategorie[i]).IdCategorie != uneC.IdCategorie)
                {
                    i++;
                }
                uneC.LaCategorie = (Categorie)this.bindSrcCategorie[i];
            }

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int i = 0;
                while (((Centre)this.bindSrcCentre[i]).IdCentre != uneC.IdCentre)
                {
                    i++;
                }
                uneC.LeCentre = (Centre)this.bindSrcCentre[i];
            }

            foreach (ClassementDouble unCD in this.bindSrcClassement)
            {
                int i = 0;
                while (((Competition)this.bindSrcCompetition[i]).IdCompetition != unCD.IdCompetition)
                {
                    i++;
                }
                ((Competition)this.bindSrcCompetition[i]).leClassementDouble.Add(unCD);
                unCD.LaCompetition = (Competition)this.bindSrcCompetition[i];
            }

            foreach (ClassementDouble unCD in this.bindSrcClassement)
            {
                int i = 0;
                while (((Joueur)this.bindSrcJoueur1[i]).IdJoueur != unCD.IdJoueur1)
                {
                    i++;
                }
                unCD.LeJoueur1 = (Joueur)this.bindSrcJoueur1[i];
            }

            foreach (ClassementDouble unCD in this.bindSrcClassement)
            {
                int i = 0;
                while (((Joueur)this.bindSrcJoueur2[i]).IdJoueur != unCD.IdJoueur2)
                {
                    i++;
                }
                unCD.LeJoueur2 = (Joueur)this.bindSrcJoueur2[i];
            }

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int place = 1;
                foreach (ClassementDouble unCD in uneC.leClassementDouble)
                {
                    unCD.Position = place;
                    place++;
                }
            }
        }

        /// <summary>
        /// Vérifie si un joueur ne participe pas plusieurs fois à une compétition
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private bool ControleJoueur(int idJoueur, bool modification)
        {
            int i = 0;
            bool doublon = false;
            if (modification == true)
            {
                while (i != (leClassementDoubleBindingSource.Count - 1) && doublon == false)
                {
                    if (((idJoueur == ((ClassementDouble)leClassementDoubleBindingSource[i]).IdJoueur1) || (idJoueur == ((ClassementDouble)leClassementDoubleBindingSource[i]).IdJoueur2)) && (((ClassementDouble)leClassementDoubleBindingSource[i]) != (ClassementDouble)leClassementDoubleBindingSource.Current)) 
                    {
                        doublon = true;
                    }
                    i++;
                }
            }
            else
            {
                while (i != (leClassementDoubleBindingSource.Count - 1) && doublon == false)
                {
                    if ((idJoueur == ((ClassementDouble)leClassementDoubleBindingSource[i]).IdJoueur1) || (idJoueur == ((ClassementDouble)leClassementDoubleBindingSource[i]).IdJoueur2))
                    {
                        doublon = true;
                    }
                    i++;
                }
            }
            return doublon;
        }

        /// <summary>
        /// Récupération des données dans le formulaire compétitions doublettes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmCompetitionDoublette_Load(object sender, EventArgs e)
        {
            this.bindSrcCategorie.DataSource = ClassePasserelle.GetLesCategories();
            this.bindSrcCentre.DataSource = ClassePasserelle.GetLesCentres();
            this.bindSrcJoueur1.DataSource = ClassePasserelle.GetLesJoueurs();
            this.bindSrcJoueur2.DataSource = ClassePasserelle.GetLesJoueurs();

            foreach (Joueur unJ in this.bindSrcJoueur1)
            {
                int i = 0;
                while (((Categorie)this.bindSrcCategorie[i]).IdCategorie != unJ.IdCategorie)
                {
                    i++;
                }
                unJ.LaCategorie = (Categorie)this.bindSrcCategorie[i];
            }


            foreach (Joueur unJ in this.bindSrcJoueur2)
            {
                int i = 0;
                while (((Categorie)this.bindSrcCategorie[i]).IdCategorie != unJ.IdCategorie)
                {
                    i++;
                }
                unJ.LaCategorie = (Categorie)this.bindSrcCategorie[i];
            }
            AppelCompetition();
        }

        /// <summary>
        /// Supprime une compétition doublette
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer_Click(object sender, EventArgs e)
        {
            if (bindSrcCompetition.Count == 0)
            {
                MessageBox.Show("Aucune compétition n'existe actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer cette compétition ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerCompetition(((Competition)bindSrcCompetition.Current).IdCompetition);
                    bindSrcCompetition.RemoveCurrent();
                    bindSrcCompetition.EndEdit();
                    MessageBox.Show("Compétition supprimée", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        /// <summary>
        /// Annule les modifications de compétition
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                bindSrcCompetition.CancelEdit();
                bindSrcCompetition.ResetBindings(false);
                Retablir();
                bindSrcCompetition.ResetBindings(false);
                rajout = false;
            }
            else
            {
                bindSrcCompetition.CancelEdit();
                bindSrcCompetition.ResetBindings(false);
            }
        }

        /// <summary>
        /// Bloque le passage sur un autre onglet lors de l'ajout
        /// Annule les modifications lors du changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (this.rajout == true)
            {
                e.Cancel = true;
            }
            else
            {
                leClassementDoubleBindingSource.CancelEdit();
                leClassementDoubleBindingSource.ResetBindings(false);
                bindSrcCompetition.CancelEdit();
                bindSrcCompetition.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout d'une compétition doublette
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btApliquer_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Ce champ est obligatoire", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        ((Competition)bindSrcCompetition.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                        ((Competition)bindSrcCompetition.Current).IdCentre = ((Centre)bindSrcCentre.Current).IdCentre;

                        Competition laCompetition = new Competition(txtNom.Text, Convert.ToDateTime(dateCompetitionPicker.Text), numEngagement.Value, comboCentre.SelectedIndex + 1, comboCateg.SelectedIndex + 1);

                        int ajout = ClassePasserelle.AjouterCompetitionDouble(laCompetition);

                        ((Competition)bindSrcCompetition.Current).IdCompetition = ajout;

                        bindSrcCompetition.EndEdit();
                        bindSrcCompetition.MoveLast();
                        MessageBox.Show("Compétition ajoutée", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (bindSrcCompetition.Count == 0)
                    {
                        if (MessageBox.Show("Aucune compétition individuelle n'existe \n Voulez-vous en créer une ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            ((Competition)bindSrcCompetition.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                            ((Competition)bindSrcCompetition.Current).IdCentre = ((Centre)bindSrcCentre.Current).IdCentre;

                            ClassementDouble leclassementDouble = new ClassementDouble(0, ((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur1.SelectedItem).IdJoueur, ((Joueur)comboJoueur2.SelectedItem).IdJoueur, (int)numPoints.Value);

                            ClassePasserelle.AjouterClassementDouble(leclassementDouble);

                            AppelCompetition();
                            leClassementDoubleBindingSource.EndEdit();
                            leClassementDoubleBindingSource.MoveLast();
                            MessageBox.Show("Participation ajoutée", "Information", MessageBoxButtons.OK);
                        }
                    }
                    else
                    {
                        ((Competition)bindSrcCompetition.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                        ((Competition)bindSrcCompetition.Current).IdCentre = ((Centre)bindSrcCentre.Current).IdCentre;

                        Competition laCompetition = new Competition(((Competition)bindSrcCompetition.Current).IdCompetition, txtNom.Text, Convert.ToDateTime(dateCompetitionPicker.Text), numEngagement.Value, comboCentre.SelectedIndex + 1, comboCateg.SelectedIndex + 1);
                        ClassePasserelle.ModifierCompetitionDouble(laCompetition);
                        bindSrcCompetition.EndEdit();
                        MessageBox.Show("Compétition modifiée", "Information", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare un nouvel ajout de compétition
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout_Click(object sender, EventArgs e)
        {
            bindSrcCompetition.CancelEdit();
            bindSrcCompetition.ResetBindings(false);
            bindSrcCompetition.AddNew();
            rajout = true;
            btSupprimer.Visible = false;
            btGererAjout.Visible = false;
        }

        /// <summary>
        /// Supprime une participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer2_Click(object sender, EventArgs e)
        {
            leClassementDoubleBindingSource.CancelEdit();
            if (leClassementDoubleBindingSource.Count == 0)
            {
                MessageBox.Show("Aucune équipe ne participe à cette compétition actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer cette participation ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerParticipationDouble(((ClassementDouble)leClassementDoubleBindingSource.Current).NumEquipe);
                    leClassementDoubleBindingSource.RemoveCurrent();
                    leClassementDoubleBindingSource.EndEdit();
                    MessageBox.Show("Participation supprimée", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Annule la modification ou l'ajout de la participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler2_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                leClassementDoubleBindingSource.CancelEdit();
                leClassementDoubleBindingSource.ResetBindings(false);
                Retablir();
                leClassementDoubleBindingSource.ResetBindings(false);
                rajout = false;
            }
            else
            {
                leClassementDoubleBindingSource.CancelEdit();
                leClassementDoubleBindingSource.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout de la participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAppliquer2_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (((Competition)bindSrcCompetition.Current).IdCategorie != ((Joueur)comboJoueur1.SelectedItem).IdCategorie)
                    {
                        MessageBox.Show("L'équipe n'est pas de la bonne catégorie pour faire la compétition", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (ControleJoueur(((Joueur)comboJoueur1.SelectedItem).IdJoueur, false) == false && ControleJoueur(((Joueur)comboJoueur2.SelectedItem).IdJoueur, false) == false)
                    {
                        ((ClassementDouble)leClassementDoubleBindingSource.Current).IdJoueur1 = ((Joueur)bindSrcJoueur1.Current).IdJoueur;
                        ((ClassementDouble)leClassementDoubleBindingSource.Current).IdJoueur2 = ((Joueur)bindSrcJoueur2.Current).IdJoueur;

                        ClassementDouble leclassementDouble = new ClassementDouble(((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur1.SelectedItem).IdJoueur, ((Joueur)comboJoueur2.SelectedItem).IdJoueur, (int)numPoints.Value);

                        leclassementDouble.NumEquipe = ClassePasserelle.AjouterClassementDouble(leclassementDouble);
                        leClassementDoubleBindingSource.EndEdit();
                        leClassementDoubleBindingSource.MoveLast();
                        MessageBox.Show("Participation ajoutée", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                    else
                    {
                        MessageBox.Show("Un des deux joueurs existe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (((Competition)bindSrcCompetition.Current).IdCategorie != ((Joueur)comboJoueur1.SelectedItem).IdCategorie)
                    {
                        MessageBox.Show("Le premier joueur n'est pas de la bonne catégorie pour faire la compétition", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (((Competition)bindSrcCompetition.Current).IdCategorie != ((Joueur)comboJoueur2.SelectedItem).IdCategorie)
                    {
                        MessageBox.Show("Le second joueur n'est pas de la bonne catégorie pour faire la compétition", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (leClassementDoubleBindingSource.Count == 0)
                    {
                        if (MessageBox.Show("Aucune équipe ne participe à cette compétition\n Voulez-vous ajouter celle-ci ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            ((Joueur)comboJoueur1.SelectedItem).IdJoueur = ((Joueur)bindSrcJoueur1.Current).IdJoueur;
                            ((Joueur)comboJoueur2.SelectedItem).IdJoueur = ((Joueur)bindSrcJoueur2.Current).IdJoueur;

                            ClassementDouble leclassementDouble = new ClassementDouble(((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur1.SelectedItem).IdJoueur, ((Joueur)comboJoueur2.SelectedItem).IdJoueur, (int)numPoints.Value);

                            leclassementDouble.NumEquipe = ClassePasserelle.AjouterClassementDouble(leclassementDouble);
                            leClassementDoubleBindingSource.Add(leclassementDouble);
                            leClassementDoubleBindingSource.EndEdit();
                            leClassementDoubleBindingSource.MoveLast();
                            MessageBox.Show("Participation ajoutée", "Information", MessageBoxButtons.OK);
                        }
                    }
                    else if (ControleJoueur(((Joueur)comboJoueur1.SelectedItem).IdJoueur, true) == false && ControleJoueur(((Joueur)comboJoueur2.SelectedItem).IdJoueur, true) == false)
                    {
                        ClassementDouble leClassementDouble = new ClassementDouble(((ClassementDouble)leClassementDoubleBindingSource.Current).NumEquipe, ((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur1.SelectedItem).IdJoueur, ((Joueur)comboJoueur2.SelectedItem).IdJoueur, (int)numPoints.Value);
                        ClassePasserelle.ModifierClassementDouble(leClassementDouble);
                        leClassementDoubleBindingSource.EndEdit();
                        MessageBox.Show("Classement modifié", "Information", MessageBoxButtons.OK);
                    }
                    else
                    {
                        MessageBox.Show("Un des deux joueurs existe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare l'ajout d'une participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout2_Click(object sender, EventArgs e)
        {
            leClassementDoubleBindingSource.CancelEdit();
            leClassementDoubleBindingSource.ResetBindings(false);
            leClassementDoubleBindingSource.AddNew();
            rajout = true;
            btSupprimer2.Visible = false;
            btGererAjout2.Visible = false;
        }

        /// <summary>
        /// Lien direct de la liste au formulaire des compétitions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridCompetition_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 1;
        }

        /// <summary>
        /// Lien direct de la liste au formulaire des participations
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 3;
        }
    }
}
