﻿namespace Classes
{
    partial class FrmCategorie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridCategorie = new System.Windows.Forms.DataGridView();
            this.Libellé = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ageMinDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ageMaxDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindSrcCategorie = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.numMax = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numMin = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.btSupprimer = new System.Windows.Forms.Button();
            this.btAnnuler = new System.Windows.Forms.Button();
            this.btApliquer = new System.Windows.Forms.Button();
            this.btGererAjout = new System.Windows.Forms.Button();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCategorie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCategorie)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMin)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(12, 25);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(920, 523);
            this.tabControl.TabIndex = 2;
            this.tabControl.TabStop = false;
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridCategorie);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(912, 497);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Liste des catégories";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridCategorie
            // 
            this.dataGridCategorie.AllowUserToAddRows = false;
            this.dataGridCategorie.AllowUserToDeleteRows = false;
            this.dataGridCategorie.AutoGenerateColumns = false;
            this.dataGridCategorie.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCategorie.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Libellé,
            this.ageMinDataGridViewTextBoxColumn,
            this.ageMaxDataGridViewTextBoxColumn});
            this.dataGridCategorie.DataSource = this.bindSrcCategorie;
            this.dataGridCategorie.Location = new System.Drawing.Point(19, 16);
            this.dataGridCategorie.Name = "dataGridCategorie";
            this.dataGridCategorie.ReadOnly = true;
            this.dataGridCategorie.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridCategorie.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridCategorie.Size = new System.Drawing.Size(873, 459);
            this.dataGridCategorie.TabIndex = 0;
            this.dataGridCategorie.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridCategorie_CellDoubleClick);
            // 
            // Libellé
            // 
            this.Libellé.DataPropertyName = "Libelle";
            this.Libellé.HeaderText = "Libelle";
            this.Libellé.Name = "Libellé";
            this.Libellé.ReadOnly = true;
            // 
            // ageMinDataGridViewTextBoxColumn
            // 
            this.ageMinDataGridViewTextBoxColumn.DataPropertyName = "AgeMin";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ageMinDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.ageMinDataGridViewTextBoxColumn.HeaderText = "Âge minimal";
            this.ageMinDataGridViewTextBoxColumn.Name = "ageMinDataGridViewTextBoxColumn";
            this.ageMinDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ageMaxDataGridViewTextBoxColumn
            // 
            this.ageMaxDataGridViewTextBoxColumn.DataPropertyName = "AgeMax";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ageMaxDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.ageMaxDataGridViewTextBoxColumn.HeaderText = "Âge maximal";
            this.ageMaxDataGridViewTextBoxColumn.Name = "ageMaxDataGridViewTextBoxColumn";
            this.ageMaxDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bindSrcCategorie
            // 
            this.bindSrcCategorie.DataSource = typeof(Classes.Categorie);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.numMax);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.numMin);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.btSupprimer);
            this.tabPage2.Controls.Add(this.btAnnuler);
            this.tabPage2.Controls.Add(this.btApliquer);
            this.tabPage2.Controls.Add(this.btGererAjout);
            this.tabPage2.Controls.Add(this.txtNom);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 497);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Informations";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // numMax
            // 
            this.numMax.CausesValidation = false;
            this.numMax.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bindSrcCategorie, "AgeMax", true));
            this.numMax.Location = new System.Drawing.Point(104, 167);
            this.numMax.Name = "numMax";
            this.numMax.Size = new System.Drawing.Size(120, 20);
            this.numMax.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.CausesValidation = false;
            this.label4.Location = new System.Drawing.Point(29, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 48;
            this.label4.Text = "Age maximal :";
            // 
            // numMin
            // 
            this.numMin.CausesValidation = false;
            this.numMin.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bindSrcCategorie, "AgeMin", true));
            this.numMin.Location = new System.Drawing.Point(104, 120);
            this.numMin.Name = "numMin";
            this.numMin.Size = new System.Drawing.Size(120, 20);
            this.numMin.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.CausesValidation = false;
            this.label2.Location = new System.Drawing.Point(29, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "Age minimal :";
            // 
            // btSupprimer
            // 
            this.btSupprimer.BackColor = System.Drawing.Color.Red;
            this.btSupprimer.CausesValidation = false;
            this.btSupprimer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btSupprimer.Location = new System.Drawing.Point(769, 416);
            this.btSupprimer.Name = "btSupprimer";
            this.btSupprimer.Size = new System.Drawing.Size(96, 30);
            this.btSupprimer.TabIndex = 45;
            this.btSupprimer.Text = "Supprimer";
            this.btSupprimer.UseVisualStyleBackColor = false;
            this.btSupprimer.Click += new System.EventHandler(this.btSupprimer_Click);
            // 
            // btAnnuler
            // 
            this.btAnnuler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAnnuler.CausesValidation = false;
            this.btAnnuler.Location = new System.Drawing.Point(459, 416);
            this.btAnnuler.Name = "btAnnuler";
            this.btAnnuler.Size = new System.Drawing.Size(142, 30);
            this.btAnnuler.TabIndex = 44;
            this.btAnnuler.Text = "Annuler";
            this.btAnnuler.UseVisualStyleBackColor = false;
            this.btAnnuler.Click += new System.EventHandler(this.btAnnuler_Click);
            // 
            // btApliquer
            // 
            this.btApliquer.BackColor = System.Drawing.Color.Lime;
            this.btApliquer.CausesValidation = false;
            this.btApliquer.Location = new System.Drawing.Point(311, 416);
            this.btApliquer.Name = "btApliquer";
            this.btApliquer.Size = new System.Drawing.Size(142, 30);
            this.btApliquer.TabIndex = 43;
            this.btApliquer.Text = "Valider";
            this.btApliquer.UseVisualStyleBackColor = false;
            this.btApliquer.Click += new System.EventHandler(this.btApliquer_Click);
            // 
            // btGererAjout
            // 
            this.btGererAjout.BackColor = System.Drawing.Color.Blue;
            this.btGererAjout.CausesValidation = false;
            this.btGererAjout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btGererAjout.Location = new System.Drawing.Point(32, 416);
            this.btGererAjout.Name = "btGererAjout";
            this.btGererAjout.Size = new System.Drawing.Size(119, 30);
            this.btGererAjout.TabIndex = 42;
            this.btGererAjout.Text = "Ajouter";
            this.btGererAjout.UseVisualStyleBackColor = false;
            this.btGererAjout.Click += new System.EventHandler(this.btGererAjout_Click);
            // 
            // txtNom
            // 
            this.txtNom.CausesValidation = false;
            this.txtNom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCategorie, "Libelle", true));
            this.txtNom.Location = new System.Drawing.Point(104, 72);
            this.txtNom.MaxLength = 50;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(358, 20);
            this.txtNom.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.CausesValidation = false;
            this.label14.Location = new System.Drawing.Point(15, 365);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "* Saisir tous les champs obligatoires";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.CausesValidation = false;
            this.label3.Location = new System.Drawing.Point(29, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Libellé * :";
            // 
            // FrmCategorie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabControl);
            this.MinimumSize = new System.Drawing.Size(960, 600);
            this.Name = "FrmCategorie";
            this.Text = "Les catégories";
            this.Load += new System.EventHandler(this.FrmCategorie_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCategorie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCategorie)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMin)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridCategorie;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btSupprimer;
        private System.Windows.Forms.Button btAnnuler;
        private System.Windows.Forms.Button btApliquer;
        private System.Windows.Forms.Button btGererAjout;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numMax;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numMin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource bindSrcCategorie;
        private System.Windows.Forms.DataGridViewTextBoxColumn libelleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Libellé;
        private System.Windows.Forms.DataGridViewTextBoxColumn ageMinDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ageMaxDataGridViewTextBoxColumn;
    }
}