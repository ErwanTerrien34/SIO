﻿namespace Projet
{
    partial class FrmCompetitionDoublette
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridCompetition = new System.Windows.Forms.DataGridView();
            this.Nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCompetition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.engagementDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leCentreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laCategorieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindSrcCompetition = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.numEngagement = new System.Windows.Forms.NumericUpDown();
            this.comboCentre = new System.Windows.Forms.ComboBox();
            this.bindSrcCentre = new System.Windows.Forms.BindingSource(this.components);
            this.label13 = new System.Windows.Forms.Label();
            this.btSupprimer = new System.Windows.Forms.Button();
            this.btAnnuler = new System.Windows.Forms.Button();
            this.btApliquer = new System.Windows.Forms.Button();
            this.btGererAjout = new System.Windows.Forms.Button();
            this.comboCateg = new System.Windows.Forms.ComboBox();
            this.bindSrcCategorie = new System.Windows.Forms.BindingSource(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.dateCompetitionPicker = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.leClassementDoubleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bindSrcJoueur2 = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.comboJoueur2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.bindSrcJoueur1 = new System.Windows.Forms.BindingSource(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.numPoints = new System.Windows.Forms.NumericUpDown();
            this.btSupprimer2 = new System.Windows.Forms.Button();
            this.btAnnuler2 = new System.Windows.Forms.Button();
            this.btAppliquer2 = new System.Windows.Forms.Button();
            this.btGererAjout2 = new System.Windows.Forms.Button();
            this.comboJoueur1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.bindSrcClassement = new System.Windows.Forms.BindingSource(this.components);
            this.idCompetitionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateCompetitionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.engagementDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idCentreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leCentreDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idNiveauDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leNiveauDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idCategorieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laCategorieDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idCompetitionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateCompetitionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.engagementDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idCentreDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leCentreDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idNiveauDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leNiveauDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idCategorieDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laCategorieDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leJoueur1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leJoueur2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nbPointsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCompetition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCompetition)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEngagement)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCentre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCategorie)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leClassementDoubleBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcJoueur2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcJoueur1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPoints)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcClassement)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Location = new System.Drawing.Point(12, 28);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(960, 598);
            this.tabControl.TabIndex = 0;
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridCompetition);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(952, 572);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Liste des compétitons";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridCompetition
            // 
            this.dataGridCompetition.AllowUserToAddRows = false;
            this.dataGridCompetition.AllowUserToDeleteRows = false;
            this.dataGridCompetition.AutoGenerateColumns = false;
            this.dataGridCompetition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCompetition.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nom,
            this.DateCompetition,
            this.engagementDataGridViewTextBoxColumn,
            this.leCentreDataGridViewTextBoxColumn,
            this.laCategorieDataGridViewTextBoxColumn});
            this.dataGridCompetition.DataSource = this.bindSrcCompetition;
            this.dataGridCompetition.Location = new System.Drawing.Point(19, 17);
            this.dataGridCompetition.MultiSelect = false;
            this.dataGridCompetition.Name = "dataGridCompetition";
            this.dataGridCompetition.ReadOnly = true;
            this.dataGridCompetition.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridCompetition.Size = new System.Drawing.Size(910, 523);
            this.dataGridCompetition.TabIndex = 3;
            this.dataGridCompetition.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridCompetition_CellDoubleClick);
            // 
            // Nom
            // 
            this.Nom.DataPropertyName = "Nom";
            this.Nom.HeaderText = "Nom compétition";
            this.Nom.Name = "Nom";
            this.Nom.ReadOnly = true;
            this.Nom.Width = 400;
            // 
            // DateCompetition
            // 
            this.DateCompetition.DataPropertyName = "DateCompetition";
            this.DateCompetition.HeaderText = "Date compétition";
            this.DateCompetition.Name = "DateCompetition";
            this.DateCompetition.ReadOnly = true;
            this.DateCompetition.Width = 150;
            // 
            // engagementDataGridViewTextBoxColumn
            // 
            this.engagementDataGridViewTextBoxColumn.DataPropertyName = "Engagement";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.engagementDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.engagementDataGridViewTextBoxColumn.HeaderText = "Engagement";
            this.engagementDataGridViewTextBoxColumn.Name = "engagementDataGridViewTextBoxColumn";
            this.engagementDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // leCentreDataGridViewTextBoxColumn
            // 
            this.leCentreDataGridViewTextBoxColumn.DataPropertyName = "LeCentre";
            this.leCentreDataGridViewTextBoxColumn.HeaderText = "Centre";
            this.leCentreDataGridViewTextBoxColumn.Name = "leCentreDataGridViewTextBoxColumn";
            this.leCentreDataGridViewTextBoxColumn.ReadOnly = true;
            this.leCentreDataGridViewTextBoxColumn.Width = 300;
            // 
            // laCategorieDataGridViewTextBoxColumn
            // 
            this.laCategorieDataGridViewTextBoxColumn.DataPropertyName = "LaCategorie";
            this.laCategorieDataGridViewTextBoxColumn.HeaderText = "Catégorie";
            this.laCategorieDataGridViewTextBoxColumn.Name = "laCategorieDataGridViewTextBoxColumn";
            this.laCategorieDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bindSrcCompetition
            // 
            this.bindSrcCompetition.DataSource = typeof(Classes.Competition);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.numEngagement);
            this.tabPage2.Controls.Add(this.comboCentre);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.btSupprimer);
            this.tabPage2.Controls.Add(this.btAnnuler);
            this.tabPage2.Controls.Add(this.btApliquer);
            this.tabPage2.Controls.Add(this.btGererAjout);
            this.tabPage2.Controls.Add(this.comboCateg);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.dateCompetitionPicker);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtNom);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(952, 572);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Informations sur la compétition";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // numEngagement
            // 
            this.numEngagement.CausesValidation = false;
            this.numEngagement.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bindSrcCompetition, "Engagement", true));
            this.numEngagement.DecimalPlaces = 2;
            this.numEngagement.Location = new System.Drawing.Point(151, 120);
            this.numEngagement.Name = "numEngagement";
            this.numEngagement.Size = new System.Drawing.Size(120, 20);
            this.numEngagement.TabIndex = 77;
            // 
            // comboCentre
            // 
            this.comboCentre.CausesValidation = false;
            this.comboCentre.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindSrcCompetition, "leCentre", true));
            this.comboCentre.DataSource = this.bindSrcCentre;
            this.comboCentre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCentre.FormattingEnabled = true;
            this.comboCentre.Location = new System.Drawing.Point(151, 170);
            this.comboCentre.Name = "comboCentre";
            this.comboCentre.Size = new System.Drawing.Size(372, 21);
            this.comboCentre.TabIndex = 76;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.CausesValidation = false;
            this.label13.Location = new System.Drawing.Point(29, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 75;
            this.label13.Text = "Centre :";
            // 
            // btSupprimer
            // 
            this.btSupprimer.BackColor = System.Drawing.Color.Red;
            this.btSupprimer.CausesValidation = false;
            this.btSupprimer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btSupprimer.Location = new System.Drawing.Point(788, 432);
            this.btSupprimer.Name = "btSupprimer";
            this.btSupprimer.Size = new System.Drawing.Size(96, 30);
            this.btSupprimer.TabIndex = 74;
            this.btSupprimer.Text = "Supprimer";
            this.btSupprimer.UseVisualStyleBackColor = false;
            this.btSupprimer.Click += new System.EventHandler(this.btSupprimer_Click);
            // 
            // btAnnuler
            // 
            this.btAnnuler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAnnuler.CausesValidation = false;
            this.btAnnuler.Location = new System.Drawing.Point(478, 432);
            this.btAnnuler.Name = "btAnnuler";
            this.btAnnuler.Size = new System.Drawing.Size(142, 30);
            this.btAnnuler.TabIndex = 73;
            this.btAnnuler.Text = "Annuler";
            this.btAnnuler.UseVisualStyleBackColor = false;
            this.btAnnuler.Click += new System.EventHandler(this.btAnnuler_Click);
            // 
            // btApliquer
            // 
            this.btApliquer.BackColor = System.Drawing.Color.Lime;
            this.btApliquer.CausesValidation = false;
            this.btApliquer.Location = new System.Drawing.Point(330, 432);
            this.btApliquer.Name = "btApliquer";
            this.btApliquer.Size = new System.Drawing.Size(142, 30);
            this.btApliquer.TabIndex = 72;
            this.btApliquer.Text = "Valider";
            this.btApliquer.UseVisualStyleBackColor = false;
            this.btApliquer.Click += new System.EventHandler(this.btApliquer_Click);
            // 
            // btGererAjout
            // 
            this.btGererAjout.BackColor = System.Drawing.Color.Blue;
            this.btGererAjout.CausesValidation = false;
            this.btGererAjout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btGererAjout.Location = new System.Drawing.Point(51, 432);
            this.btGererAjout.Name = "btGererAjout";
            this.btGererAjout.Size = new System.Drawing.Size(134, 30);
            this.btGererAjout.TabIndex = 71;
            this.btGererAjout.Text = "Ajouter";
            this.btGererAjout.UseVisualStyleBackColor = false;
            this.btGererAjout.Click += new System.EventHandler(this.btGererAjout_Click);
            // 
            // comboCateg
            // 
            this.comboCateg.CausesValidation = false;
            this.comboCateg.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindSrcCompetition, "LaCategorie", true));
            this.comboCateg.DataSource = this.bindSrcCategorie;
            this.comboCateg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCateg.FormattingEnabled = true;
            this.comboCateg.Location = new System.Drawing.Point(151, 214);
            this.comboCateg.Name = "comboCateg";
            this.comboCateg.Size = new System.Drawing.Size(121, 21);
            this.comboCateg.TabIndex = 70;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.CausesValidation = false;
            this.label14.Location = new System.Drawing.Point(34, 381);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 13);
            this.label14.TabIndex = 63;
            this.label14.Text = "* Saisir tous les champs obligatoires";
            // 
            // dateCompetitionPicker
            // 
            this.dateCompetitionPicker.CausesValidation = false;
            this.dateCompetitionPicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bindSrcCompetition, "DateCompetition", true));
            this.dateCompetitionPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateCompetitionPicker.Location = new System.Drawing.Point(151, 79);
            this.dateCompetitionPicker.Name = "dateCompetitionPicker";
            this.dateCompetitionPicker.Size = new System.Drawing.Size(103, 20);
            this.dateCompetitionPicker.TabIndex = 61;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.CausesValidation = false;
            this.label12.Location = new System.Drawing.Point(29, 217);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 59;
            this.label12.Text = "Catégorie :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.CausesValidation = false;
            this.label6.Location = new System.Drawing.Point(29, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "Date de la compétition :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.CausesValidation = false;
            this.label4.Location = new System.Drawing.Point(29, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "Engagement :";
            // 
            // txtNom
            // 
            this.txtNom.CausesValidation = false;
            this.txtNom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCompetition, "Nom", true));
            this.txtNom.Location = new System.Drawing.Point(151, 35);
            this.txtNom.MaxLength = 50;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(372, 20);
            this.txtNom.TabIndex = 49;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.CausesValidation = false;
            this.label3.Location = new System.Drawing.Point(29, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 48;
            this.label3.Text = "Nom * :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox4);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(952, 572);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Classement de la compétition";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.CausesValidation = false;
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCompetition, "Nom", true));
            this.textBox4.Location = new System.Drawing.Point(152, 19);
            this.textBox4.MaxLength = 50;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(760, 20);
            this.textBox4.TabIndex = 81;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.CausesValidation = false;
            this.label1.Location = new System.Drawing.Point(28, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 80;
            this.label1.Text = "Nom de la compétition :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.leJoueur1DataGridViewTextBoxColumn,
            this.leJoueur2DataGridViewTextBoxColumn,
            this.nbPointsDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.leClassementDoubleBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(31, 57);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(892, 484);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // leClassementDoubleBindingSource
            // 
            this.leClassementDoubleBindingSource.DataMember = "leClassementDouble";
            this.leClassementDoubleBindingSource.DataSource = this.bindSrcCompetition;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.textBox1);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.comboJoueur2);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.textBox3);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.numPoints);
            this.tabPage4.Controls.Add(this.btSupprimer2);
            this.tabPage4.Controls.Add(this.btAnnuler2);
            this.tabPage4.Controls.Add(this.btAppliquer2);
            this.tabPage4.Controls.Add(this.btGererAjout2);
            this.tabPage4.Controls.Add(this.comboJoueur1);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(952, 572);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Participation";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur2, "LaCategorie", true));
            this.textBox1.Location = new System.Drawing.Point(646, 106);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 104;
            // 
            // bindSrcJoueur2
            // 
            this.bindSrcJoueur2.DataSource = typeof(Classes.Joueur);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(519, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 13);
            this.label2.TabIndex = 103;
            this.label2.Text = "Catégorie du joueur 2 :";
            // 
            // comboJoueur2
            // 
            this.comboJoueur2.CausesValidation = false;
            this.comboJoueur2.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.leClassementDoubleBindingSource, "LeJoueur2", true));
            this.comboJoueur2.DataSource = this.bindSrcJoueur2;
            this.comboJoueur2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboJoueur2.FormattingEnabled = true;
            this.comboJoueur2.Location = new System.Drawing.Point(646, 66);
            this.comboJoueur2.Name = "comboJoueur2";
            this.comboJoueur2.Size = new System.Drawing.Size(281, 21);
            this.comboJoueur2.TabIndex = 102;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.CausesValidation = false;
            this.label10.Location = new System.Drawing.Point(522, 72);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 101;
            this.label10.Text = "Joueur 2 :";
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur1, "LaCategorie", true));
            this.textBox3.Location = new System.Drawing.Point(139, 103);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 100;
            // 
            // bindSrcJoueur1
            // 
            this.bindSrcJoueur1.DataSource = typeof(Classes.Joueur);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 13);
            this.label8.TabIndex = 99;
            this.label8.Text = "Catégorie du joueur 1 :";
            // 
            // numPoints
            // 
            this.numPoints.CausesValidation = false;
            this.numPoints.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.leClassementDoubleBindingSource, "NbPoints", true));
            this.numPoints.Location = new System.Drawing.Point(136, 302);
            this.numPoints.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numPoints.Name = "numPoints";
            this.numPoints.Size = new System.Drawing.Size(120, 20);
            this.numPoints.TabIndex = 96;
            // 
            // btSupprimer2
            // 
            this.btSupprimer2.BackColor = System.Drawing.Color.Red;
            this.btSupprimer2.CausesValidation = false;
            this.btSupprimer2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btSupprimer2.Location = new System.Drawing.Point(788, 436);
            this.btSupprimer2.Name = "btSupprimer2";
            this.btSupprimer2.Size = new System.Drawing.Size(96, 30);
            this.btSupprimer2.TabIndex = 93;
            this.btSupprimer2.Text = "Supprimer";
            this.btSupprimer2.UseVisualStyleBackColor = false;
            this.btSupprimer2.Click += new System.EventHandler(this.btSupprimer2_Click);
            // 
            // btAnnuler2
            // 
            this.btAnnuler2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAnnuler2.CausesValidation = false;
            this.btAnnuler2.Location = new System.Drawing.Point(478, 436);
            this.btAnnuler2.Name = "btAnnuler2";
            this.btAnnuler2.Size = new System.Drawing.Size(142, 30);
            this.btAnnuler2.TabIndex = 92;
            this.btAnnuler2.Text = "Annuler";
            this.btAnnuler2.UseVisualStyleBackColor = false;
            this.btAnnuler2.Click += new System.EventHandler(this.btAnnuler2_Click);
            // 
            // btAppliquer2
            // 
            this.btAppliquer2.BackColor = System.Drawing.Color.Lime;
            this.btAppliquer2.CausesValidation = false;
            this.btAppliquer2.Location = new System.Drawing.Point(330, 436);
            this.btAppliquer2.Name = "btAppliquer2";
            this.btAppliquer2.Size = new System.Drawing.Size(142, 30);
            this.btAppliquer2.TabIndex = 91;
            this.btAppliquer2.Text = "Valider";
            this.btAppliquer2.UseVisualStyleBackColor = false;
            this.btAppliquer2.Click += new System.EventHandler(this.btAppliquer2_Click);
            // 
            // btGererAjout2
            // 
            this.btGererAjout2.BackColor = System.Drawing.Color.Blue;
            this.btGererAjout2.CausesValidation = false;
            this.btGererAjout2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btGererAjout2.Location = new System.Drawing.Point(51, 436);
            this.btGererAjout2.Name = "btGererAjout2";
            this.btGererAjout2.Size = new System.Drawing.Size(134, 30);
            this.btGererAjout2.TabIndex = 90;
            this.btGererAjout2.Text = "Ajouter";
            this.btGererAjout2.UseVisualStyleBackColor = false;
            this.btGererAjout2.Click += new System.EventHandler(this.btGererAjout2_Click);
            // 
            // comboJoueur1
            // 
            this.comboJoueur1.CausesValidation = false;
            this.comboJoueur1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.leClassementDoubleBindingSource, "LeJoueur1", true));
            this.comboJoueur1.DataSource = this.bindSrcJoueur1;
            this.comboJoueur1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboJoueur1.FormattingEnabled = true;
            this.comboJoueur1.Location = new System.Drawing.Point(139, 66);
            this.comboJoueur1.Name = "comboJoueur1";
            this.comboJoueur1.Size = new System.Drawing.Size(279, 21);
            this.comboJoueur1.TabIndex = 88;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.CausesValidation = false;
            this.label5.Location = new System.Drawing.Point(34, 385);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(174, 13);
            this.label5.TabIndex = 87;
            this.label5.Text = "* Saisir tous les champs obligatoires";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.CausesValidation = false;
            this.label9.Location = new System.Drawing.Point(15, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 82;
            this.label9.Text = "Joueur 1 :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.CausesValidation = false;
            this.label15.Location = new System.Drawing.Point(34, 304);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 13);
            this.label15.TabIndex = 80;
            this.label15.Text = "Nombre de points :";
            // 
            // textBox2
            // 
            this.textBox2.CausesValidation = false;
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCompetition, "Nom", true));
            this.textBox2.Location = new System.Drawing.Point(139, 27);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(788, 20);
            this.textBox2.TabIndex = 79;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.CausesValidation = false;
            this.label16.Location = new System.Drawing.Point(15, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 13);
            this.label16.TabIndex = 78;
            this.label16.Text = "Nom de la compétition :";
            // 
            // bindSrcClassement
            // 
            this.bindSrcClassement.DataSource = typeof(Classes.ClassementDouble);
            // 
            // idCompetitionDataGridViewTextBoxColumn
            // 
            this.idCompetitionDataGridViewTextBoxColumn.DataPropertyName = "IdCompetition";
            this.idCompetitionDataGridViewTextBoxColumn.HeaderText = "IdCompetition";
            this.idCompetitionDataGridViewTextBoxColumn.Name = "idCompetitionDataGridViewTextBoxColumn";
            // 
            // nomDataGridViewTextBoxColumn
            // 
            this.nomDataGridViewTextBoxColumn.DataPropertyName = "Nom";
            this.nomDataGridViewTextBoxColumn.HeaderText = "Nom";
            this.nomDataGridViewTextBoxColumn.Name = "nomDataGridViewTextBoxColumn";
            // 
            // dateCompetitionDataGridViewTextBoxColumn
            // 
            this.dateCompetitionDataGridViewTextBoxColumn.DataPropertyName = "DateCompetition";
            this.dateCompetitionDataGridViewTextBoxColumn.HeaderText = "DateCompetition";
            this.dateCompetitionDataGridViewTextBoxColumn.Name = "dateCompetitionDataGridViewTextBoxColumn";
            // 
            // engagementDataGridViewTextBoxColumn1
            // 
            this.engagementDataGridViewTextBoxColumn1.DataPropertyName = "Engagement";
            this.engagementDataGridViewTextBoxColumn1.HeaderText = "Engagement";
            this.engagementDataGridViewTextBoxColumn1.Name = "engagementDataGridViewTextBoxColumn1";
            // 
            // idCentreDataGridViewTextBoxColumn
            // 
            this.idCentreDataGridViewTextBoxColumn.DataPropertyName = "IdCentre";
            this.idCentreDataGridViewTextBoxColumn.HeaderText = "IdCentre";
            this.idCentreDataGridViewTextBoxColumn.Name = "idCentreDataGridViewTextBoxColumn";
            // 
            // leCentreDataGridViewTextBoxColumn1
            // 
            this.leCentreDataGridViewTextBoxColumn1.DataPropertyName = "LeCentre";
            this.leCentreDataGridViewTextBoxColumn1.HeaderText = "LeCentre";
            this.leCentreDataGridViewTextBoxColumn1.Name = "leCentreDataGridViewTextBoxColumn1";
            // 
            // idNiveauDataGridViewTextBoxColumn
            // 
            this.idNiveauDataGridViewTextBoxColumn.DataPropertyName = "IdNiveau";
            this.idNiveauDataGridViewTextBoxColumn.HeaderText = "IdNiveau";
            this.idNiveauDataGridViewTextBoxColumn.Name = "idNiveauDataGridViewTextBoxColumn";
            // 
            // leNiveauDataGridViewTextBoxColumn1
            // 
            this.leNiveauDataGridViewTextBoxColumn1.DataPropertyName = "LeNiveau";
            this.leNiveauDataGridViewTextBoxColumn1.HeaderText = "LeNiveau";
            this.leNiveauDataGridViewTextBoxColumn1.Name = "leNiveauDataGridViewTextBoxColumn1";
            // 
            // idCategorieDataGridViewTextBoxColumn
            // 
            this.idCategorieDataGridViewTextBoxColumn.DataPropertyName = "IdCategorie";
            this.idCategorieDataGridViewTextBoxColumn.HeaderText = "IdCategorie";
            this.idCategorieDataGridViewTextBoxColumn.Name = "idCategorieDataGridViewTextBoxColumn";
            // 
            // laCategorieDataGridViewTextBoxColumn1
            // 
            this.laCategorieDataGridViewTextBoxColumn1.DataPropertyName = "LaCategorie";
            this.laCategorieDataGridViewTextBoxColumn1.HeaderText = "LaCategorie";
            this.laCategorieDataGridViewTextBoxColumn1.Name = "laCategorieDataGridViewTextBoxColumn1";
            // 
            // idCompetitionDataGridViewTextBoxColumn1
            // 
            this.idCompetitionDataGridViewTextBoxColumn1.DataPropertyName = "IdCompetition";
            this.idCompetitionDataGridViewTextBoxColumn1.HeaderText = "IdCompetition";
            this.idCompetitionDataGridViewTextBoxColumn1.Name = "idCompetitionDataGridViewTextBoxColumn1";
            // 
            // nomDataGridViewTextBoxColumn1
            // 
            this.nomDataGridViewTextBoxColumn1.DataPropertyName = "Nom";
            this.nomDataGridViewTextBoxColumn1.HeaderText = "Nom";
            this.nomDataGridViewTextBoxColumn1.Name = "nomDataGridViewTextBoxColumn1";
            // 
            // dateCompetitionDataGridViewTextBoxColumn1
            // 
            this.dateCompetitionDataGridViewTextBoxColumn1.DataPropertyName = "DateCompetition";
            this.dateCompetitionDataGridViewTextBoxColumn1.HeaderText = "DateCompetition";
            this.dateCompetitionDataGridViewTextBoxColumn1.Name = "dateCompetitionDataGridViewTextBoxColumn1";
            // 
            // engagementDataGridViewTextBoxColumn2
            // 
            this.engagementDataGridViewTextBoxColumn2.DataPropertyName = "Engagement";
            this.engagementDataGridViewTextBoxColumn2.HeaderText = "Engagement";
            this.engagementDataGridViewTextBoxColumn2.Name = "engagementDataGridViewTextBoxColumn2";
            // 
            // idCentreDataGridViewTextBoxColumn1
            // 
            this.idCentreDataGridViewTextBoxColumn1.DataPropertyName = "IdCentre";
            this.idCentreDataGridViewTextBoxColumn1.HeaderText = "IdCentre";
            this.idCentreDataGridViewTextBoxColumn1.Name = "idCentreDataGridViewTextBoxColumn1";
            // 
            // leCentreDataGridViewTextBoxColumn2
            // 
            this.leCentreDataGridViewTextBoxColumn2.DataPropertyName = "LeCentre";
            this.leCentreDataGridViewTextBoxColumn2.HeaderText = "LeCentre";
            this.leCentreDataGridViewTextBoxColumn2.Name = "leCentreDataGridViewTextBoxColumn2";
            // 
            // idNiveauDataGridViewTextBoxColumn1
            // 
            this.idNiveauDataGridViewTextBoxColumn1.DataPropertyName = "IdNiveau";
            this.idNiveauDataGridViewTextBoxColumn1.HeaderText = "IdNiveau";
            this.idNiveauDataGridViewTextBoxColumn1.Name = "idNiveauDataGridViewTextBoxColumn1";
            // 
            // leNiveauDataGridViewTextBoxColumn2
            // 
            this.leNiveauDataGridViewTextBoxColumn2.DataPropertyName = "LeNiveau";
            this.leNiveauDataGridViewTextBoxColumn2.HeaderText = "LeNiveau";
            this.leNiveauDataGridViewTextBoxColumn2.Name = "leNiveauDataGridViewTextBoxColumn2";
            // 
            // idCategorieDataGridViewTextBoxColumn1
            // 
            this.idCategorieDataGridViewTextBoxColumn1.DataPropertyName = "IdCategorie";
            this.idCategorieDataGridViewTextBoxColumn1.HeaderText = "IdCategorie";
            this.idCategorieDataGridViewTextBoxColumn1.Name = "idCategorieDataGridViewTextBoxColumn1";
            // 
            // laCategorieDataGridViewTextBoxColumn2
            // 
            this.laCategorieDataGridViewTextBoxColumn2.DataPropertyName = "LaCategorie";
            this.laCategorieDataGridViewTextBoxColumn2.HeaderText = "LaCategorie";
            this.laCategorieDataGridViewTextBoxColumn2.Name = "laCategorieDataGridViewTextBoxColumn2";
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Position";
            this.Column1.HeaderText = "Position";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 60;
            // 
            // leJoueur1DataGridViewTextBoxColumn
            // 
            this.leJoueur1DataGridViewTextBoxColumn.DataPropertyName = "LeJoueur1";
            this.leJoueur1DataGridViewTextBoxColumn.HeaderText = "Joueur 1";
            this.leJoueur1DataGridViewTextBoxColumn.Name = "leJoueur1DataGridViewTextBoxColumn";
            this.leJoueur1DataGridViewTextBoxColumn.ReadOnly = true;
            this.leJoueur1DataGridViewTextBoxColumn.Width = 200;
            // 
            // leJoueur2DataGridViewTextBoxColumn
            // 
            this.leJoueur2DataGridViewTextBoxColumn.DataPropertyName = "LeJoueur2";
            this.leJoueur2DataGridViewTextBoxColumn.HeaderText = "Joueur 2";
            this.leJoueur2DataGridViewTextBoxColumn.Name = "leJoueur2DataGridViewTextBoxColumn";
            this.leJoueur2DataGridViewTextBoxColumn.ReadOnly = true;
            this.leJoueur2DataGridViewTextBoxColumn.Width = 200;
            // 
            // nbPointsDataGridViewTextBoxColumn
            // 
            this.nbPointsDataGridViewTextBoxColumn.DataPropertyName = "NbPoints";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.nbPointsDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.nbPointsDataGridViewTextBoxColumn.HeaderText = "Nombre points";
            this.nbPointsDataGridViewTextBoxColumn.Name = "nbPointsDataGridViewTextBoxColumn";
            this.nbPointsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // FrmCompetitionDoublette
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabControl);
            this.MinimumSize = new System.Drawing.Size(960, 600);
            this.Name = "FrmCompetitionDoublette";
            this.Text = "Compétitions";
            this.Load += new System.EventHandler(this.FrmCompetitionDoublette_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCompetition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCompetition)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEngagement)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCentre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCategorie)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leClassementDoubleBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcJoueur2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcJoueur1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPoints)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcClassement)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridCompetition;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomCentreDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bindSrcCompetition;
        private System.Windows.Forms.Button btSupprimer;
        private System.Windows.Forms.Button btAnnuler;
        private System.Windows.Forms.Button btApliquer;
        private System.Windows.Forms.Button btGererAjout;
        private System.Windows.Forms.ComboBox comboCateg;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateCompetitionPicker;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboCentre;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numEngagement;
        private System.Windows.Forms.BindingSource bindSrcCategorie;
        private System.Windows.Forms.BindingSource bindSrcCentre;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource bindSrcJoueur1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.NumericUpDown numPoints;
        private System.Windows.Forms.Button btSupprimer2;
        private System.Windows.Forms.Button btAnnuler2;
        private System.Windows.Forms.Button btAppliquer2;
        private System.Windows.Forms.Button btGererAjout2;
        private System.Windows.Forms.ComboBox comboJoueur1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.BindingSource bindSrcClassement;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCompetitionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateCompetitionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn engagementDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCentreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn leCentreDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idNiveauDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn leNiveauDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCategorieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn laCategorieDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCompetitionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateCompetitionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn engagementDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCentreDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn leCentreDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idNiveauDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn leNiveauDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idCategorieDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn laCategorieDataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.BindingSource leClassementDoubleBindingSource;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboJoueur2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.BindingSource bindSrcJoueur2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCompetition;
        private System.Windows.Forms.DataGridViewTextBoxColumn engagementDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn leCentreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn laCategorieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn leJoueur1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn leJoueur2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nbPointsDataGridViewTextBoxColumn;
    }
}