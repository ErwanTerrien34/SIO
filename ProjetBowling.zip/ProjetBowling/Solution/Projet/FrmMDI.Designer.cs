﻿namespace Projet
{
    partial class FrmMDI
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMDI));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.qUITTERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.joueursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compétitionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.individuelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doubletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.centreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catégorieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.niveauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.qUITTERToolStripMenuItem,
            this.joueursToolStripMenuItem,
            this.compétitionToolStripMenuItem,
            this.centreToolStripMenuItem,
            this.catégorieToolStripMenuItem,
            this.niveauToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // qUITTERToolStripMenuItem
            // 
            this.qUITTERToolStripMenuItem.Name = "qUITTERToolStripMenuItem";
            resources.ApplyResources(this.qUITTERToolStripMenuItem, "qUITTERToolStripMenuItem");
            this.qUITTERToolStripMenuItem.Click += new System.EventHandler(this.qUITTERToolStripMenuItem_Click);
            // 
            // joueursToolStripMenuItem
            // 
            this.joueursToolStripMenuItem.Name = "joueursToolStripMenuItem";
            resources.ApplyResources(this.joueursToolStripMenuItem, "joueursToolStripMenuItem");
            this.joueursToolStripMenuItem.Click += new System.EventHandler(this.joueursToolStripMenuItem_Click);
            // 
            // compétitionToolStripMenuItem
            // 
            this.compétitionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.individuelleToolStripMenuItem,
            this.doubletteToolStripMenuItem});
            this.compétitionToolStripMenuItem.Name = "compétitionToolStripMenuItem";
            resources.ApplyResources(this.compétitionToolStripMenuItem, "compétitionToolStripMenuItem");
            // 
            // individuelleToolStripMenuItem
            // 
            this.individuelleToolStripMenuItem.Name = "individuelleToolStripMenuItem";
            resources.ApplyResources(this.individuelleToolStripMenuItem, "individuelleToolStripMenuItem");
            this.individuelleToolStripMenuItem.Click += new System.EventHandler(this.individuelleToolStripMenuItem_Click);
            // 
            // doubletteToolStripMenuItem
            // 
            this.doubletteToolStripMenuItem.Name = "doubletteToolStripMenuItem";
            resources.ApplyResources(this.doubletteToolStripMenuItem, "doubletteToolStripMenuItem");
            this.doubletteToolStripMenuItem.Click += new System.EventHandler(this.doubletteToolStripMenuItem_Click);
            // 
            // centreToolStripMenuItem
            // 
            this.centreToolStripMenuItem.Name = "centreToolStripMenuItem";
            resources.ApplyResources(this.centreToolStripMenuItem, "centreToolStripMenuItem");
            this.centreToolStripMenuItem.Click += new System.EventHandler(this.centreToolStripMenuItem_Click);
            // 
            // catégorieToolStripMenuItem
            // 
            this.catégorieToolStripMenuItem.Name = "catégorieToolStripMenuItem";
            resources.ApplyResources(this.catégorieToolStripMenuItem, "catégorieToolStripMenuItem");
            this.catégorieToolStripMenuItem.Click += new System.EventHandler(this.catégorieToolStripMenuItem_Click);
            // 
            // niveauToolStripMenuItem
            // 
            this.niveauToolStripMenuItem.Name = "niveauToolStripMenuItem";
            resources.ApplyResources(this.niveauToolStripMenuItem, "niveauToolStripMenuItem");
            this.niveauToolStripMenuItem.Click += new System.EventHandler(this.niveauToolStripMenuItem_Click);
            // 
            // FrmMDI
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMDI";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMDI_FormClosing);
            this.Load += new System.EventHandler(this.FrmMDI_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem qUITTERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem joueursToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem compétitionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem individuelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doubletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem centreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catégorieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem niveauToolStripMenuItem;
    }
}

