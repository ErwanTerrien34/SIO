﻿namespace Projet
{
    partial class FrmJoueur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridJoueur = new System.Windows.Forms.DataGridView();
            this.numLicenceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prenomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateNaissanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codePostalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.villeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numTelephoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresseMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LeNiveau = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LaCategorie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindSrcJoueur = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btSupprimer = new System.Windows.Forms.Button();
            this.btAnnuler = new System.Windows.Forms.Button();
            this.btApliquer = new System.Windows.Forms.Button();
            this.btGererAjout = new System.Windows.Forms.Button();
            this.comboCateg = new System.Windows.Forms.ComboBox();
            this.bindSrcCategorie = new System.Windows.Forms.BindingSource(this.components);
            this.comboNiveau = new System.Windows.Forms.ComboBox();
            this.bindSrcNiveau = new System.Windows.Forms.BindingSource(this.components);
            this.txtMail = new System.Windows.Forms.TextBox();
            this.txtTelephone = new System.Windows.Forms.MaskedTextBox();
            this.txtVille = new System.Windows.Forms.TextBox();
            this.txtCP = new System.Windows.Forms.MaskedTextBox();
            this.txtAdresse = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dateNaissancePicker = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLicence = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridCompetition = new System.Windows.Forms.DataGridView();
            this.nomDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCompetition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Engagement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindSrcParticipation = new System.Windows.Forms.BindingSource(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridJoueur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcJoueur)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCategorie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcNiveau)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCompetition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcParticipation)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(920, 523);
            this.tabControl.TabIndex = 0;
            this.tabControl.TabStop = false;
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridJoueur);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(912, 497);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Liste des joueurs";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridJoueur
            // 
            this.dataGridJoueur.AllowUserToAddRows = false;
            this.dataGridJoueur.AllowUserToDeleteRows = false;
            this.dataGridJoueur.AutoGenerateColumns = false;
            this.dataGridJoueur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridJoueur.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numLicenceDataGridViewTextBoxColumn,
            this.nomDataGridViewTextBoxColumn,
            this.prenomDataGridViewTextBoxColumn,
            this.dateNaissanceDataGridViewTextBoxColumn,
            this.adresseDataGridViewTextBoxColumn,
            this.codePostalDataGridViewTextBoxColumn,
            this.villeDataGridViewTextBoxColumn,
            this.numTelephoneDataGridViewTextBoxColumn,
            this.adresseMailDataGridViewTextBoxColumn,
            this.LeNiveau,
            this.LaCategorie});
            this.dataGridJoueur.DataSource = this.bindSrcJoueur;
            this.dataGridJoueur.Location = new System.Drawing.Point(19, 16);
            this.dataGridJoueur.Name = "dataGridJoueur";
            this.dataGridJoueur.ReadOnly = true;
            this.dataGridJoueur.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridJoueur.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridJoueur.Size = new System.Drawing.Size(873, 462);
            this.dataGridJoueur.TabIndex = 0;
            this.dataGridJoueur.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridJoueur_CellDoubleClick);
            // 
            // numLicenceDataGridViewTextBoxColumn
            // 
            this.numLicenceDataGridViewTextBoxColumn.DataPropertyName = "NumLicence";
            this.numLicenceDataGridViewTextBoxColumn.HeaderText = "N°Licence";
            this.numLicenceDataGridViewTextBoxColumn.Name = "numLicenceDataGridViewTextBoxColumn";
            this.numLicenceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomDataGridViewTextBoxColumn
            // 
            this.nomDataGridViewTextBoxColumn.DataPropertyName = "Nom";
            this.nomDataGridViewTextBoxColumn.HeaderText = "Nom";
            this.nomDataGridViewTextBoxColumn.Name = "nomDataGridViewTextBoxColumn";
            this.nomDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prenomDataGridViewTextBoxColumn
            // 
            this.prenomDataGridViewTextBoxColumn.DataPropertyName = "Prenom";
            this.prenomDataGridViewTextBoxColumn.HeaderText = "Prénom";
            this.prenomDataGridViewTextBoxColumn.Name = "prenomDataGridViewTextBoxColumn";
            this.prenomDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateNaissanceDataGridViewTextBoxColumn
            // 
            this.dateNaissanceDataGridViewTextBoxColumn.DataPropertyName = "DateNaissance";
            this.dateNaissanceDataGridViewTextBoxColumn.HeaderText = "Date de naissance";
            this.dateNaissanceDataGridViewTextBoxColumn.Name = "dateNaissanceDataGridViewTextBoxColumn";
            this.dateNaissanceDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateNaissanceDataGridViewTextBoxColumn.Width = 120;
            // 
            // adresseDataGridViewTextBoxColumn
            // 
            this.adresseDataGridViewTextBoxColumn.DataPropertyName = "Adresse";
            this.adresseDataGridViewTextBoxColumn.HeaderText = "Adresse";
            this.adresseDataGridViewTextBoxColumn.Name = "adresseDataGridViewTextBoxColumn";
            this.adresseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // codePostalDataGridViewTextBoxColumn
            // 
            this.codePostalDataGridViewTextBoxColumn.DataPropertyName = "CodePostal";
            this.codePostalDataGridViewTextBoxColumn.HeaderText = "Code postal";
            this.codePostalDataGridViewTextBoxColumn.Name = "codePostalDataGridViewTextBoxColumn";
            this.codePostalDataGridViewTextBoxColumn.ReadOnly = true;
            this.codePostalDataGridViewTextBoxColumn.Width = 88;
            // 
            // villeDataGridViewTextBoxColumn
            // 
            this.villeDataGridViewTextBoxColumn.DataPropertyName = "Ville";
            this.villeDataGridViewTextBoxColumn.HeaderText = "Ville";
            this.villeDataGridViewTextBoxColumn.Name = "villeDataGridViewTextBoxColumn";
            this.villeDataGridViewTextBoxColumn.ReadOnly = true;
            this.villeDataGridViewTextBoxColumn.Width = 200;
            // 
            // numTelephoneDataGridViewTextBoxColumn
            // 
            this.numTelephoneDataGridViewTextBoxColumn.DataPropertyName = "NumTelephone";
            this.numTelephoneDataGridViewTextBoxColumn.HeaderText = "Téléphone";
            this.numTelephoneDataGridViewTextBoxColumn.Name = "numTelephoneDataGridViewTextBoxColumn";
            this.numTelephoneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // adresseMailDataGridViewTextBoxColumn
            // 
            this.adresseMailDataGridViewTextBoxColumn.DataPropertyName = "AdresseMail";
            this.adresseMailDataGridViewTextBoxColumn.HeaderText = "Mail";
            this.adresseMailDataGridViewTextBoxColumn.Name = "adresseMailDataGridViewTextBoxColumn";
            this.adresseMailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // LeNiveau
            // 
            this.LeNiveau.DataPropertyName = "LeNiveau";
            this.LeNiveau.HeaderText = "Niveau";
            this.LeNiveau.Name = "LeNiveau";
            this.LeNiveau.ReadOnly = true;
            // 
            // LaCategorie
            // 
            this.LaCategorie.DataPropertyName = "LaCategorie";
            this.LaCategorie.HeaderText = "Catégorie";
            this.LaCategorie.Name = "LaCategorie";
            this.LaCategorie.ReadOnly = true;
            // 
            // bindSrcJoueur
            // 
            this.bindSrcJoueur.DataSource = typeof(Classes.Joueur);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btSupprimer);
            this.tabPage2.Controls.Add(this.btAnnuler);
            this.tabPage2.Controls.Add(this.btApliquer);
            this.tabPage2.Controls.Add(this.btGererAjout);
            this.tabPage2.Controls.Add(this.comboCateg);
            this.tabPage2.Controls.Add(this.comboNiveau);
            this.tabPage2.Controls.Add(this.txtMail);
            this.tabPage2.Controls.Add(this.txtTelephone);
            this.tabPage2.Controls.Add(this.txtVille);
            this.tabPage2.Controls.Add(this.txtCP);
            this.tabPage2.Controls.Add(this.txtAdresse);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.dateNaissancePicker);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtPrenom);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtNom);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.txtLicence);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 497);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Informations";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btSupprimer
            // 
            this.btSupprimer.BackColor = System.Drawing.Color.Red;
            this.btSupprimer.CausesValidation = false;
            this.btSupprimer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btSupprimer.Location = new System.Drawing.Point(769, 416);
            this.btSupprimer.Name = "btSupprimer";
            this.btSupprimer.Size = new System.Drawing.Size(96, 30);
            this.btSupprimer.TabIndex = 45;
            this.btSupprimer.Text = "Supprimer";
            this.btSupprimer.UseVisualStyleBackColor = false;
            this.btSupprimer.Click += new System.EventHandler(this.btSupprimer_Click);
            // 
            // btAnnuler
            // 
            this.btAnnuler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAnnuler.CausesValidation = false;
            this.btAnnuler.Location = new System.Drawing.Point(459, 416);
            this.btAnnuler.Name = "btAnnuler";
            this.btAnnuler.Size = new System.Drawing.Size(142, 30);
            this.btAnnuler.TabIndex = 44;
            this.btAnnuler.Text = "Annuler";
            this.btAnnuler.UseVisualStyleBackColor = false;
            this.btAnnuler.Click += new System.EventHandler(this.btAnnuler_Click);
            // 
            // btApliquer
            // 
            this.btApliquer.BackColor = System.Drawing.Color.Lime;
            this.btApliquer.CausesValidation = false;
            this.btApliquer.Location = new System.Drawing.Point(311, 416);
            this.btApliquer.Name = "btApliquer";
            this.btApliquer.Size = new System.Drawing.Size(142, 30);
            this.btApliquer.TabIndex = 43;
            this.btApliquer.Text = "Valider";
            this.btApliquer.UseVisualStyleBackColor = false;
            this.btApliquer.Click += new System.EventHandler(this.btAppliquer_Click);
            // 
            // btGererAjout
            // 
            this.btGererAjout.BackColor = System.Drawing.Color.Blue;
            this.btGererAjout.CausesValidation = false;
            this.btGererAjout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btGererAjout.Location = new System.Drawing.Point(32, 416);
            this.btGererAjout.Name = "btGererAjout";
            this.btGererAjout.Size = new System.Drawing.Size(119, 30);
            this.btGererAjout.TabIndex = 42;
            this.btGererAjout.Text = "Ajouter";
            this.btGererAjout.UseVisualStyleBackColor = false;
            this.btGererAjout.Click += new System.EventHandler(this.btGererAjout_Click);
            // 
            // comboCateg
            // 
            this.comboCateg.CausesValidation = false;
            this.comboCateg.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindSrcJoueur, "LaCategorie", true));
            this.comboCateg.DataSource = this.bindSrcCategorie;
            this.comboCateg.DisplayMember = "Libelle";
            this.comboCateg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCateg.FormattingEnabled = true;
            this.comboCateg.Location = new System.Drawing.Point(372, 297);
            this.comboCateg.Name = "comboCateg";
            this.comboCateg.Size = new System.Drawing.Size(121, 21);
            this.comboCateg.TabIndex = 41;
            // 
            // bindSrcCategorie
            // 
            this.bindSrcCategorie.DataSource = typeof(Classes.Categorie);
            // 
            // comboNiveau
            // 
            this.comboNiveau.CausesValidation = false;
            this.comboNiveau.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindSrcJoueur, "LeNiveau", true));
            this.comboNiveau.DataSource = this.bindSrcNiveau;
            this.comboNiveau.DisplayMember = "Libelle";
            this.comboNiveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboNiveau.FormattingEnabled = true;
            this.comboNiveau.Location = new System.Drawing.Point(125, 300);
            this.comboNiveau.Name = "comboNiveau";
            this.comboNiveau.Size = new System.Drawing.Size(121, 21);
            this.comboNiveau.TabIndex = 40;
            // 
            // bindSrcNiveau
            // 
            this.bindSrcNiveau.DataSource = typeof(Classes.Niveau);
            // 
            // txtMail
            // 
            this.txtMail.CausesValidation = false;
            this.txtMail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "AdresseMail", true));
            this.txtMail.Location = new System.Drawing.Point(125, 262);
            this.txtMail.MaxLength = 50;
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(358, 20);
            this.txtMail.TabIndex = 39;
            // 
            // txtTelephone
            // 
            this.txtTelephone.CausesValidation = false;
            this.txtTelephone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "NumTelephone", true));
            this.txtTelephone.Location = new System.Drawing.Point(125, 232);
            this.txtTelephone.Mask = "00 00 00 00 00";
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.PromptChar = ' ';
            this.txtTelephone.Size = new System.Drawing.Size(128, 20);
            this.txtTelephone.TabIndex = 38;
            this.txtTelephone.Enter += new System.EventHandler(this.txtTelephone_Enter);
            // 
            // txtVille
            // 
            this.txtVille.CausesValidation = false;
            this.txtVille.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "Ville", true));
            this.txtVille.Location = new System.Drawing.Point(284, 190);
            this.txtVille.MaxLength = 50;
            this.txtVille.Name = "txtVille";
            this.txtVille.Size = new System.Drawing.Size(203, 20);
            this.txtVille.TabIndex = 37;
            // 
            // txtCP
            // 
            this.txtCP.CausesValidation = false;
            this.txtCP.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "CodePostal", true));
            this.txtCP.Location = new System.Drawing.Point(125, 190);
            this.txtCP.Mask = "00000";
            this.txtCP.Name = "txtCP";
            this.txtCP.PromptChar = ' ';
            this.txtCP.Size = new System.Drawing.Size(54, 20);
            this.txtCP.TabIndex = 36;
            this.txtCP.Enter += new System.EventHandler(this.txtCP_Enter);
            // 
            // txtAdresse
            // 
            this.txtAdresse.CausesValidation = false;
            this.txtAdresse.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "Adresse", true));
            this.txtAdresse.Location = new System.Drawing.Point(125, 155);
            this.txtAdresse.MaxLength = 50;
            this.txtAdresse.Name = "txtAdresse";
            this.txtAdresse.Size = new System.Drawing.Size(362, 20);
            this.txtAdresse.TabIndex = 35;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.CausesValidation = false;
            this.label14.Location = new System.Drawing.Point(15, 365);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "* Saisir tous les champs obligatoires";
            // 
            // dateNaissancePicker
            // 
            this.dateNaissancePicker.CausesValidation = false;
            this.dateNaissancePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bindSrcJoueur, "DateNaissance", true));
            this.dateNaissancePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateNaissancePicker.Location = new System.Drawing.Point(125, 121);
            this.dateNaissancePicker.Name = "dateNaissancePicker";
            this.dateNaissancePicker.Size = new System.Drawing.Size(103, 20);
            this.dateNaissancePicker.TabIndex = 32;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.CausesValidation = false;
            this.label12.Location = new System.Drawing.Point(308, 300);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Catégorie :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.CausesValidation = false;
            this.label11.Location = new System.Drawing.Point(17, 300);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Niveau :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.CausesValidation = false;
            this.label10.Location = new System.Drawing.Point(17, 262);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Mail  * :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.CausesValidation = false;
            this.label9.Location = new System.Drawing.Point(15, 232);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Téléphone :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.CausesValidation = false;
            this.label8.Location = new System.Drawing.Point(15, 193);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Code Postal :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.CausesValidation = false;
            this.label7.Location = new System.Drawing.Point(246, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Ville :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.CausesValidation = false;
            this.label6.Location = new System.Drawing.Point(17, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Date de naissance :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.CausesValidation = false;
            this.label4.Location = new System.Drawing.Point(15, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Adresse :";
            // 
            // txtPrenom
            // 
            this.txtPrenom.CausesValidation = false;
            this.txtPrenom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "Prenom", true));
            this.txtPrenom.Location = new System.Drawing.Point(125, 92);
            this.txtPrenom.MaxLength = 50;
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(358, 20);
            this.txtPrenom.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.CausesValidation = false;
            this.label5.Location = new System.Drawing.Point(17, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Prénom * :";
            // 
            // txtNom
            // 
            this.txtNom.CausesValidation = false;
            this.txtNom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "Nom", true));
            this.txtNom.Location = new System.Drawing.Point(125, 58);
            this.txtNom.MaxLength = 50;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(358, 20);
            this.txtNom.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.CausesValidation = false;
            this.label3.Location = new System.Drawing.Point(17, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nom * :";
            // 
            // txtLicence
            // 
            this.txtLicence.CausesValidation = false;
            this.txtLicence.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "NumLicence", true));
            this.txtLicence.Location = new System.Drawing.Point(128, 23);
            this.txtLicence.MaxLength = 10;
            this.txtLicence.Name = "txtLicence";
            this.txtLicence.Size = new System.Drawing.Size(100, 20);
            this.txtLicence.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.CausesValidation = false;
            this.label2.Location = new System.Drawing.Point(15, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "N° licence * :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridCompetition);
            this.tabPage3.Controls.Add(this.textBox1);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(912, 497);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Participations";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridCompetition
            // 
            this.dataGridCompetition.AllowUserToAddRows = false;
            this.dataGridCompetition.AllowUserToDeleteRows = false;
            this.dataGridCompetition.AutoGenerateColumns = false;
            this.dataGridCompetition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCompetition.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nomDataGridViewTextBoxColumn1,
            this.DateCompetition,
            this.Engagement,
            this.Column1});
            this.dataGridCompetition.DataSource = this.bindSrcParticipation;
            this.dataGridCompetition.Location = new System.Drawing.Point(18, 54);
            this.dataGridCompetition.MultiSelect = false;
            this.dataGridCompetition.Name = "dataGridCompetition";
            this.dataGridCompetition.ReadOnly = true;
            this.dataGridCompetition.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridCompetition.Size = new System.Drawing.Size(861, 420);
            this.dataGridCompetition.TabIndex = 2;
            // 
            // nomDataGridViewTextBoxColumn1
            // 
            this.nomDataGridViewTextBoxColumn1.DataPropertyName = "Nom";
            this.nomDataGridViewTextBoxColumn1.HeaderText = "Nom compétition";
            this.nomDataGridViewTextBoxColumn1.Name = "nomDataGridViewTextBoxColumn1";
            this.nomDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nomDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.nomDataGridViewTextBoxColumn1.Width = 478;
            // 
            // DateCompetition
            // 
            this.DateCompetition.DataPropertyName = "DateCompetition";
            this.DateCompetition.HeaderText = "Date compétition";
            this.DateCompetition.Name = "DateCompetition";
            this.DateCompetition.ReadOnly = true;
            this.DateCompetition.Width = 120;
            // 
            // Engagement
            // 
            this.Engagement.DataPropertyName = "TypeCompetition";
            this.Engagement.HeaderText = "Type compétition";
            this.Engagement.Name = "Engagement";
            this.Engagement.ReadOnly = true;
            this.Engagement.Width = 120;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "NbPointsObtenus";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column1.HeaderText = "Points obtenus";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // bindSrcParticipation
            // 
            this.bindSrcParticipation.DataMember = "LesParticipationsDuJoueur";
            this.bindSrcParticipation.DataSource = this.bindSrcJoueur;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcJoueur, "Resume", true));
            this.textBox1.Location = new System.Drawing.Point(167, 17);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(370, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(29, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(132, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Nom et prénom du joueur :";
            // 
            // FrmJoueur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabControl);
            this.MinimumSize = new System.Drawing.Size(960, 600);
            this.Name = "FrmJoueur";
            this.Text = "Joueurs";
            this.Load += new System.EventHandler(this.FrmJoueur_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridJoueur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcJoueur)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCategorie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcNiveau)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCompetition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcParticipation)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridJoueur;
        private System.Windows.Forms.BindingSource bindSrcJoueur;
        private System.Windows.Forms.TextBox txtLicence;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.DateTimePicker dateNaissancePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.BindingSource bindSrcNiveau;
        private System.Windows.Forms.BindingSource bindSrcCategorie;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridCompetition;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btSupprimer;
        private System.Windows.Forms.Button btAnnuler;
        private System.Windows.Forms.Button btApliquer;
        private System.Windows.Forms.Button btGererAjout;
        private System.Windows.Forms.ComboBox comboCateg;
        private System.Windows.Forms.ComboBox comboNiveau;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.MaskedTextBox txtTelephone;
        private System.Windows.Forms.TextBox txtVille;
        private System.Windows.Forms.MaskedTextBox txtCP;
        private System.Windows.Forms.TextBox txtAdresse;
        private System.Windows.Forms.BindingSource bindSrcParticipation;
        private System.Windows.Forms.DataGridViewTextBoxColumn numLicenceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prenomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateNaissanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codePostalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn villeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numTelephoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresseMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LeNiveau;
        private System.Windows.Forms.DataGridViewTextBoxColumn LaCategorie;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCompetition;
        private System.Windows.Forms.DataGridViewTextBoxColumn Engagement;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    }
}