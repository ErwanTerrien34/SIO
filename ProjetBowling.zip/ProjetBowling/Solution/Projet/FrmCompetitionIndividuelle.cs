﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet
{
    /// <summary>
    /// Formulaire de recensement des compétitions individuelles
    /// </summary>
    public partial class FrmCompetitionIndividuelle : Form
    {
        /// <summary>
        /// Vérifie si une donnée est en cours d'ajout
        /// </summary>
        private bool rajout = false;

        public FrmCompetitionIndividuelle()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Après ajout ou annulation de l'ajout
        /// </summary>
        private void Retablir()
        {
            btSupprimer.Visible = true;
            btSupprimer2.Visible = true;
            btGererAjout.Visible = true;
            btGererAjout2.Visible = true;
        }

        /// <summary>
        /// Associe les compétitions aux joueurs
        /// </summary>
        private void AppelCompetition()
        {
            this.bindSrcCompetition.DataSource = ClassePasserelle.GetLesCompetitionsIndividuelles();
            this.bindSrcClassement.DataSource = ClassePasserelle.GetClassementIndividuel();

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int i = 0;
                while (((Niveau)this.bindSrcNiveau[i]).IdNiveau != uneC.IdNiveau)
                {
                    i++;
                }
                uneC.LeNiveau = (Niveau)this.bindSrcNiveau[i];
            }

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int i = 0;
                while (((Categorie)this.bindSrcCategorie[i]).IdCategorie != uneC.IdCategorie)
                {
                    i++;
                }
                uneC.LaCategorie = (Categorie)this.bindSrcCategorie[i];
            }

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int i = 0;
                while (((Centre)this.bindSrcCentre[i]).IdCentre != uneC.IdCentre)
                {
                    i++;
                }
                uneC.LeCentre = (Centre)this.bindSrcCentre[i];
            }

            foreach (ClassementIndividuel unCI in this.bindSrcClassement)
            {
                int i = 0;
                while (((Competition)this.bindSrcCompetition[i]).IdCompetition != unCI.IdCompetition)
                {
                    i++;
                }
                ((Competition)this.bindSrcCompetition[i]).leClassementIndividuel.Add(unCI);
                unCI.LaCompetition = (Competition)this.bindSrcCompetition[i];
            }

            foreach (ClassementIndividuel unCI in this.bindSrcClassement)
            {
                int i = 0;
                while (((Joueur)this.bindSrcJoueur[i]).IdJoueur != unCI.IdJoueur)
                {
                    i++;
                }
                unCI.LeJoueur = (Joueur)this.bindSrcJoueur[i];
            }

            foreach (Competition uneC in this.bindSrcCompetition)
            {
                int place = 1;
                foreach (ClassementIndividuel unCI in uneC.leClassementIndividuel)
                {
                    unCI.Position = place;
                    place++;
                }
            }
        }

        /// <summary>
        /// Vérifie si un joueur ne participe pas plusieurs fois à une compétition
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private bool ControleJoueur(int idJoueur, bool modification)
        {
            int i = 0;
            bool doublon = false;
            if (modification == false)
            {
                while (i != (leClassementIndividuelBindingSource.Count) && doublon == false)
                {
                    if (idJoueur == ((ClassementIndividuel)leClassementIndividuelBindingSource[i]).IdJoueur)
                    {
                        doublon = true;
                    }
                    i++;
                }
            }
            else
            {
                while (i != (leClassementIndividuelBindingSource.Count) && doublon == false)
                {
                    if (idJoueur == ((ClassementIndividuel)leClassementIndividuelBindingSource[i]).IdJoueur && ((ClassementIndividuel)leClassementIndividuelBindingSource[i]) != ((ClassementIndividuel)leClassementIndividuelBindingSource.Current))
                    {
                        doublon = true;
                    }
                    i++;
                }
            }
            return doublon;
        }

        /// <summary>
        /// Récupération des données dans le formulaire compétitions individuelles
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmCompetitionIndividuelle_Load(object sender, EventArgs e)
        {
            this.bindSrcNiveau.DataSource = ClassePasserelle.GetLesNiveaux();
            this.bindSrcCategorie.DataSource = ClassePasserelle.GetLesCategories();
            this.bindSrcCentre.DataSource = ClassePasserelle.GetLesCentres();
            this.bindSrcJoueur.DataSource = ClassePasserelle.GetLesJoueurs();

            foreach (Joueur unJ in this.bindSrcJoueur)
            {
                int i = 0;
                while (((Niveau)this.bindSrcNiveau[i]).IdNiveau != unJ.IdNiveau)
                {
                    i++;
                }
                unJ.LeNiveau = (Niveau)this.bindSrcNiveau[i];
            }

            foreach (Joueur unJ in this.bindSrcJoueur)
            {
                int i = 0;
                while (((Categorie)this.bindSrcCategorie[i]).IdCategorie != unJ.IdCategorie)
                {
                    i++;
                }
                unJ.LaCategorie = (Categorie)this.bindSrcCategorie[i];
            }
            AppelCompetition();
        }

        /// <summary>
        /// Supprime une compétition individuelle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer_Click(object sender, EventArgs e)
        {
            if (bindSrcCompetition.Count == 0)
            {
                MessageBox.Show("Aucune compétition n'existe actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer cette compétition ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerCompetition(((Competition)bindSrcCompetition.Current).IdCompetition);
                    bindSrcCompetition.RemoveCurrent();
                    bindSrcCompetition.EndEdit();
                    MessageBox.Show("Compétition supprimé", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        /// <summary>
        /// Annule les modifications de compétition
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                bindSrcCompetition.CancelEdit();
                bindSrcCompetition.ResetBindings(false);
                Retablir();
                rajout = false;
            }
            else
            {
                bindSrcCompetition.CancelEdit();
                bindSrcCompetition.ResetBindings(false);
            }
        }

        /// <summary>
        /// Bloque le passage sur un autre onglet lors de l'ajout
        /// Annule les modifications lors du changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (this.rajout == true)
            {
                e.Cancel = true;
            }
            else
            {
                leClassementIndividuelBindingSource.CancelEdit();
                leClassementIndividuelBindingSource.ResetBindings(false);
                bindSrcCompetition.CancelEdit();
                bindSrcCompetition.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout d'une compétition individuelle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btApliquer_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        ((Competition)bindSrcCompetition.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                        ((Competition)bindSrcCompetition.Current).IdNiveau = ((Niveau)bindSrcNiveau.Current).IdNiveau;
                        ((Competition)bindSrcCompetition.Current).IdCentre = ((Centre)bindSrcCentre.Current).IdCentre;

                        Competition laCompetition = new Competition(txtNom.Text, Convert.ToDateTime(dateCompetitionPicker.Text), numEngagement.Value, comboCentre.SelectedIndex + 1, comboNiveau.SelectedIndex + 1, comboCateg.SelectedIndex + 1);

                        string leNom = txtNom.Text;
                        DateTime laDate = Convert.ToDateTime(dateCompetitionPicker.Text);
                        decimal lengagement = numEngagement.Value;
                        int leNiveau = comboNiveau.SelectedIndex + 1;
                        int laCategorie = comboCateg.SelectedIndex + 1;
                        int leCentre = comboCateg.SelectedIndex + 1;
                        int ajout = ClassePasserelle.AjouterCompetitionIndividuelle(laCompetition);

                        laCompetition = new Competition(ajout, leNom, laDate, lengagement, leCentre, leNiveau, laCategorie);
                        AppelCompetition();
                        bindSrcCompetition.EndEdit();
                        bindSrcCompetition.MoveLast();
                        MessageBox.Show("Compétition ajoutée", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (bindSrcCompetition.Count == 0)
                    {
                        if (MessageBox.Show("Aucune compétition individuelle n'existe \n Voulez-vous en créer une ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            ((Competition)bindSrcCompetition.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                            ((Competition)bindSrcCompetition.Current).IdNiveau = ((Niveau)bindSrcNiveau.Current).IdNiveau;
                            ((Competition)bindSrcCompetition.Current).IdCentre = ((Centre)bindSrcCentre.Current).IdCentre;

                            Competition laCompetition = new Competition(txtNom.Text, Convert.ToDateTime(dateCompetitionPicker.Text), numEngagement.Value, comboCentre.SelectedIndex + 1, comboNiveau.SelectedIndex + 1, comboCateg.SelectedIndex + 1);

                            string leNom = txtNom.Text;
                            DateTime laDate = Convert.ToDateTime(dateCompetitionPicker.Text);
                            decimal lengagement = numEngagement.Value;
                            int leNiveau = comboNiveau.SelectedIndex + 1;
                            int laCategorie = comboCateg.SelectedIndex + 1;
                            int leCentre = comboCateg.SelectedIndex + 1;
                            int ajout = ClassePasserelle.AjouterCompetitionIndividuelle(laCompetition);

                            laCompetition = new Competition(ajout, leNom, laDate, lengagement, leCentre, leNiveau, laCategorie);
                            AppelCompetition();
                            bindSrcCompetition.EndEdit();
                            bindSrcCompetition.MoveLast();
                            MessageBox.Show("Compétition ajoutée", "Information", MessageBoxButtons.OK);
                        }
                    }
                    else
                    {
                        ((Competition)bindSrcCompetition.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                        ((Competition)bindSrcCompetition.Current).IdNiveau = ((Niveau)bindSrcNiveau.Current).IdNiveau;
                        ((Competition)bindSrcCompetition.Current).IdCentre = ((Centre)bindSrcCentre.Current).IdCentre;

                        Competition laCompetition = new Competition(((Competition)bindSrcCompetition.Current).IdCompetition, txtNom.Text, Convert.ToDateTime(dateCompetitionPicker.Text), numEngagement.Value, comboCentre.SelectedIndex + 1, comboNiveau.SelectedIndex + 1, comboCateg.SelectedIndex + 1);
                        ClassePasserelle.ModifierCompetitionIndividuelle(laCompetition);
                        bindSrcCompetition.EndEdit();
                        MessageBox.Show("Compétition modifiée", "Information", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare un nouvel ajout de compétition
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout_Click(object sender, EventArgs e)
        {
            bindSrcCompetition.CancelEdit();
            bindSrcCompetition.ResetBindings(false);
            bindSrcCompetition.AddNew();
            rajout = true;
            btSupprimer.Visible = false;
            btGererAjout.Visible = false;
        }

        /// <summary>
        /// Supprime une participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer2_Click(object sender, EventArgs e)
        {
            leClassementIndividuelBindingSource.CancelEdit();
            if (leClassementIndividuelBindingSource.Count == 0)
            {
                MessageBox.Show("Aucun joueur ne participe à cette compétition actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer cette participation ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerParticipationIndividuelle(((Joueur)comboJoueur.SelectedItem).IdJoueur, ((Competition)bindSrcCompetition.Current).IdCompetition);
                    leClassementIndividuelBindingSource.RemoveCurrent();
                    leClassementIndividuelBindingSource.EndEdit();
                    MessageBox.Show("Participation supprimée", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Annule la modification ou l'ajout de la participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler2_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                leClassementIndividuelBindingSource.CancelEdit();
                leClassementIndividuelBindingSource.ResetBindings(false);
                Retablir();
                leClassementIndividuelBindingSource.ResetBindings(false);
                rajout = false;
            }
            else
            {
                leClassementIndividuelBindingSource.CancelEdit();
                leClassementIndividuelBindingSource.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout de la participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAppliquer2_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (ControleJoueur(((Joueur)comboJoueur.SelectedItem).IdJoueur, false) == true)
                    {
                        MessageBox.Show("Ce joueur participe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        ClassementIndividuel leclassementIndividuel = new ClassementIndividuel(((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur.SelectedItem).IdJoueur, (int)numPoints.Value);

                        ClassePasserelle.AjouterClassementIndividuel(leclassementIndividuel);
                        ((ClassementIndividuel)leClassementIndividuelBindingSource.Current).IdJoueur = ((Joueur)comboJoueur.SelectedItem).IdJoueur;
                        leClassementIndividuelBindingSource.EndEdit();
                        leClassementIndividuelBindingSource.MoveLast();
                        MessageBox.Show("Participation ajoutée", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (leClassementIndividuelBindingSource.Count == 0)
                {
                    if (MessageBox.Show("Aucun joueur ne participe à cette compétition\n Voulez-vous ajouter celui-ci ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        try
                        {
                            ClassementIndividuel leclassementIndividuel = new ClassementIndividuel(((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur.SelectedItem).IdJoueur, (int)numPoints.Value);

                            ClassePasserelle.AjouterClassementIndividuel(leclassementIndividuel);
                            leClassementIndividuelBindingSource.Add(leclassementIndividuel);
                            leClassementIndividuelBindingSource.EndEdit();
                            leClassementIndividuelBindingSource.MoveLast();
                            MessageBox.Show("Participation ajoutée", "Information", MessageBoxButtons.OK);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else if (ControleJoueur(((Joueur)comboJoueur.SelectedItem).IdJoueur, true) == true)
                {
                    MessageBox.Show("Ce joueur participe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        ClassementIndividuel leClassementIndividuelactuel = new ClassementIndividuel(((Competition)bindSrcCompetition.Current).IdCompetition, ((ClassementIndividuel)leClassementIndividuelBindingSource.Current).IdJoueur, ((ClassementIndividuel)bindSrcClassement.Current).NbPoints);
                        ClassementIndividuel leClassementIndividuelmodifie = new ClassementIndividuel(((Competition)bindSrcCompetition.Current).IdCompetition, ((Joueur)comboJoueur.SelectedItem).IdJoueur, (int)numPoints.Value);
                        ClassePasserelle.ModifierClassementIndividuel(leClassementIndividuelactuel, leClassementIndividuelmodifie);
                        leClassementIndividuelBindingSource.EndEdit();
                        MessageBox.Show("Classement modifié", "Information", MessageBoxButtons.OK);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        /// <summary>
        /// Prépare l'ajout d'une participation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout2_Click(object sender, EventArgs e)
        {
            leClassementIndividuelBindingSource.CancelEdit();
            leClassementIndividuelBindingSource.ResetBindings(false);
            leClassementIndividuelBindingSource.AddNew();
            rajout = true;
            btSupprimer2.Visible = false;
            btGererAjout2.Visible = false;
        }

        /// <summary>
        /// Lien direct de la liste au formulaire des compétitions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridCompetition_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 1;
        }

        /// <summary>
        /// Lien direct de la liste au formulaire des participations
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 3;
        }
    }
}
