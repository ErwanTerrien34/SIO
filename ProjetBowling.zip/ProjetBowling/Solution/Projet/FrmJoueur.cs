﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Classes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projet
{
    /// <summary>
    /// Formulaire de recensement des joueurs
    /// </summary>
    public partial class FrmJoueur : Form
    {
        /// <summary>
        /// Vérifie si une donnée est en cours d'ajout
        /// </summary>
        private bool rajout = false;

        /// <summary>
        /// Liste des joueurs servant à des contrôles
        /// </summary>
        private List<Joueur> lesJoueurs = new List<Joueur>();

        public FrmJoueur()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Association des joueurs aux catégories et aux niveaux
        /// </summary>
        private void AppelJoueur()
        {
            this.bindSrcJoueur.DataSource = ClassePasserelle.GetLesJoueurs();
            foreach (Joueur unJ in bindSrcJoueur)
            {
                lesJoueurs.Add(unJ);
            }

            foreach (Joueur unJ in this.bindSrcJoueur)
            {
                unJ.LesParticipationsDuJoueur = ClassePasserelle.GetLesParticipations(unJ.IdJoueur);
            }

            foreach (Joueur unJ in this.bindSrcJoueur)
            {
                int i = 0;
                while (((Niveau)this.bindSrcNiveau[i]).IdNiveau != unJ.IdNiveau)
                {
                    i++;
                }
                unJ.LeNiveau = (Niveau)this.bindSrcNiveau[i];
            }

            foreach (Joueur unJ in this.bindSrcJoueur)
            {
                int i = 0;
                while (((Categorie)this.bindSrcCategorie[i]).IdCategorie != unJ.IdCategorie)
                {
                    i++;
                }
                unJ.LaCategorie = (Categorie)this.bindSrcCategorie[i];
            }
        }

        /// <summary>
        /// Après ajout ou annulation de l'ajout
        /// </summary>
        private void Retablir()
        {
            btSupprimer.Visible = true;
            btGererAjout.Visible = true;
        }

        /// <summary>
        /// Vérifie que plusieurs joueurs n'ont pas le même numéro de licence
        /// </summary>
        /// <param name="licence"></param>
        /// <param name="modification"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        private bool ControleLicence(string licence, bool modification, int id)
        {
            int i = 0;
            bool doublon = false;
            lesJoueurs = ClassePasserelle.GetLesJoueurs();
            if (modification == false)
            {
                while (i != (lesJoueurs.Count - 1) && doublon == false)
                {
                    if (lesJoueurs[i].NumLicence == licence)
                    {
                        doublon = true;
                    }
                    i++;
                }
            }
            else
            {
                while (i != (lesJoueurs.Count - 1) && doublon == false)
                {
                    if (lesJoueurs[i].NumLicence == licence && lesJoueurs[i].IdJoueur != id)
                    {
                        doublon = true;
                    }
                    i++;
                }
            }
            return doublon;
        }

        /// <summary>
        /// Récupération des données dans le formulaire joueur
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmJoueur_Load(object sender, EventArgs e)
        {
            try
            {
                this.bindSrcNiveau.DataSource = ClassePasserelle.GetLesNiveaux();
                this.bindSrcCategorie.DataSource = ClassePasserelle.GetLesCategories();

                AppelJoueur();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Supprime un joueur
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer_Click(object sender, EventArgs e)
        {
            if (bindSrcJoueur.Count == 0)
            {
                MessageBox.Show("Aucun joueur n'existe actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer ce joueur ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                if (((Joueur)bindSrcJoueur.Current).LesParticipationsDuJoueur.Count == 0)
                {
                    try
                    {
                        ClassePasserelle.SupprimerJoueur(((Joueur)bindSrcJoueur.Current).IdJoueur);
                        bindSrcJoueur.RemoveCurrent();
                        bindSrcJoueur.EndEdit();
                        MessageBox.Show("Joueur supprimé", "Information", MessageBoxButtons.OK);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    if (MessageBox.Show("Ce joueur participe à des compétitions, voulez-vous le supprimer quand-même ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        try
                        {
                            ClassePasserelle.SupprimerJoueur(((Joueur)bindSrcJoueur.Current).IdJoueur);
                            bindSrcJoueur.RemoveCurrent();
                            bindSrcJoueur.EndEdit();
                            MessageBox.Show("Joueur supprimé", "Information", MessageBoxButtons.OK);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Bloque le passage sur un autre onglet lors de l'ajout
        /// Annule les modifications lors du changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (this.rajout == true)
            {
                e.Cancel = true;
            }
            else
            {
                bindSrcJoueur.CancelEdit();
                bindSrcJoueur.ResetBindings(false);
            }
        }

        /// <summary>
        /// Annule les modifications
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                bindSrcJoueur.CancelEdit();
                bindSrcJoueur.ResetBindings(false);
                Retablir();
                bindSrcJoueur.ResetBindings(false);
                rajout = false;
            }
            else
            {
                bindSrcJoueur.CancelEdit();
                bindSrcJoueur.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAppliquer_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (ControleLicence(txtLicence.Text, false, 0) == true)
                    {
                        MessageBox.Show("Ce numéro de licence existe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (txtLicence.Text == "" || txtNom.Text == "" || txtPrenom.Text == "" || txtMail.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        ((Joueur)bindSrcJoueur.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                        ((Joueur)bindSrcJoueur.Current).IdNiveau = ((Niveau)bindSrcNiveau.Current).IdNiveau;

                        string laLicence = txtLicence.Text;
                        string leNom = txtNom.Text;
                        string lePrenom = txtPrenom.Text;
                        DateTime laDate = Convert.ToDateTime(dateNaissancePicker.Text);
                        string lAdresse = txtAdresse.Text;
                        string laVille = txtVille.Text;
                        string leCP = txtCP.Text;
                        string leTelephone = txtTelephone.Text;
                        string leMail = txtMail.Text;
                        int leNiveau = comboNiveau.SelectedIndex + 1;
                        int laCategorie = comboCateg.SelectedIndex + 1;

                        Joueur leJoueur = new Joueur(laLicence, leNom, lePrenom, laDate, lAdresse, laVille, leCP, leTelephone, leMail, leNiveau, laCategorie);
                        int ajout = ClassePasserelle.AjouterJoueur(leJoueur);
                        ((Joueur)bindSrcJoueur.Current).IdJoueur = ajout;
                        ((Joueur)bindSrcJoueur.Current).LesParticipationsDuJoueur = new List<Participation>();
                        bindSrcJoueur.EndEdit();
                        bindSrcJoueur.MoveLast();
                        MessageBox.Show("Joueur ajouté", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (ControleLicence(txtLicence.Text, true, ((Joueur)bindSrcJoueur.Current).IdJoueur) == true)
                    {
                        MessageBox.Show("Ce numéro de licence existe déjà", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (txtLicence.Text == "" || txtNom.Text == "" || txtPrenom.Text == "" || txtMail.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (bindSrcJoueur.Count == 0)
                    {
                        if (MessageBox.Show("Aucun joueur n'est inscrit \n Voulez-vous en créer un ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            ((Joueur)bindSrcJoueur.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                            ((Joueur)bindSrcJoueur.Current).IdNiveau = ((Niveau)bindSrcNiveau.Current).IdNiveau;

                            string laLicence = txtLicence.Text;
                            string leNom = txtNom.Text;
                            string lePrenom = txtPrenom.Text;
                            DateTime laDate = Convert.ToDateTime(dateNaissancePicker.Text);
                            string lAdresse = txtAdresse.Text;
                            string laVille = txtVille.Text;
                            string leCP = txtCP.Text;
                            string leTelephone = txtTelephone.Text;
                            string leMail = txtMail.Text;
                            int leNiveau = comboNiveau.SelectedIndex + 1;
                            int laCategorie = comboCateg.SelectedIndex + 1;

                            Joueur leJoueur = new Joueur(laLicence, leNom, lePrenom, laDate, lAdresse, laVille, leCP, leTelephone, leMail, leNiveau, laCategorie);
                            int ajout = ClassePasserelle.AjouterJoueur(leJoueur);
                            leJoueur.IdJoueur = ajout;
                            bindSrcJoueur.Add(leJoueur);
                            bindSrcJoueur.EndEdit();
                            bindSrcJoueur.MoveLast();
                            MessageBox.Show("Joueur ajouté", "Information", MessageBoxButtons.OK);
                        }
                    }
                    else
                    {
                        ((Joueur)bindSrcJoueur.Current).IdCategorie = ((Categorie)bindSrcCategorie.Current).IdCategorie;
                        ((Joueur)bindSrcJoueur.Current).IdNiveau = ((Niveau)bindSrcNiveau.Current).IdNiveau;

                        Joueur leJoueur = new Joueur(((Joueur)bindSrcJoueur.Current).IdJoueur, txtLicence.Text, txtNom.Text, txtPrenom.Text, Convert.ToDateTime(dateNaissancePicker.Text), txtAdresse.Text, txtVille.Text, txtCP.Text, txtTelephone.Text, txtMail.Text, comboNiveau.SelectedIndex + 1, comboCateg.SelectedIndex + 1);
                        ClassePasserelle.ModifierJoueur(leJoueur);
                        bindSrcJoueur.EndEdit();
                        MessageBox.Show("Joueur modifié", "Information", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare un nouvel ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout_Click(object sender, EventArgs e)
        {
            bindSrcJoueur.CancelEdit();
            bindSrcJoueur.ResetBindings(false);
            bindSrcJoueur.AddNew();
            rajout = true;
            btSupprimer.Visible = false;
            btGererAjout.Visible = false;
        }

        /// <summary>
        /// Lien direct de la liste au formulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridJoueur_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 1;
        }

        /// <summary>
        /// Place le curseur au bon endroit sur le code postal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCP_Enter(object sender, EventArgs e)
        {
            this.BeginInvoke((MethodInvoker)delegate ()
            {
                int pos = txtCP.SelectionStart;

                if (pos > txtCP.Text.Length)
                    pos = txtCP.Text.Length;
                txtCP.Select(pos, 0);
            });
        }

        /// <summary>
        /// Place le curseur au bon endroit sur le numero de téléphone
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtTelephone_Enter(object sender, EventArgs e)
        {
            this.BeginInvoke((MethodInvoker)delegate ()
            {
                int pos = txtTelephone.TextLength;
                string s = " ";
                while (pos != 0 && s == " ")
                {
                    pos -= 1;
                    try
                    {
                        s = txtTelephone.Text.Substring(pos, 1);
                    }
                    catch
                    {
                        s = " ";
                    }
                }
                if (txtTelephone.Text.First() != ' ')
                    pos += 1;
                txtTelephone.Select(pos, 0);
            });
        }
    }
}