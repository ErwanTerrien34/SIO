﻿namespace Projet
{
    partial class FrmCentre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btSupprimer = new System.Windows.Forms.Button();
            this.btAnnuler = new System.Windows.Forms.Button();
            this.btApliquer = new System.Windows.Forms.Button();
            this.btGererAjout = new System.Windows.Forms.Button();
            this.txtVille = new System.Windows.Forms.TextBox();
            this.bindSrcCentre = new System.Windows.Forms.BindingSource(this.components);
            this.txtAdresse = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtCP = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridCentre = new System.Windows.Forms.DataGridView();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.raisonSocialeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Adresse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ville = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CodePostal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCentre)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCentre)).BeginInit();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btSupprimer);
            this.tabPage2.Controls.Add(this.btAnnuler);
            this.tabPage2.Controls.Add(this.btApliquer);
            this.tabPage2.Controls.Add(this.btGererAjout);
            this.tabPage2.Controls.Add(this.txtVille);
            this.tabPage2.Controls.Add(this.txtAdresse);
            this.tabPage2.Controls.Add(this.txtNom);
            this.tabPage2.Controls.Add(this.txtCP);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 497);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Informations";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btSupprimer
            // 
            this.btSupprimer.BackColor = System.Drawing.Color.Red;
            this.btSupprimer.CausesValidation = false;
            this.btSupprimer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btSupprimer.Location = new System.Drawing.Point(769, 416);
            this.btSupprimer.Name = "btSupprimer";
            this.btSupprimer.Size = new System.Drawing.Size(96, 30);
            this.btSupprimer.TabIndex = 45;
            this.btSupprimer.Text = "Supprimer";
            this.btSupprimer.UseVisualStyleBackColor = false;
            this.btSupprimer.Click += new System.EventHandler(this.btSupprimer_Click);
            // 
            // btAnnuler
            // 
            this.btAnnuler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAnnuler.CausesValidation = false;
            this.btAnnuler.Location = new System.Drawing.Point(459, 416);
            this.btAnnuler.Name = "btAnnuler";
            this.btAnnuler.Size = new System.Drawing.Size(142, 30);
            this.btAnnuler.TabIndex = 44;
            this.btAnnuler.Text = "Annuler";
            this.btAnnuler.UseVisualStyleBackColor = false;
            this.btAnnuler.Click += new System.EventHandler(this.btAnnuler_Click);
            // 
            // btApliquer
            // 
            this.btApliquer.BackColor = System.Drawing.Color.Lime;
            this.btApliquer.CausesValidation = false;
            this.btApliquer.Location = new System.Drawing.Point(311, 416);
            this.btApliquer.Name = "btApliquer";
            this.btApliquer.Size = new System.Drawing.Size(142, 30);
            this.btApliquer.TabIndex = 43;
            this.btApliquer.Text = "Valider";
            this.btApliquer.UseVisualStyleBackColor = false;
            this.btApliquer.Click += new System.EventHandler(this.btApliquer_Click);
            // 
            // btGererAjout
            // 
            this.btGererAjout.BackColor = System.Drawing.Color.Blue;
            this.btGererAjout.CausesValidation = false;
            this.btGererAjout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btGererAjout.Location = new System.Drawing.Point(32, 416);
            this.btGererAjout.Name = "btGererAjout";
            this.btGererAjout.Size = new System.Drawing.Size(119, 30);
            this.btGererAjout.TabIndex = 42;
            this.btGererAjout.Text = "Ajouter";
            this.btGererAjout.UseVisualStyleBackColor = false;
            this.btGererAjout.Click += new System.EventHandler(this.btGererAjout_Click);
            // 
            // txtVille
            // 
            this.txtVille.CausesValidation = false;
            this.txtVille.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCentre, "Ville", true));
            this.txtVille.Location = new System.Drawing.Point(125, 195);
            this.txtVille.MaxLength = 50;
            this.txtVille.Name = "txtVille";
            this.txtVille.Size = new System.Drawing.Size(203, 20);
            this.txtVille.TabIndex = 37;
            // 
            // bindSrcCentre
            // 
            this.bindSrcCentre.DataSource = typeof(Classes.Centre);
            // 
            // txtAdresse
            // 
            this.txtAdresse.CausesValidation = false;
            this.txtAdresse.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCentre, "Adresse", true));
            this.txtAdresse.Location = new System.Drawing.Point(125, 115);
            this.txtAdresse.MaxLength = 50;
            this.txtAdresse.Name = "txtAdresse";
            this.txtAdresse.Size = new System.Drawing.Size(362, 20);
            this.txtAdresse.TabIndex = 35;
            // 
            // txtNom
            // 
            this.txtNom.CausesValidation = false;
            this.txtNom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCentre, "RaisonSociale", true));
            this.txtNom.Location = new System.Drawing.Point(125, 72);
            this.txtNom.MaxLength = 50;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(358, 20);
            this.txtNom.TabIndex = 5;
            // 
            // txtCP
            // 
            this.txtCP.CausesValidation = false;
            this.txtCP.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcCentre, "CodePostal", true));
            this.txtCP.Location = new System.Drawing.Point(125, 150);
            this.txtCP.Mask = "00000";
            this.txtCP.Name = "txtCP";
            this.txtCP.PromptChar = ' ';
            this.txtCP.Size = new System.Drawing.Size(38, 20);
            this.txtCP.TabIndex = 36;
            this.txtCP.Enter += new System.EventHandler(this.txtCP_Enter);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.CausesValidation = false;
            this.label14.Location = new System.Drawing.Point(15, 365);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "* Saisir tous les champs obligatoires";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.CausesValidation = false;
            this.label8.Location = new System.Drawing.Point(15, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Code Postal :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.CausesValidation = false;
            this.label7.Location = new System.Drawing.Point(15, 198);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Ville :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.CausesValidation = false;
            this.label4.Location = new System.Drawing.Point(15, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Adresse :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.CausesValidation = false;
            this.label3.Location = new System.Drawing.Point(15, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nom du centre * :";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridCentre);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(912, 497);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Liste des centres";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridCentre
            // 
            this.dataGridCentre.AllowUserToAddRows = false;
            this.dataGridCentre.AllowUserToDeleteRows = false;
            this.dataGridCentre.AutoGenerateColumns = false;
            this.dataGridCentre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCentre.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.raisonSocialeDataGridViewTextBoxColumn,
            this.Adresse,
            this.Ville,
            this.CodePostal});
            this.dataGridCentre.DataSource = this.bindSrcCentre;
            this.dataGridCentre.Location = new System.Drawing.Point(19, 16);
            this.dataGridCentre.Name = "dataGridCentre";
            this.dataGridCentre.ReadOnly = true;
            this.dataGridCentre.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridCentre.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridCentre.Size = new System.Drawing.Size(873, 350);
            this.dataGridCentre.TabIndex = 0;
            this.dataGridCentre.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridCentre_CellDoubleClick);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(920, 523);
            this.tabControl.TabIndex = 1;
            this.tabControl.TabStop = false;
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            // 
            // raisonSocialeDataGridViewTextBoxColumn
            // 
            this.raisonSocialeDataGridViewTextBoxColumn.DataPropertyName = "RaisonSociale";
            this.raisonSocialeDataGridViewTextBoxColumn.HeaderText = "Nom du centre";
            this.raisonSocialeDataGridViewTextBoxColumn.Name = "raisonSocialeDataGridViewTextBoxColumn";
            this.raisonSocialeDataGridViewTextBoxColumn.ReadOnly = true;
            this.raisonSocialeDataGridViewTextBoxColumn.Width = 300;
            // 
            // Adresse
            // 
            this.Adresse.DataPropertyName = "Adresse";
            this.Adresse.HeaderText = "Adresse";
            this.Adresse.Name = "Adresse";
            this.Adresse.ReadOnly = true;
            this.Adresse.Width = 400;
            // 
            // Ville
            // 
            this.Ville.DataPropertyName = "Ville";
            this.Ville.HeaderText = "Ville";
            this.Ville.Name = "Ville";
            this.Ville.ReadOnly = true;
            this.Ville.Width = 200;
            // 
            // CodePostal
            // 
            this.CodePostal.DataPropertyName = "CodePostal";
            this.CodePostal.HeaderText = "Code postal";
            this.CodePostal.Name = "CodePostal";
            this.CodePostal.ReadOnly = true;
            this.CodePostal.Width = 88;
            // 
            // FrmCentre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabControl);
            this.MinimumSize = new System.Drawing.Size(960, 600);
            this.Name = "FrmCentre";
            this.Text = "Les centres";
            this.Load += new System.EventHandler(this.FrmCentre_Load);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcCentre)).EndInit();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCentre)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource bindSrcCentre;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btSupprimer;
        private System.Windows.Forms.Button btAnnuler;
        private System.Windows.Forms.Button btApliquer;
        private System.Windows.Forms.Button btGererAjout;
        private System.Windows.Forms.TextBox txtVille;
        private System.Windows.Forms.TextBox txtAdresse;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.MaskedTextBox txtCP;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridCentre;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.DataGridViewTextBoxColumn raisonSocialeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Adresse;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ville;
        private System.Windows.Forms.DataGridViewTextBoxColumn CodePostal;
    }
}