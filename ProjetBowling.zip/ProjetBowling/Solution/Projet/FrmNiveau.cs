﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet
{
    /// <summary>
    /// Formulaire de recensement des niveaux
    /// </summary>
    public partial class FrmNiveau : Form
    {
        /// <summary>
        /// Vérifie si une donnée est en cours d'ajout
        /// </summary>
        private bool rajout = false;

        public FrmNiveau()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Après ajout ou annulation de l'ajout
        /// </summary>
        private void Retablir()
        {
            btSupprimer.Visible = true;
            btGererAjout.Visible = true;
        }

        /// <summary>
        /// Récupération des données dans le formulaire niveau
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmNiveau_Load(object sender, EventArgs e)
        {
            try
            {
                this.bindSrcNiveau.DataSource = ClassePasserelle.GetLesNiveaux();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Lien direct de la liste au formulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridNiveau_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 1;
        }

        /// <summary>
        /// Bloque le passage sur un autre onglet lors de l'ajout
        /// Annule les modifications lors du changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (this.rajout == true)
            {
                e.Cancel = true;
            }
            else
            {
                bindSrcNiveau.CancelEdit();
                bindSrcNiveau.ResetBindings(false);
            }
        }

        /// <summary>
        /// Annule les modifications
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                bindSrcNiveau.CancelEdit();
                bindSrcNiveau.ResetBindings(false);
                Retablir();
                bindSrcNiveau.ResetBindings(false);
                rajout = false;
            }
            else
            {
                bindSrcNiveau.CancelEdit();
                bindSrcNiveau.ResetBindings(false);
            }
        }

        /// <summary>
        /// Supprime un niveau
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer_Click(object sender, EventArgs e)
        {
            if (bindSrcNiveau.Count == 0)
            {
                MessageBox.Show("Aucun niveau n'existe actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer ce niveau ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerNiveau(((Niveau)bindSrcNiveau.Current).IdNiveau);
                    bindSrcNiveau.RemoveCurrent();
                    bindSrcNiveau.EndEdit();
                    MessageBox.Show("Niveau supprimé", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btApliquer_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string leNom = txtNom.Text;
                        int points = (int)numPoints.Value;

                        Niveau leNiveau = new Niveau(leNom, points);
                        int ajout = ClassePasserelle.AjouterNiveau(leNiveau);
                        ((Niveau)bindSrcNiveau.Current).IdNiveau = ajout;
                        bindSrcNiveau.EndEdit();
                        bindSrcNiveau.MoveLast();
                        MessageBox.Show("Niveau ajouté", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (bindSrcNiveau.Count == 0)
                    {
                        if (MessageBox.Show("Aucun niveau n'existe \n Voulez-vous en créer un ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            string leNom = txtNom.Text;
                            int points = (int)numPoints.Value;

                            Niveau leNiveau = new Niveau(leNom, points);
                            int ajout = ClassePasserelle.AjouterNiveau(leNiveau);
                            leNiveau.IdNiveau = ajout;
                            bindSrcNiveau.Add(leNiveau);
                            bindSrcNiveau.EndEdit();
                            bindSrcNiveau.MoveLast();
                            MessageBox.Show("Niveau ajouté", "Information", MessageBoxButtons.OK);
                        }
                    }
                    else
                    {
                        Niveau leNiveau = new Niveau(((Niveau)bindSrcNiveau.Current).IdNiveau, txtNom.Text, (int)numPoints.Value);
                        ClassePasserelle.ModifierNiveau(leNiveau);
                        bindSrcNiveau.EndEdit();
                        MessageBox.Show("Niveau modifié", "Information", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare un nouvel ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout_Click(object sender, EventArgs e)
        {
            bindSrcNiveau.CancelEdit();
            bindSrcNiveau.ResetBindings(false);
            bindSrcNiveau.AddNew();
            rajout = true;
            btSupprimer.Visible = false;
            btGererAjout.Visible = false;
        }
    }
}
