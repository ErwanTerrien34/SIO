﻿namespace Projet
{
    partial class FrmNiveau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridNiveau = new System.Windows.Forms.DataGridView();
            this.bindSrcNiveau = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.numPoints = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.btSupprimer = new System.Windows.Forms.Button();
            this.btAnnuler = new System.Windows.Forms.Button();
            this.btApliquer = new System.Windows.Forms.Button();
            this.btGererAjout = new System.Windows.Forms.Button();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.libelleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NbPointsRequis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridNiveau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcNiveau)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPoints)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(12, 28);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(920, 523);
            this.tabControl.TabIndex = 3;
            this.tabControl.TabStop = false;
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridNiveau);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(912, 497);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Liste des niveaux";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridNiveau
            // 
            this.dataGridNiveau.AllowUserToAddRows = false;
            this.dataGridNiveau.AllowUserToDeleteRows = false;
            this.dataGridNiveau.AutoGenerateColumns = false;
            this.dataGridNiveau.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridNiveau.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.libelleDataGridViewTextBoxColumn,
            this.NbPointsRequis});
            this.dataGridNiveau.DataSource = this.bindSrcNiveau;
            this.dataGridNiveau.Location = new System.Drawing.Point(19, 16);
            this.dataGridNiveau.Name = "dataGridNiveau";
            this.dataGridNiveau.ReadOnly = true;
            this.dataGridNiveau.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridNiveau.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridNiveau.Size = new System.Drawing.Size(873, 462);
            this.dataGridNiveau.TabIndex = 0;
            this.dataGridNiveau.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridNiveau_CellDoubleClick);
            // 
            // bindSrcNiveau
            // 
            this.bindSrcNiveau.DataSource = typeof(Classes.Niveau);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.numPoints);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.btSupprimer);
            this.tabPage2.Controls.Add(this.btAnnuler);
            this.tabPage2.Controls.Add(this.btApliquer);
            this.tabPage2.Controls.Add(this.btGererAjout);
            this.tabPage2.Controls.Add(this.txtNom);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(912, 497);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Informations";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // numPoints
            // 
            this.numPoints.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bindSrcNiveau, "NbPointsRequis", true));
            this.numPoints.Location = new System.Drawing.Point(162, 167);
            this.numPoints.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numPoints.Name = "numPoints";
            this.numPoints.Size = new System.Drawing.Size(120, 20);
            this.numPoints.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.CausesValidation = false;
            this.label4.Location = new System.Drawing.Point(29, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 13);
            this.label4.TabIndex = 48;
            this.label4.Text = "Nombre de points requis :";
            // 
            // btSupprimer
            // 
            this.btSupprimer.BackColor = System.Drawing.Color.Red;
            this.btSupprimer.CausesValidation = false;
            this.btSupprimer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btSupprimer.Location = new System.Drawing.Point(769, 416);
            this.btSupprimer.Name = "btSupprimer";
            this.btSupprimer.Size = new System.Drawing.Size(96, 30);
            this.btSupprimer.TabIndex = 45;
            this.btSupprimer.Text = "Supprimer";
            this.btSupprimer.UseVisualStyleBackColor = false;
            this.btSupprimer.Click += new System.EventHandler(this.btSupprimer_Click);
            // 
            // btAnnuler
            // 
            this.btAnnuler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btAnnuler.CausesValidation = false;
            this.btAnnuler.Location = new System.Drawing.Point(459, 416);
            this.btAnnuler.Name = "btAnnuler";
            this.btAnnuler.Size = new System.Drawing.Size(142, 30);
            this.btAnnuler.TabIndex = 44;
            this.btAnnuler.Text = "Annuler";
            this.btAnnuler.UseVisualStyleBackColor = false;
            this.btAnnuler.Click += new System.EventHandler(this.btAnnuler_Click);
            // 
            // btApliquer
            // 
            this.btApliquer.BackColor = System.Drawing.Color.Lime;
            this.btApliquer.CausesValidation = false;
            this.btApliquer.Location = new System.Drawing.Point(311, 416);
            this.btApliquer.Name = "btApliquer";
            this.btApliquer.Size = new System.Drawing.Size(142, 30);
            this.btApliquer.TabIndex = 43;
            this.btApliquer.Text = "Valider";
            this.btApliquer.UseVisualStyleBackColor = false;
            this.btApliquer.Click += new System.EventHandler(this.btApliquer_Click);
            // 
            // btGererAjout
            // 
            this.btGererAjout.BackColor = System.Drawing.Color.Blue;
            this.btGererAjout.CausesValidation = false;
            this.btGererAjout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btGererAjout.Location = new System.Drawing.Point(32, 416);
            this.btGererAjout.Name = "btGererAjout";
            this.btGererAjout.Size = new System.Drawing.Size(119, 30);
            this.btGererAjout.TabIndex = 42;
            this.btGererAjout.Text = "Ajouter";
            this.btGererAjout.UseVisualStyleBackColor = false;
            this.btGererAjout.Click += new System.EventHandler(this.btGererAjout_Click);
            // 
            // txtNom
            // 
            this.txtNom.CausesValidation = false;
            this.txtNom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindSrcNiveau, "Libelle", true));
            this.txtNom.Location = new System.Drawing.Point(162, 72);
            this.txtNom.MaxLength = 50;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(358, 20);
            this.txtNom.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.CausesValidation = false;
            this.label14.Location = new System.Drawing.Point(15, 365);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 13);
            this.label14.TabIndex = 34;
            this.label14.Text = "* Saisir tous les champs obligatoires";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.CausesValidation = false;
            this.label3.Location = new System.Drawing.Point(29, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Libellé * :";
            // 
            // libelleDataGridViewTextBoxColumn
            // 
            this.libelleDataGridViewTextBoxColumn.DataPropertyName = "Libelle";
            this.libelleDataGridViewTextBoxColumn.HeaderText = "Libellé";
            this.libelleDataGridViewTextBoxColumn.Name = "libelleDataGridViewTextBoxColumn";
            this.libelleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // NbPointsRequis
            // 
            this.NbPointsRequis.DataPropertyName = "NbPointsRequis";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.NbPointsRequis.DefaultCellStyle = dataGridViewCellStyle1;
            this.NbPointsRequis.HeaderText = "Points Requis";
            this.NbPointsRequis.Name = "NbPointsRequis";
            this.NbPointsRequis.ReadOnly = true;
            // 
            // FrmNiveau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabControl);
            this.MinimumSize = new System.Drawing.Size(960, 600);
            this.Name = "FrmNiveau";
            this.Text = "Les niveaux";
            this.Load += new System.EventHandler(this.FrmNiveau_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridNiveau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindSrcNiveau)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPoints)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridNiveau;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.NumericUpDown numPoints;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btSupprimer;
        private System.Windows.Forms.Button btAnnuler;
        private System.Windows.Forms.Button btApliquer;
        private System.Windows.Forms.Button btGererAjout;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource bindSrcNiveau;
        private System.Windows.Forms.DataGridViewTextBoxColumn libelleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn NbPointsRequis;
    }
}