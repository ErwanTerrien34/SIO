﻿using Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Projet
{
    /// <summary>
    /// Formulaire de recensement des centres
    /// </summary>
    public partial class FrmCentre : Form
    {
        /// <summary>
        /// Vérifie si une donnée est en cours d'ajout
        /// </summary>
        private bool rajout = false;

        public FrmCentre()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Récupération des données dans le formulaire centre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmCentre_Load(object sender, EventArgs e)
        {
            try
            {
                this.bindSrcCentre.DataSource = ClassePasserelle.GetLesCentres();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Après ajout ou annulation de l'ajout
        /// </summary>
        private void Retablir()
        {
            btSupprimer.Visible = true;
            btGererAjout.Visible = true;
        }

        /// <summary>
        /// Annule les modifications
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btAnnuler_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                bindSrcCentre.CancelEdit();
                bindSrcCentre.ResetBindings(false);
                Retablir();
                bindSrcCentre.ResetBindings(false);
                rajout = false;
            }
            else
            {
                bindSrcCentre.CancelEdit();
                bindSrcCentre.ResetBindings(false);
            }
        }

        /// <summary>
        /// Supprime un centre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btSupprimer_Click(object sender, EventArgs e)
        {
            if (bindSrcCentre.Count == 0)
            {
                MessageBox.Show("Aucun centre n'existe actuellement", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Voulez-vous réellement supprimer ce centre ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    ClassePasserelle.SupprimerCentre(((Centre)bindSrcCentre.Current).IdCentre);
                    bindSrcCentre.RemoveCurrent();
                    bindSrcCentre.EndEdit();
                    MessageBox.Show("Centre supprimé", "Information", MessageBoxButtons.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        /// <summary>
        /// Lien direct de la liste au formulaire
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridCentre_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabControl.SelectedIndex = 1;
        }

        /// <summary>
        /// Bloque le passage sur un autre onglet lors de l'ajout
        /// Annule les modifications lors du changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (this.rajout == true)
            {
                e.Cancel = true;
            }
            else
            {
                bindSrcCentre.CancelEdit();
                bindSrcCentre.ResetBindings(false);
            }
        }

        /// <summary>
        /// Valide la modification ou l'ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btApliquer_Click(object sender, EventArgs e)
        {
            if (this.rajout == true)
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string leNom = txtNom.Text;
                        string lAdresse = txtAdresse.Text;
                        string laVille = txtVille.Text;
                        string leCP = txtCP.Text;

                        Centre leCentre = new Centre(leNom, lAdresse, laVille, leCP);
                        int ajout = ClassePasserelle.AjouterCentre(leCentre);
                        ((Centre)bindSrcCentre.Current).IdCentre = ajout;
                        bindSrcCentre.EndEdit();
                        bindSrcCentre.MoveLast();
                        MessageBox.Show("Centre ajouté", "Information", MessageBoxButtons.OK);
                        Retablir();
                        rajout = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                try
                {
                    if (txtNom.Text == "")
                    {
                        MessageBox.Show("Saisir tous les champs obligatoires", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (bindSrcCentre.Count == 0)
                    {
                        if (MessageBox.Show("Aucun centre n'est recensé \n Voulez-vous en créer un ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            string leNom = txtNom.Text;
                            string lAdresse = txtAdresse.Text;
                            string laVille = txtVille.Text;
                            string leCP = txtCP.Text;

                            Centre leCentre = new Centre(leNom, lAdresse, laVille, leCP);
                            int ajout = ClassePasserelle.AjouterCentre(leCentre);
                            leCentre.IdCentre = ajout;
                            bindSrcCentre.Add(leCentre);
                            bindSrcCentre.EndEdit();
                            bindSrcCentre.MoveLast();
                            MessageBox.Show("Centre ajouté", "Information", MessageBoxButtons.OK);
                            Retablir();
                            rajout = false;
                        }
                    }
                    else
                    {
                        Centre leCentre = new Centre(((Centre)bindSrcCentre.Current).IdCentre, txtNom.Text, txtAdresse.Text, txtVille.Text, txtCP.Text);
                        ClassePasserelle.ModifierCentre(leCentre);
                        bindSrcCentre.EndEdit();
                        MessageBox.Show("Centre modifié", "Information", MessageBoxButtons.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prépare un nouvel ajout
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btGererAjout_Click(object sender, EventArgs e)
        {
            bindSrcCentre.CancelEdit();
            bindSrcCentre.ResetBindings(false);
            bindSrcCentre.AddNew();
            rajout = true;
            btSupprimer.Visible = false;
            btGererAjout.Visible = false;
        }

        /// <summary>
        /// Place le curseur au bon endroit sur le code postal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCP_Enter(object sender, EventArgs e)
        {
            this.BeginInvoke((MethodInvoker)delegate ()
            {
                int pos = txtCP.SelectionStart;

                if (pos > txtCP.Text.Length)
                    pos = txtCP.Text.Length;
                txtCP.Select(pos, 0);
            });
        }
    }
}
