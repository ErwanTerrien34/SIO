use ProjetBowling;
go

--Cr�ation des centres
INSERT INTO Centre (raisonSociale, adresse , ville, codePostal) VALUES ('Centre M�dit�rran�e', 'Pompignane', 'Montpellier', 34000), ('Centre national', 'Elys�es', 'Paris', 75000), ('Centre Nordique', 'Lille Sud', 'Lille', 59000)

--Cr�ation des cat�gories
INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES ('Minime', 3, 6)
INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES ('Cadet', 7, 11)
INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES ('Junior', 12, 17)
INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES ('Senior', 18, 65)

--Cr�ation des niveaux
INSERT INTO Niveau (libelle, nbPointsRequis) VALUES ('Promotion', 50)
INSERT INTO Niveau (libelle, nbPointsRequis) VALUES ('Honneur', 100)
INSERT INTO Niveau (libelle, nbPointsRequis) VALUES ('Excellence', 400)
INSERT INTO Niveau (libelle, nbPointsRequis) VALUES ('Elite', 40000)

--Cr�ation des comp�titions
INSERT INTO Competition (nom, dateCompetition, engagement, idCategorie, idCentre) VALUES ('Championnat  F�d�ral  Individuel -Excellence  Phase R�gionale', '01/02/2023', 15, 1, 1), ('Championnat  F�d�ral  Doublette -Excellence  Phase R�gionale', '07/02/2023', 15, 1, 1), ('Les deux � la fois', '07/02/2023', 15, 1, 1), ('Competition tr�s simple', '07/02/2023', 15, 1, 1)

--Cr�ation des joueurs
INSERT Into Joueur (numLicence, nom, prenom, dateNaissance, adresse, ville, codePostal, numTelephone, adresseMail, idNiveau, idCategorie) VALUES
('OCC1', 'Pratini', 'Michel', '01/01/2020', 'Antigone', 'Montpellier', '34000', '04 04 04 04 04', 'm.pratini@mail.com', 1, 1),
('NAQ1', 'Laporte', 'Willy', '02/02/2018', 'Caud�ran', 'Bordeaux', '33000', '05 05 05 05 05', 'w.laporte@mail.com', 2, 1),
('BZH1', 'Dupont', 'Thierry', '03/03/2013', 'Saint-Michel', 'Rennes', '35000', '02 02 02 02 02', 't.dupont@mail.com', 1, 2),
('GDE1', 'Dupond', 'Damien', '01/01/2010', 'Meinau', 'Strasbourg', '67000', '03 03 03 03 03', 'd.dupond@mail.com', 2, 2),
('OCC2', 'Brun', 'Jean-Pierre', '12/05/2009', 'Place du temple', 'Arphy', '30120', '04 04 04 04 05', 'jp.brun@mail.com', 3, 2),
('IDF1', 'Laporte', 'Laurence', '26/03/1999', 'La d�fense', 'Paris', '75000', '01 01 01 01 01', 'l.brun@mail.com', 2, 4),
('PDL1', 'Lelouedec', 'Anthony', '23/01/2008', 'Sainte-croix', 'Nantes', '44000', '02 02 02 02 03', 'a.lelouedec@mail.com', 2, 3),
('PAC1', 'Pasquier', 'Christine', '05/05/2006', 'Chateau de la Buzine', 'Marseille', '13000', '04 04 04 04 06', 'p.christine@mail.com', 3, 3),
('OCC3', 'Oriale', 'Edith', '12/05/2009', 'Place du temple', 'Arphy', '30120', '04 04 09 09 09', 'jp.brun@mail.com', 4, 3),
('OCC4', 'Apouf', 'Pat', '12/05/1999', 'Place du temple', 'Arphy', '30120', '04 04 08 08 08', 'p.apouf@mail.com', 4, 4),
('ARA1', 'Suffit', 'Sam', '09/06/2018', 'Rh�ne', 'Lyon', '69000', '04 04 04 05 05', 's.suffit@mail.com', 3, 1),
('CTR1', 'Khan', 'Jerry', '03/10/1980', 'Chateau de la loire', 'Orl�ans', '45000', '02 02 02 03 03', 'j.khan@mail.com', 3, 4),
('OCC5', 'Bricot', 'Judas', '09/06/1998', 'Gare du train jaune', 'Font-Romeu', '66000', '04 04 04 06 06', 'j.bricot@mail.com', 1, 4),
('PAC2', 'Aire', 'Axel', '04/12/1993', 'Sofia Antipolis', 'Nice', '06000', '04 04 03 06 09', 'a.aire@mail.com', 4, 1),
('HDF1', 'Proviste', 'Alain', '04/12/2017', 'C�tes du nord', 'Lille', '69000', '03 03 03 03 04', 'a.proviste@mail.com', 4, 2),
('BFC1', 'Menvussat', 'G�rard', '24/06/2007', 'Champs de moutarde', 'Dijon', '21000', '03 03 03 03 05', 'g.menvussat@mail.com', 1, 3),
('ARA2', 'Covert', 'Harry', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'h.covert@mail.com', 1, 1),
('BZH2', 'Tergeist', 'Paul', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'p.tergeist@mail.com', 1, 2),
('GDE2', 'Hochon', 'Paul', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'p.hochon@mail.com', 1, 3),
('NOR1', 'Ponsable', 'Th�r�se', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 't.ponsable@mail.com', 1, 4),
('GDE3', 'Monflis', 'Thibaut', '30/09/2014', 'Centre Pompidou', 'Metz', '57000', '03 03 03 03 01', 't.monfils@mail.com', 2, 2),
('PAC3', 'Gonzola', 'Igor', '04/12/2005', 'Mont-Blanc', 'Gap', '04000', '04 04 03 06 08', 'a.aire@mail.com', 2, 3),
('CAT1', 'Onyote', 'Anne', '04/12/1975', 'Col du Perthus', 'Barcelone', '99999', '34 99 99 99 99', 'a.onyote@mail.com', 2, 4),
('ITC1', 'Vessel', 'Aude', '04/12/2006', 'Mont-Cenis', 'Turin', '99999', '39 99 99 99 99', 'a.vessel@mail.com', 3, 3),
('BDW1', 'Javel', 'Aude', '04/12/1955', 'Wissembourg', 'Stuttgart', '99999', '49 99 99 99 99', 'a.javel@mail.com', 3, 4),

('MIN10', 'Minim', 'Promu', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.promu@mail.com', 1, 1),
('CAD10', 'Cadet', 'Promu', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.promu@mail.com', 1, 2),
('JUN10', 'Junior', 'Promu', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.promu.com', 1, 3),
('SEN10', 'Senior', 'Promu', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.promu@mail.com', 1, 4),
('MIN20', 'Minim', 'Honor�', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.honore@mail.com', 2, 1),
('CAD20', 'Cadet', 'Honor�', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.honore@mail.com', 2, 2),
('JUN20', 'Junior', 'Honor�', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.honore.com', 2, 3),
('SEN20', 'Senior', 'Honor�', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.honore@mail.com', 2, 4),
('MIN30', 'Minim', 'Excellent', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.excellent@mail.com', 3, 1),
('CAD30', 'Cadet', 'Excellent', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.excellent@mail.com', 3, 2),
('JUN30', 'Junior', 'Excellent', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.excellent.com', 3, 3),
('SEN30', 'Senior', 'Excellent', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.excellent@mail.com', 3, 4),
('MIN40', 'Minim', 'Elite', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.elite@mail.com', 4, 1),
('CAD40', 'Cadet', 'Elite', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.elite@mail.com', 4, 2),
('JUN40', 'Junior', 'Elite', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.elite.com', 4, 3),
('SEN40', 'Senior', 'Elite', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.elite@mail.com', 4, 4),

('MIN11', 'Minime', 'Promue', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.promue@mail.com', 1, 1),
('CAD11', 'Cadette', 'Promue', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.promue@mail.com', 1, 2),
('JUN11', 'Juniore', 'Promue', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.promue.com', 1, 3),
('SEN11', 'Seniore', 'Promue', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.promue@mail.com', 1, 4),
('MIN21', 'Minime', 'Honor�e', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.honoree@mail.com', 2, 1),
('CAD21', 'Cadette', 'Honor�e', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.honoree@mail.com', 2, 2),
('JUN21', 'Juniore', 'Honor�e', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.honoree.com', 2, 3),
('SEN21', 'Seniore', 'Honor�e', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.honoree@mail.com', 2, 4),
('MIN31', 'Minime', 'Excellence', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.excellence@mail.com', 3, 1),
('CAD31', 'Cadette', 'Excellence', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.excellence@mail.com', 3, 2),
('JUN31', 'Juniore', 'Excellence', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.excellence.com', 3, 3),
('SEN31', 'Seniore', 'Excellence', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.excellence@mail.com', 3, 4),
('MIN41', 'Minime', 'Elite', '09/06/2018', 'Massif central', 'Clermont-Ferrand', '69000', '04 04 04 05 05', 'm.elite@mail.com', 4, 1),
('CAD41', 'Cadette', 'Elite', '03/03/2013', 'Phare occidental', 'Landudec', '29108', '02 02 02 02 03', 'c.elite@mail.com', 4, 2),
('JUN41', 'Juniore', 'Elite', '01/01/2010', 'Vallon oriental', 'Wasserbourg', '68358', '03 03 03 03 06', 'j.elite.com', 4, 3),
('SEN41', 'Seniore', 'Elite', '27/05/1994', 'Ligne verticale', 'Rouen', '76000', '02 02 02 02 09', 's.elite@mail.com', 4, 4)

--D�but de la r�partition des comp�titions individuelles/doublettes
INSERT INTO Individuelle VALUES (1, 2)

INSERT INTO Doublette VALUES (2)

INSERT INTO Doublette VALUES (3)

INSERT INTO Individuelle VALUES (4, 1)
--Fin de la r�partition des comp�titions individuelles/doublettes

--Ajout des inscriptions individuelles
INSERT INTO Inscription_Individuelle VALUES (2, 1, 12)
INSERT INTO Inscription_Individuelle VALUES (30, 1, 12)
INSERT INTO Inscription_Individuelle VALUES (46, 1, 12) 
INSERT INTO Inscription_Individuelle VALUES (1, 4, 30)

--Ajout des �quipes
INSERT INTO Equipe (Joueur1, Joueur2) VALUES (1,2)
INSERT INTO Equipe (Joueur1, Joueur2) VALUES (26,42)
INSERT INTO Equipe (Joueur1, Joueur2) VALUES (30,46)
INSERT INTO Equipe (Joueur1, Joueur2) VALUES (34,50)
INSERT INTO Equipe (Joueur1, Joueur2) VALUES (38,54)

--Ajout des inscriptions doublettes
INSERT INTO S_associer (idCompetition, numEquipe, pointsObtenuADeux) VALUES (2, 1, 30)
INSERT INTO S_associer (idCompetition, numEquipe, pointsObtenuADeux) VALUES (2, 2, 30)
INSERT INTO S_associer (idCompetition, numEquipe, pointsObtenuADeux) VALUES (2, 3, 30)
INSERT INTO S_associer (idCompetition, numEquipe, pointsObtenuADeux) VALUES (2, 4, 30)
INSERT INTO S_associer (idCompetition, numEquipe, pointsObtenuADeux) VALUES (2, 5, 30)