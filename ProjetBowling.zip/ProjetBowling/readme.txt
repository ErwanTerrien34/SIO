1. Exécuter le script "BDD bownling.sql" dans sql server
2. Exécuter le script "Essai bownling.sql" dans sql server

Des tests avec les triggers peuvent être effectués. Le script prévu à cet effet se nomme "Test triggers.sql"