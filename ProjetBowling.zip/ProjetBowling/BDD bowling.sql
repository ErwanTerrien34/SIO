CREATE DATABASE ProjetBowling -- Cr�ation de la base
go
create login Quilles with password = 'B0w1!ng'; -- Cr�ation de l'utilisateur
go
use ProjetBowling;
go
create user Quilles for login Quilles;
go

-- Attribution des droits � l'utilisateur quilles
alter role db_datareader add MEMBER Quilles;
alter role db_datawriter add MEMBER Quilles;
go

-- D�but de cr�ation des tables
CREATE TABLE Categorie(
   idCategorie INT IDENTITY,
   libelle VARCHAR(50) ,
   ageMin TINYINT,
   ageMax TINYINT,
   PRIMARY KEY(idCategorie)
);
go

CREATE TABLE Centre(
   idCentre INT IDENTITY,
   raisonSociale VARCHAR(50) ,
   adresse VARCHAR(50) ,
   ville VARCHAR(50) ,
   codePostal CHAR(5) ,
   PRIMARY KEY(idCentre)
);
go

CREATE TABLE Niveau(
   idNiveau INT IDENTITY,
   libelle VARCHAR(50),
   nbPointsRequis INT,
   PRIMARY KEY(idNiveau)
);
go

CREATE TABLE Joueur(
   idJoueur INT IDENTITY,
   numLicence VARCHAR(10)  NOT NULL,
   nom VARCHAR(50) ,
   prenom VARCHAR(50) ,
   dateNaissance DATE,
   adresse VARCHAR(50) ,
   ville VARCHAR(50) ,
   codePostal CHAR(5) ,
   numTelephone VARCHAR(14) ,
   adresseMail VARCHAR(50) ,
   idNiveau INT NOT NULL,
   idCategorie INT NOT NULL,
   PRIMARY KEY(idJoueur),
   UNIQUE(numLicence),
   FOREIGN KEY(idNiveau) REFERENCES Niveau(idNiveau),
   FOREIGN KEY(idCategorie) REFERENCES Categorie(idCategorie)
);
go

CREATE TABLE Competition(
   idCompetition INT IDENTITY,
   nom VARCHAR(200) ,
   dateCompetition DATE NOT NULL,
   engagement MONEY,
   idCategorie INT NOT NULL,
   idCentre INT NOT NULL,
   PRIMARY KEY(idCompetition),
   FOREIGN KEY(idCategorie) REFERENCES Categorie(idCategorie),
   FOREIGN KEY(idCentre) REFERENCES Centre(idCentre)
);
go

CREATE TABLE Individuelle(
   idCompetition INT,
   idNiveau INT NOT NULL,
   PRIMARY KEY(idCompetition),
   FOREIGN KEY(idCompetition) REFERENCES Competition(idCompetition),
   FOREIGN KEY(idNiveau) REFERENCES Niveau(idNiveau)
);
go

CREATE TABLE Doublette(
   idCompetition INT,
   PRIMARY KEY(idCompetition),
   FOREIGN KEY(idCompetition) REFERENCES Competition(idCompetition)
); 
go

CREATE TABLE Equipe(
   numEquipe INT IDENTITY,
   Joueur1 INT NOT NULL,
   Joueur2 INT NOT NULL,
   PRIMARY KEY(numEquipe),
   FOREIGN KEY(Joueur1) REFERENCES Joueur(idJoueur),
   FOREIGN KEY(Joueur2) REFERENCES Joueur(idJoueur)
);
go

CREATE TABLE Inscription_Individuelle(
   idJoueur INT,
   idCompetition INT,
   pointsObtenusSeul INT NOT NULL,
   PRIMARY KEY(idJoueur, idCompetition),
   FOREIGN KEY(idJoueur) REFERENCES Joueur(idJoueur),
   FOREIGN KEY(idCompetition) REFERENCES Individuelle(idCompetition)
);
go

CREATE TABLE S_associer(
   idCompetition INT,
   numEquipe INT,
   pointsObtenuADeux INT NOT NULL,
   PRIMARY KEY(idCompetition, numEquipe),
   FOREIGN KEY(idCompetition) REFERENCES Doublette(idCompetition),
   FOREIGN KEY(numEquipe) REFERENCES Equipe(numEquipe)
);
go
-- Fin de cr�ation des tables


-- D�but de cr�ation des triggers
CREATE OR ALTER TRIGGER TIU_Inscription_Individuelle ON Inscription_Individuelle
AFTER INSERT, UPDATE
AS
BEGIN
	IF ((SELECT idCategorie FROM Joueur WHERE idJoueur IN (SELECT idJoueur FROM inserted)) != (SELECT idCategorie FROM Competition WHERE idCompetition IN (SELECT idCompetition FROM inserted)))
		throw 50001 , 'Le joueur n''a pas la bonne cat�gorie pour faire la comp�tition!',0
	
	IF ((SELECT idNiveau FROM Joueur WHERE idJoueur IN (SELECT idJoueur FROM inserted)) != (SELECT idNiveau FROM Individuelle WHERE idCompetition IN (SELECT idCompetition FROM inserted)))
		throw 50001 , 'Le joueur n''a pas le niveau correspondant � la comp�tition!',0
END
go

CREATE OR ALTER TRIGGER TIU_Individuelle ON Individuelle
AFTER INSERT, UPDATE
AS
BEGIN
	IF ((SELECT idCompetition FROM inserted) = (SELECT idCompetition FROM Doublette WHERE idCompetition IN (SELECT idCompetition FROM inserted)))
		throw 50001 , 'La comp�tition ne peut pas appartenir aux deux types!',0
END
go

CREATE OR ALTER TRIGGER TIU_Doublette ON Doublette
AFTER INSERT, UPDATE
AS
BEGIN
	IF ((SELECT idCompetition FROM inserted) = (SELECT idCompetition FROM Individuelle WHERE idCompetition IN (SELECT idCompetition FROM inserted)))
		throw 50001 , 'La comp�tition ne peut pas appartenir aux deux types!',0
END
go

CREATE OR ALTER TRIGGER TD_Joueur ON Joueur
INSTEAD OF DELETE
AS
BEGIN
	DELETE FROM Equipe WHERE Joueur1 IN (SELECT idJoueur FROM deleted) OR Joueur2 IN (SELECT idJoueur FROM deleted)
	DELETE FROM Inscription_Individuelle WHERE idJoueur IN (SELECT idJoueur FROM deleted)
	DELETE FROM Joueur WHERE idJoueur IN (SELECT idJoueur FROM deleted)
END
go

CREATE OR ALTER TRIGGER TD_Equipe ON Equipe
INSTEAD OF DELETE
AS
BEGIN
	DELETE FROM S_associer WHERE numEquipe IN (SELECT numEquipe FROM deleted)
	DELETE FROM Equipe WHERE numEquipe IN (SELECT numEquipe FROM deleted)
END
go

CREATE OR ALTER TRIGGER TD_Individuelle ON Individuelle
INSTEAD OF DELETE
AS
BEGIN
	DELETE FROM Inscription_Individuelle WHERE idCompetition IN (SELECT idCompetition FROM deleted)
	DELETE FROM Individuelle WHERE idCompetition IN (SELECT idCompetition FROM deleted)
END
go

CREATE OR ALTER TRIGGER TD_Doublette ON Doublette
INSTEAD OF DELETE
AS
BEGIN
	DELETE FROM S_associer WHERE idCompetition IN (SELECT idCompetition FROM deleted)
	DELETE FROM Doublette WHERE idCompetition IN (SELECT idCompetition FROM deleted)
END
go

CREATE OR ALTER TRIGGER TD_Competition ON Competition
INSTEAD OF DELETE
AS
BEGIN
	DELETE FROM Individuelle WHERE idCompetition IN (SELECT idCompetition FROM deleted)
	DELETE FROM Doublette WHERE idCompetition IN (SELECT idCompetition FROM deleted)
	DELETE FROM Competition WHERE idCompetition IN (SELECT idCompetition FROM deleted)
END
go

CREATE OR ALTER TRIGGER TD_Centre ON Centre
INSTEAD OF DELETE
AS
BEGIN
	IF (exists(select * from Competition WHERE idCentre IN (SELECT idCentre FROM deleted)))
		throw 50001, 'Supression impossible! Des comp�titions sont rattach�es � ce centre',0
	ELSE
		DELETE FROM Centre WHERE idCentre IN (SELECT idCentre FROM deleted)
END
go

CREATE OR ALTER TRIGGER TIU_Equipe ON Equipe
AFTER INSERT, UPDATE
AS
BEGIN
	IF ((SELECT Joueur1 FROM inserted) = (SELECT Joueur2 FROM inserted))
		throw 50001 , 'Il faut deux joueurs diff�rents',0

	IF ((SELECT idCategorie FROM inserted I JOIN Joueur J ON I.Joueur1 = J.idJoueur) != (SELECT idCategorie FROM inserted I JOIN Joueur J ON I.Joueur2 = J.idJoueur))
		throw 50001 , 'Les joueurs doivent faire partie de la m�me cat�gorie',0
END
go

CREATE OR ALTER TRIGGER TI_Categorie ON Categorie
AFTER INSERT
AS
BEGIN
	IF ((SELECT ageMin FROM inserted) > (SELECT ageMax FROM inserted))
		throw 50001 , 'L''�ge minimal ne peut pas �tre sup�rieur � l''�ge maximal',0

	IF (exists(select * from Categorie C join inserted I ON I.ageMin BETWEEN C.ageMin AND C.ageMax OR I.ageMax BETWEEN C.ageMin AND C.ageMax WHERE C.idCategorie != (SELECT idCategorie FROM inserted)))
		throw 50001, 'Les cat�gories ne peuvent pas se chevaucher',0
END
go

CREATE OR ALTER TRIGGER TU_Categorie ON Categorie
AFTER UPDATE
AS
BEGIN
	IF ((SELECT ageMin FROM inserted) > (SELECT ageMax FROM inserted))
		throw 50001 , 'L''�ge minimal ne peut pas �tre sup�rieur � l''�ge maximal',0

	IF ((SELECT ageMin FROM inserted) != (SELECT ageMin FROM deleted))
		IF (exists(select * from Categorie C join inserted I ON I.ageMin BETWEEN C.ageMin AND C.ageMax OR I.ageMax BETWEEN C.ageMin AND C.ageMax WHERE C.idCategorie != (SELECT idCategorie FROM inserted)))
			throw 50001, 'Les cat�gories ne peuvent pas se chevaucher',0

	IF ((SELECT ageMax FROM inserted) != (SELECT ageMax FROM deleted))
		IF (exists(select * from Categorie C join inserted I ON I.ageMin BETWEEN C.ageMin AND C.ageMax OR I.ageMax BETWEEN C.ageMin AND C.ageMax WHERE C.idCategorie != (SELECT idCategorie FROM inserted)))
			throw 50001, 'Les cat�gories ne peuvent pas se chevaucher',0
END
go

CREATE OR ALTER TRIGGER TD_Categorie ON Categorie
INSTEAD OF DELETE
AS
BEGIN
	IF (exists(select * from Joueur WHERE idCategorie IN (SELECT idCategorie FROM deleted)))
		throw 50001, 'Supression impossible! Des joueurs sont rattach�s � cette cat�gorie',0
	ELSE IF (exists(select * from Competition WHERE idCategorie IN (SELECT idCategorie FROM deleted)))
		throw 50001, 'Supression impossible! Des comp�titions sont rattach�es � cette cat�gorie',0
	ELSE
		DELETE FROM Categorie WHERE idCategorie IN (SELECT idCategorie FROM deleted)
END
go

CREATE OR ALTER TRIGGER TI_Niveau ON Niveau
INSTEAD OF INSERT
AS
BEGIN
	IF (exists(select * from Niveau N join inserted I ON N.nbPointsRequis = I.nbPointsRequis))
		throw 50001, 'Deux niveaux ne peuvent pas avoir le m�me nombre de points requis',0
	ELSE
		INSERT INTO Niveau (libelle, nbPointsRequis) VALUES ((SELECT libelle from inserted), (SELECT nbPointsRequis from inserted))
END
go

CREATE OR ALTER TRIGGER TU_Niveau ON Niveau
INSTEAD OF UPDATE
AS
BEGIN
	IF (exists(select * from Niveau N join inserted I ON N.nbPointsRequis = I.nbPointsRequis AND N.idNiveau != (SELECT idNiveau FROM inserted)))
		throw 50001, 'Deux niveaux ne peuvent pas avoir le m�me nombre de points requis',0
	ELSE
		UPDATE Niveau SET libelle = (SELECT libelle from inserted), nbPointsRequis = (SELECT nbPointsRequis from inserted) WHERE idNiveau = (SELECT idNiveau FROM inserted)
END
go

CREATE OR ALTER TRIGGER TD_Niveau ON Niveau
INSTEAD OF DELETE
AS
BEGIN
	IF (exists(select * from Joueur WHERE idNiveau IN (SELECT idNiveau FROM deleted)))
		throw 50001, 'Supression impossible! Des joueurs sont rattach�s � ce niveau',0
	ELSE IF (exists(select * from Individuelle WHERE idNiveau IN (SELECT idNiveau FROM deleted)))
		throw 50001, 'Supression impossible! Des comp�titions sont rattach�es � ce niveau',0
	ELSE
		DELETE FROM Niveau WHERE idNiveau IN (SELECT idNiveau FROM deleted)
END
go
-- Fin de cr�ation des triggers


-- Cr�ation de la proc�dure stock�e
CREATE OR ALTER PROCEDURE Participations
@joueur int
AS
BEGIN
	(SELECT C.idCompetition, nom, dateCompetition, 'Individuelle' AS TypeCompetition, pointsObtenusSeul AS nbPointsObtenus
	FROM Competition C
		JOIN Individuelle I ON I.idCompetition = C.idCompetition
		JOIN Inscription_Individuelle Ii on C.idCompetition = Ii.idCompetition
	WHERE idJoueur = @joueur)
	UNION
	(SELECT C.idCompetition, nom, dateCompetition, 'Doublette' AS TypeCompetition, pointsObtenuADeux AS nbPointsObtenus
	FROM Competition C
		JOIN Doublette D ON D.idCompetition = C.idCompetition
		JOIN S_associer A on C.idCompetition = A.idCompetition
		JOIN Equipe E ON E.numEquipe = A.numEquipe
	WHERE Joueur1 = @joueur OR Joueur2 = @joueur)
END
go

-- Autorisation pour l'utilisateur quilles d'ex�cuter la proc�dure
GRANT EXECUTE ON dbo.Participations TO Quilles;  
go