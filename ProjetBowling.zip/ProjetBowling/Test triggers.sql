use ProjetBowling;
go

INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES ('Chevauch�s', 5, 10) --Test de chevauchement des  cat�gories
go

INSERT INTO Categorie (libelle, ageMin, ageMax) VALUES ('Invers�', 79, 77) --Test de l'age minimal et maximal
go

INSERT INTO Niveau (libelle, nbPointsRequis) VALUES ('Identique Promotion', 50)--Test de niveaux ayant des points requis identiques
go

--Comp�tition dans les deux types
INSERT INTO Individuelle VALUES (3, 2) --Pr�sente dans les doublettes
go

INSERT INTO Inscription_Individuelle VALUES (3, 1, 12) --Joueur de la mauvaise cat�gorie
go

INSERT INTO Inscription_Individuelle VALUES (30, 4, 12) --Joueur du mauvais niveau
go

INSERT INTO Equipe (Joueur1, Joueur2) VALUES (1,3) --Equipe avec deux joueurs de cat�gories diff�rentes
go

INSERT INTO Equipe (Joueur1, Joueur2) VALUES (1,1) --Equipe avec deux joueurs les m�mes
go